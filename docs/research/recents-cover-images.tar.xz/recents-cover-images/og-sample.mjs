// Samples declared cover images (og:image, then twitter:image) of recent articles from publisher
// front pages and reports byte length, format and pixel dimensions. Image bytes stay in memory.
const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";
const ACCEPT_IMAGE = "image/jpeg,image/png,image/webp,image/avif,image/gif,*/*;q=0.5";
const fronts = process.argv.slice(2);
const perFront = 2;

async function get(url, accept) {
  const response = await fetch(url, {
    headers: { "User-Agent": UA, Accept: accept, "Accept-Language": "en,de;q=0.8" },
    redirect: "follow",
    signal: AbortSignal.timeout(15_000),
  });
  return response;
}

function metaContent(html, names) {
  for (const name of names) {
    const re = new RegExp(
      `<meta[^>]+(?:property|name)=["']${name}["'][^>]*>`,
      "i",
    );
    const tag = html.match(re)?.[0];
    const content = tag?.match(/content=["']([^"']+)["']/i)?.[1];
    if (content) return content.replaceAll("&amp;", "&");
  }
  return undefined;
}

function articleLinks(html, base) {
  const host = new URL(base).host;
  const seen = new Set();
  for (const m of html.matchAll(/href=["']([^"'#?]+)["']/gi)) {
    let u;
    try {
      u = new URL(m[1], base);
    } catch {
      continue;
    }
    if (u.host !== host) continue;
    const path = u.pathname;
    const slug = path.split("/").filter(Boolean).at(-1) ?? "";
    if (slug.split("-").length >= 4 || /\/20\d\d\/\d\d\//.test(path)) seen.add(u.href);
    if (seen.size >= 12) break;
  }
  return [...seen];
}

function dimensions(b) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const ascii = (s, e) => String.fromCharCode(...b.subarray(s, e));
  if (b[0] === 0xff && b[1] === 0xd8) {
    let o = 2;
    while (o + 9 < b.length) {
      if (b[o] !== 0xff) { o++; continue; }
      const marker = b[o + 1];
      const len = dv.getUint16(o + 2);
      if (marker >= 0xc0 && marker <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marker)) {
        return { format: "jpeg", height: dv.getUint16(o + 5), width: dv.getUint16(o + 7) };
      }
      o += 2 + len;
    }
    return { format: "jpeg" };
  }
  if (b[0] === 0x89 && ascii(1, 4) === "PNG") return { format: "png", width: dv.getUint32(16), height: dv.getUint32(20) };
  if (ascii(0, 6).startsWith("GIF8")) return { format: "gif", width: dv.getUint16(6, true), height: dv.getUint16(8, true) };
  if (ascii(0, 4) === "RIFF" && ascii(8, 12) === "WEBP") {
    const chunk = ascii(12, 16);
    if (chunk === "VP8 ") return { format: "webp", width: dv.getUint16(26, true) & 0x3fff, height: dv.getUint16(28, true) & 0x3fff };
    if (chunk === "VP8L") {
      const bits = dv.getUint32(21, true);
      return { format: "webp", width: (bits & 0x3fff) + 1, height: ((bits >> 14) & 0x3fff) + 1 };
    }
    if (chunk === "VP8X") {
      const w = 1 + (b[24] | (b[25] << 8) | (b[26] << 16));
      const h = 1 + (b[27] | (b[28] << 8) | (b[29] << 16));
      return { format: "webp", width: w, height: h };
    }
    return { format: "webp" };
  }
  if (ascii(4, 8) === "ftyp") {
    const i = ascii(0, Math.min(b.length, 4096)).indexOf("ispe");
    return i > 0 ? { format: "avif", width: dv.getUint32(i + 8), height: dv.getUint32(i + 12) } : { format: "avif" };
  }
  return { format: "other" };
}

const rows = [];
for (const front of fronts) {
  try {
    const html = await (await get(front, "text/html")).text();
    const links = articleLinks(html, front);
    let taken = 0;
    for (const link of links) {
      if (taken >= perFront) break;
      try {
        const page = await get(link, "text/html");
        if (!page.ok) continue;
        const pageHtml = await page.text();
        const declared = metaContent(pageHtml, ["og:image", "og:image:url", "twitter:image", "twitter:image:src"]);
        if (!declared) { rows.push({ front, link, declared: null }); taken++; continue; }
        const imageUrl = new URL(declared, link).href;
        const image = await get(imageUrl, ACCEPT_IMAGE);
        if (!image.ok) { rows.push({ front, link, status: image.status }); taken++; continue; }
        const bytes = new Uint8Array(await image.arrayBuffer());
        rows.push({ front: new URL(front).host, bytes: bytes.byteLength, ...dimensions(bytes), link, imageUrl });
        taken++;
      } catch (error) {
        rows.push({ front, link, error: String(error).slice(0, 80) });
      }
    }
    if (links.length === 0) rows.push({ front, error: "no article links" });
  } catch (error) {
    rows.push({ front, error: String(error).slice(0, 80) });
  }
}
for (const row of rows) console.log(JSON.stringify(row));
const ok = rows.filter((r) => r.bytes);
const sorted = (k) => ok.map((r) => r[k]).filter((v) => typeof v === "number").sort((a, b) => a - b);
const q = (arr, p) => arr[Math.min(arr.length - 1, Math.floor(p * arr.length))];
for (const k of ["bytes", "width", "height"]) {
  const a = sorted(k);
  console.log(k, { n: a.length, min: a[0], p25: q(a, 0.25), median: q(a, 0.5), p75: q(a, 0.75), max: a.at(-1) });
}
console.log("formats", Object.groupBy(ok, (r) => r.format) && Object.fromEntries(Object.entries(Object.groupBy(ok, (r) => r.format)).map(([k, v]) => [k, v.length])));
