// Mirrors libs/api-server/src/http/signed-media-url.ts signMediaUrl (importKey per call, HMAC-SHA-256).
const enc = new TextEncoder();
const b64u = (bytes) =>
  btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
const key = "x".repeat(64);
async function sign(conversionId, importPerCall, cachedKey) {
  const payload = b64u(
    enc.encode(
      JSON.stringify({
        conversionId,
        principal: { kind: "account", accountId: crypto.randomUUID() },
        expiresAtMs: Date.now() + 86400000,
      }),
    ),
  );
  const k = importPerCall
    ? await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"])
    : cachedKey;
  const sig = b64u(new Uint8Array(await crypto.subtle.sign("HMAC", k, enc.encode(payload))));
  const url = new URL(`https://cup.audio/api/files/audiobooks/${conversionId}/cover-image`);
  url.searchParams.set("token", `v1.${payload}.${sig}`);
  return url.href;
}
const cachedKey = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
for (const importPerCall of [true, false]) {
  for (let w = 0; w < 2000; w++) await sign(crypto.randomUUID(), importPerCall, cachedKey);
  const rounds = 200;
  const perPage = 50;
  const t0 = performance.now();
  let len = 0;
  for (let r = 0; r < rounds; r++) {
    const urls = await Promise.all(
      Array.from({ length: perPage }, () => sign(crypto.randomUUID(), importPerCall, cachedKey)),
    );
    len = urls[0].length;
  }
  const ms = performance.now() - t0;
  console.log(
    JSON.stringify({
      importPerCall,
      perUrlMicros: +((ms * 1000) / (rounds * perPage)).toFixed(1),
      per50PageMs: +(ms / rounds).toFixed(3),
      urlLength: len,
    }),
  );
}
console.log(process.version, process.arch);
