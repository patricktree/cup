// Counts how often Chromium requests a cover image under Cup's headers when an <img> is re-rendered
// with the same URL, remounted with the same URL, or given a URL with a new token.
import { createServer } from "node:http";
import { chromium } from "/Users/pkerschbaum/workspace/cup/node_modules/.pnpm/playwright-core@1.64.0/node_modules/playwright-core/index.mjs";

// 1x1 transparent PNG.
const PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==",
  "base64",
);
const cacheControl = process.argv[2] ?? "private, no-store";
const hits = [];
const server = createServer((req, res) => {
  if (req.url.startsWith("/cover")) {
    hits.push(req.url);
    res.writeHead(200, { "Content-Type": "image/png", "Cache-Control": cacheControl, ETag: '"e1"' });
    res.end(PNG);
    return;
  }
  res.writeHead(200, { "Content-Type": "text/html", "Cache-Control": "no-store" });
  res.end("<!doctype html><div id=root></div>");
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const origin = `http://127.0.0.1:${server.address().port}`;

const browser = await chromium.launch({
  executablePath: `${process.env.HOME}/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing`,
});
const page = await browser.newPage();
await page.goto(origin);
const load = (src, replace) =>
  page.evaluate(
    ({ src, replace }) =>
      new Promise((resolve) => {
        const root = document.getElementById("root");
        let img = root.querySelector("img");
        if (!img || replace) {
          root.replaceChildren();
          img = document.createElement("img");
          root.append(img);
        }
        if (img.getAttribute("src") === src && img.complete) return resolve("unchanged");
        img.onload = () => resolve("loaded");
        img.onerror = () => resolve("error");
        img.src = src;
      }),
    { src, replace },
  );

const steps = [];
const step = async (name, fn) => {
  const before = hits.length;
  const result = await fn();
  await page.waitForTimeout(200);
  steps.push({ name, result, requests: hits.length - before });
};
await step("first render, token A", () => load("/cover?token=A", false));
await step("same element, same URL set again", () => page.evaluate(() => { const i = document.querySelector("img"); i.src = i.src; return new Promise((r) => { i.onload = () => r("loaded"); setTimeout(() => r("no load event"), 500); }); }));
await step("remount new element, same URL (token A)", () => load("/cover?token=A", true));
await step("same element, new URL (token B)", () => load("/cover?token=B", false));
await step("remount new element, earlier URL (token A)", () => load("/cover?token=A", true));
await page.reload();
await step("after page reload, token A", () => load("/cover?token=A", true));
console.log(JSON.stringify({ cacheControl, browser: browser.version(), steps }, null, 2));
await browser.close();
server.close();
