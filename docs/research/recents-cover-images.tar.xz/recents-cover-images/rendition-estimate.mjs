// Estimates card rendition sizes: downscales each sampled cover image in Chromium's canvas to a
// given width and encodes it as WebP (quality 0.8). Image bytes stay in memory.
import { readFileSync } from "node:fs";
import { createServer } from "node:http";
import { chromium } from "/Users/pkerschbaum/workspace/cup/node_modules/.pnpm/playwright-core@1.64.0/node_modules/playwright-core/index.mjs";

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";
const rows = readFileSync(process.argv[2], "utf8")
  .split("\n")
  .filter((line) => line.startsWith("{"))
  .map((line) => JSON.parse(line))
  .filter((row) => row.imageUrl);
const images = [];
for (const row of rows) {
  const response = await fetch(row.imageUrl, {
    headers: { "User-Agent": UA, Accept: "image/jpeg,image/png,image/webp,image/avif,image/gif,*/*;q=0.5" },
  });
  images.push({ row, bytes: Buffer.from(await response.arrayBuffer()), type: response.headers.get("content-type") });
}
const server = createServer((req, res) => {
  const index = Number(req.url.split("/")[2]);
  if (req.url.startsWith("/img/") && images[index]) {
    res.writeHead(200, { "Content-Type": images[index].type ?? "application/octet-stream" });
    res.end(images[index].bytes);
    return;
  }
  res.writeHead(200, { "Content-Type": "text/html" });
  res.end("<!doctype html><body></body>");
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({
  executablePath: `${process.env.HOME}/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing`,
});
const page = await browser.newPage();
await page.goto(origin);
const widths = [480, 640];
const results = [];
for (const [index, image] of images.entries()) {
  const sizes = await page.evaluate(
    async ({ src, widths }) => {
      const img = new Image();
      img.src = src;
      await img.decode();
      const out = {};
      for (const width of widths) {
        const w = Math.min(width, img.naturalWidth);
        const h = Math.round((img.naturalHeight * w) / img.naturalWidth);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", 0.8));
        out[width] = blob.size;
      }
      return out;
    },
    { src: `/img/${index}`, widths },
  );
  results.push({ host: image.row.front, original: image.bytes.length, width: image.row.width, height: image.row.height, ...Object.fromEntries(widths.map((w) => [`webp${w}`, sizes[w]])) });
}
for (const result of results) console.log(JSON.stringify(result));
const median = (values) => values.sort((a, b) => a - b)[Math.floor(values.length / 2)];
const sum = (values) => values.reduce((a, b) => a + b, 0);
console.log(
  JSON.stringify({
    n: results.length,
    medianOriginal: median(results.map((r) => r.original)),
    ...Object.fromEntries(widths.map((w) => [`medianWebp${w}`, median(results.map((r) => r[`webp${w}`]))])),
    sumOriginal: sum(results.map((r) => r.original)),
    ...Object.fromEntries(widths.map((w) => [`sumWebp${w}`, sum(results.map((r) => r[`webp${w}`]))])),
    browser: browser.version(),
  }),
);
await browser.close();
server.close();
