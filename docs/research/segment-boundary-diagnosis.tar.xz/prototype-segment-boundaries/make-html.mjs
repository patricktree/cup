// PROTOTYPE (patricktree/cup#290), throwaway, never merged: writes the listening page from page-data.json.
// Usage: node make-html.mjs <page-dir>
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const [pageDir] = process.argv.slice(2);
const runs = JSON.parse(readFileSync(join(pageDir, "page-data.json"), "utf8"));
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
const n = (x, d = 1) => (Number.isFinite(x) ? x.toFixed(d) : "–");
const signed = (x, d = 1) => (Number.isFinite(x) ? `${x >= 0 ? "+" : "−"}${Math.abs(x).toFixed(d)}` : "–");

// Level envelope, −60…0 dBFS over ±4 s, boundary in the middle.
function envSvg(pts, label) {
  const w = 320, h = 44, step = w / Math.max(1, pts.length - 1);
  const y = (d) => h - ((d + 60) / 60) * h;
  const line = pts.map((d, i) => `${(i * step).toFixed(1)},${y(d).toFixed(1)}`).join(" ");
  return `<svg class="env" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(label)}"><polygon points="0,${h} ${line} ${w},${h}" class="env-fill"></polygon><line x1="${w / 2}" x2="${w / 2}" y1="0" y2="${h}" class="env-mid"></line><line x1="0" x2="${w}" y1="${y(-45)}" y2="${y(-45)}" class="env-floor"></line></svg>`;
}

const JUMPS = ["Energy", "Intonation", "Pace", "Pause length", "Loudness", "Voice timbre"];

function boundaryCard(run, b) {
  const heading = b.group === "heading" || b.group === "after-heading";
  const c = b.cont;
  return `<article class="bnd" id="${b.id}" data-id="${b.id}" data-label="${esc(`${run.title} · ${b.index} · ${b.kind}`)}">
  <header class="bnd-head"><span class="chip chip-${b.group}">${esc(b.kind)}</span><span class="idx">chunks ${esc(b.index)}</span></header>
  <p class="seam"><span class="tail">…${esc(b.tail.replace(/\n\n/g, " ¶ "))}</span><span class="cut" aria-label="segment boundary">║</span><span class="headtxt">${esc(b.head.replace(/\n\n/g, " ¶ "))}…</span></p>
  <div class="ab">
    <div class="side">
      <button type="button" class="play" data-src="audio/${run.trackFile}" data-from="${Math.max(0, b.at - 5).toFixed(2)}" data-to="${(b.at + 5).toFixed(2)}">▶ Joined, policy 6</button>
      ${envSvg(b.envJoined, "Level across the joined boundary")}
      <dl class="m"><div><dt>Gap</dt><dd>${b.gapMs} ms</dd></div><div><dt>Trail + lead</dt><dd>${b.trailMs} + ${b.leadMs} ms</dd></div><div><dt>Level step</dt><dd>${signed(b.levelJump)} dB</dd></div><div><dt>Pitch step</dt><dd>${signed(b.f0Jump)} st</dd></div></dl>
    </div>
    <div class="side">
      <button type="button" class="play alt" data-src="audio/${run.contFile}" data-from="${c ? Math.max(0, c.at - 5).toFixed(2) : 0}" data-to="${c ? (c.at + 5).toFixed(2) : 10}">▶ Continuous reference</button>
      ${envSvg(b.envCont, "Level across the same spot in the continuous take")}
      <dl class="m">${c ? `<div><dt>Pause</dt><dd>${c.pauseMs} ms</dd></div><div><dt>&nbsp;</dt><dd>&nbsp;</dd></div><div><dt>Level step</dt><dd>${signed(c.levelJump)} dB</dd></div><div><dt>Pitch step</dt><dd>${signed(c.f0Jump)} st</dd></div>` : "<div><dt>Spot</dt><dd>not located</dd></div>"}</dl>
    </div>
  </div>
  <fieldset class="verdict"><legend>What jumps at this boundary?</legend>
    <div class="opts">${JUMPS.map((j) => `<label><input type="checkbox" id="${b.id}-${j.replace(/\s/g, "")}" data-jump="${j}"> ${j}</label>`).join("")}<label class="none"><input type="checkbox" id="${b.id}-none" data-jump="Nothing, sounds continuous"> Nothing</label></div>
    ${heading ? `<div class="opts fresh"><span>A fresh start here is</span>${["right", "wrong", "either is fine"].map((v) => `<label><input type="radio" name="${b.id}-fresh" id="${b.id}-fresh-${v.replace(/\s/g, "")}" value="${v}"> ${v}</label>`).join("")}</div>` : ""}
    <label class="note-l" for="${b.id}-note">Notes</label><textarea id="${b.id}-note" rows="2" placeholder="Optional: what you hear"></textarea>
  </fieldset>
</article>`;
}

function segTable(run) {
  return `<div class="tw"><table><thead><tr><th>Chunk</th><th>Chars</th><th>Length</th><th>Lead</th><th>Trail</th><th>LUFS</th><th>Level first 3 s</th><th>Level last 3 s</th><th>Pitch median</th><th>Pitch first 2 s</th><th>Pitch last 2 s</th><th>Chars/s</th></tr></thead><tbody>
${run.segRows.map((s) => `<tr><td>${s.index}</td><td>${s.chars}</td><td>${n(s.seconds)} s</td><td>${s.leadMs} ms</td><td>${s.trailMs} ms</td><td>${n(s.lufs)}</td><td>${n(s.levelStart)} dB</td><td>${n(s.levelEnd)} dB</td><td>${n(s.f0All, 0)} Hz</td><td>${n(s.f0Start, 0)} Hz</td><td>${n(s.f0End, 0)} Hz</td><td>${n(s.charsPerS)}</td></tr>`).join("\n")}
<tr class="ref"><td>Continuous</td><td>${run.texts.reduce((s, t) => s + t.length, 0)}</td><td>${n(run.contInfo.seconds)} s</td><td>${run.contInfo.leadMs} ms</td><td>${run.contInfo.trailMs} ms</td><td>${n(run.contInfo.lufs)}</td><td colspan="2">pauses ≥ 250 ms: ${run.contInfo.pausesOver250.join(", ")} ms</td><td>${n(run.contInfo.f0All, 0)} Hz</td><td></td><td></td><td>${n(run.contInfo.charsPerS)}</td></tr>
</tbody></table></div>`;
}

const html = `<title>Segment Boundary Diagnosis</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&family=Fraunces:opsz,wght@9..144,600&display=swap">
<style>
/* Layout: one listening column; each boundary is an A/B pair (joined vs continuous) above its verdict. */
:root{--bg:#f6f7f4;--surface:#ffffff;--fg:#1c211d;--muted:#5f6a62;--line:#dfe3dc;--accent:#1f6f5c;--alt:#8a5a14;--chip:#e7efe9;--warn:#f4ead9;
--display:"Fraunces",Georgia,serif;--text:"IBM Plex Sans",system-ui,sans-serif;--mono:"IBM Plex Mono",ui-monospace,monospace}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#121513;--surface:#1a1f1c;--fg:#e6ebe6;--muted:#97a39a;--line:#2c332e;--accent:#5cc4a6;--alt:#e0ae62;--chip:#22302a;--warn:#33291b;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#121513;--surface:#1a1f1c;--fg:#e6ebe6;--muted:#97a39a;--line:#2c332e;--accent:#5cc4a6;--alt:#e0ae62;--chip:#22302a;--warn:#33291b;color-scheme:dark}
body{background:var(--bg);color:var(--fg);font:15px/1.55 var(--text);padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:28px 64px}
main{max-width:980px;margin:0 auto;display:flex;flex-direction:column;gap:20px}
h1{font:600 30px/1.15 var(--display);margin:0;text-wrap:balance}h2{font:600 21px/1.25 var(--display);margin:28px 0 0;text-wrap:balance}
.lede{max-width:68ch;color:var(--muted);margin:0}.lede strong{color:var(--fg);font-weight:600}
.legend{display:flex;flex-wrap:wrap;gap:8px 18px;font-size:13px;color:var(--muted)}
.full{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:center}.full label{font-size:13px;color:var(--muted);display:flex;flex-direction:column;gap:4px}
audio{width:min(360px,100%);height:34px}
.tw{overflow-x:auto;border:1px solid var(--line);border-radius:6px;background:var(--surface)}
table{border-collapse:collapse;width:100%;font:13px/1.4 var(--mono);font-variant-numeric:tabular-nums;white-space:nowrap}
th,td{padding:6px 10px;text-align:right;border-bottom:1px solid var(--line)}th:first-child,td:first-child{text-align:left}th{font:600 11px/1.3 var(--text);color:var(--muted);letter-spacing:.03em;text-transform:uppercase}
tr.ref td{color:var(--muted);background:var(--chip)}tr:last-child td{border-bottom:0}
.bnd{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:16px;display:flex;flex-direction:column;gap:12px;min-width:0}
.bnd-head{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between}
.chip{font:500 12px/1 var(--text);padding:5px 8px;border-radius:999px;background:var(--chip);color:var(--accent)}.chip-heading,.chip-after-heading{background:var(--warn);color:var(--alt)}
.idx{font:12px var(--mono);color:var(--muted)}
.seam{margin:0;font-size:14px;line-height:1.5}.tail{color:var(--muted)}.cut{color:var(--accent);font-weight:600;padding:0 6px}
.ab{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}.side{display:flex;flex-direction:column;gap:8px;min-width:0}
.play{align-self:flex-start;font:500 14px var(--text);padding:8px 14px;border-radius:6px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer}
.play.alt{border-color:var(--alt);color:var(--alt)}.play[aria-pressed="true"]{background:var(--accent);color:var(--surface)}.play.alt[aria-pressed="true"]{background:var(--alt)}
.play:focus-visible,button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.env{width:100%;max-width:100%;height:44px}.env-fill{fill:var(--chip);stroke:var(--accent);stroke-width:1}.side:last-child .env-fill{stroke:var(--alt)}.env-mid{stroke:var(--fg);stroke-dasharray:2 3;stroke-width:1}.env-floor{stroke:var(--line);stroke-width:1}
.m{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:4px 10px;margin:0}.m div{min-width:0}.m dt{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.03em}.m dd{margin:0;font:13px var(--mono);font-variant-numeric:tabular-nums}
.verdict{border:0;border-top:1px solid var(--line);margin:0;padding:12px 0 0;display:flex;flex-direction:column;gap:8px}.verdict legend{font-weight:600;font-size:14px;padding:0 0 4px}
.opts{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:14px}.opts label{display:flex;gap:6px;align-items:center}.fresh span{color:var(--alt);font-weight:500}
.note-l{font-size:12px;color:var(--muted)}textarea{font:14px var(--text);color:var(--fg);background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:8px;width:100%;box-sizing:border-box;resize:vertical}
.bar{position:sticky;bottom:calc(12px + env(safe-area-inset-bottom,0px));align-self:center;display:flex;gap:10px;align-items:center;background:var(--surface);border:1px solid var(--line);border-radius:999px;padding:8px 10px 8px 16px;box-shadow:0 4px 18px rgb(0 0 0/.12);font-size:13px;color:var(--muted)}
.bar button{font:500 14px var(--text);padding:8px 14px;border-radius:999px;border:0;background:var(--accent);color:var(--surface);cursor:pointer}
#out{width:100%;font:12px var(--mono)}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
<main>
<h1>Where do segment boundaries sound like a fresh start?</h1>
<p class="lede">Prototype for <a href="https://github.com/patricktree/cup/issues/290">Where and why do segment boundaries sound like a fresh start?</a> Every segment below went through the production <code>produceAudioSegment</code> on 2026-11-12: Gemini 3.8 Flash-Lite, voice Charon, speech policy 6 with Sonic ×1.05. Each run's stored segment MP3s are joined byte for byte, as the narration track joins them. The <strong>continuous reference</strong> is the same run's text sent as one request, so you can hear how the model itself crosses those paragraph breaks.</p>
<p class="lede">Each A/B plays 5 s before and after the boundary. The continuous spot is the longest pause near the boundary's share of the text, so check by ear that it is the same place. Gap is the measured silence at the join (below −45 dBFS), including about 50 ms of MP3 padding. Level is mean speech power; pitch is the median F0 of the last 2 s before and the first 2 s after, in semitones. The split runs stand in for an oversized narration block: the fixtures have none over 2,000 characters, so one long paragraph is split at the sentence nearest its middle.</p>
<p class="lede"><strong>For each boundary, tick what jumps</strong> (and for heading boundaries, whether a fresh start belongs there), then use <em>Copy answers</em> and paste the result into the session. Your ticks stay in this browser.</p>
${runs
  .map(
    (run) => `<section aria-labelledby="h-${run.id}"><h2 id="h-${run.id}">${esc(run.title)}</h2>
<div class="full"><label>Whole run, joined (policy 6), ${n(run.joinedSeconds)} s<audio controls preload="none" src="audio/${run.trackFile}"></audio></label><label>Whole run, continuous reference, ${n(run.contInfo.seconds)} s<audio controls preload="none" src="audio/${run.contFile}"></audio></label></div>
${segTable(run)}
${run.boundaries.map((b) => boundaryCard(run, b)).join("\n")}
</section>`,
  )
  .join("\n")}
<details><summary>Answers as text</summary><textarea id="out" rows="12" readonly></textarea></details>
<div class="bar"><span id="count">0 boundaries answered</span><button type="button" id="copy">Copy answers</button></div>
</main>
<script>
const player = new Audio();
let stopAt = 0, current = null;
player.addEventListener("timeupdate", () => { if (player.currentTime >= stopAt) stop(); });
function stop(){ player.pause(); if (current) current.setAttribute("aria-pressed","false"); current = null; }
document.addEventListener("play", (e) => { if (e.target.tagName === "AUDIO") stop(); for (const a of document.querySelectorAll("audio")) if (a !== e.target) a.pause(); }, true);
for (const btn of document.querySelectorAll(".play")) btn.addEventListener("click", async () => {
  if (current === btn) { stop(); return; }
  stop(); for (const a of document.querySelectorAll("audio")) a.pause();
  const src = new URL(btn.dataset.src, location.href).href;
  if (player.src !== src) { player.src = src; await new Promise((r) => player.addEventListener("loadedmetadata", r, { once: true })); }
  player.currentTime = +btn.dataset.from; stopAt = +btn.dataset.to; current = btn; btn.setAttribute("aria-pressed","true"); player.play();
});
const KEY = "segment-boundaries-v1";
function collect(){
  return [...document.querySelectorAll(".bnd")].map((b) => ({
    label: b.dataset.label,
    jumps: [...b.querySelectorAll("input[data-jump]:checked")].map((i) => i.dataset.jump),
    fresh: b.querySelector("input[type=radio]:checked")?.value,
    note: b.querySelector("textarea").value.trim(),
  }));
}
function render(){
  const a = collect(); const done = a.filter((x) => x.jumps.length || x.fresh || x.note).length;
  document.getElementById("count").textContent = done + " of " + a.length + " boundaries answered";
  document.getElementById("out").value = a.map((x) => "- " + x.label + ": " + (x.jumps.join(", ") || "(no tick)") + (x.fresh ? "; fresh start " + x.fresh : "") + (x.note ? "; " + x.note : "")).join("\\n");
  try { localStorage.setItem(KEY, JSON.stringify(a)); } catch {}
}
try { const saved = JSON.parse(localStorage.getItem(KEY) || "[]"); for (const s of saved) { const b = [...document.querySelectorAll(".bnd")].find((x) => x.dataset.label === s.label); if (!b) continue; for (const i of b.querySelectorAll("input[data-jump]")) i.checked = s.jumps.includes(i.dataset.jump); for (const r of b.querySelectorAll("input[type=radio]")) r.checked = r.value === s.fresh; b.querySelector("textarea").value = s.note || ""; } } catch {}
document.addEventListener("input", render); render();
document.getElementById("copy").addEventListener("click", async () => {
  const text = document.getElementById("out").value;
  try { await navigator.clipboard.writeText(text); document.getElementById("count").textContent = "Copied"; }
  catch { const o = document.getElementById("out"); o.closest("details").open = true; o.select(); document.getElementById("count").textContent = "Select and copy the text above"; }
});
</script>`;
writeFileSync(join(pageDir, "index.html"), html);
console.log("wrote", join(pageDir, "index.html"));
