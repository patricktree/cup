# PROTOTYPE: segment boundaries (throwaway, never merged)

Answers [Where and why do segment boundaries sound like a fresh start?](https://github.com/patricktree/cup/issues/290), part of [Map: narration flows across segment boundaries](https://github.com/patricktree/cup/issues/288).

**Verdict (2026-11-13, operator by ear, 10 of 15 boundaries judged):** every judged boundary jumps, and the jump is prosody, not the pause. Intonation jumped at 8 of 10 and energy at 7, voice timbre (a different-sounding take) at 3; loudness at 2, both German paragraph-to-paragraph boundaries. Pause length was never ticked: the joins already pause for 570–850 ms, less than the 680–1,170 ms the model pauses between paragraphs in one continuous request. A fresh start is wrong at 6 of the 7 heading and step-title boundaries and "either is fine" at the remaining one, a paragraph into a new section's heading, so no heading boundary needs to keep sounding like a fresh start. The German mid-paragraph split jumped in intonation. The 4 Cloudflare boundaries and the English split were not judged.

## Method

Five runs of consecutive narration chunks from the narration-source-analysis eval fixtures: Anthropic 91–96, Cloudflare 56–60 and derStandard 8–12, plus Anthropic chunk 99 and derStandard chunk 13 split at the sentence nearest their middle, standing in for an oversized narration block (no fixture block exceeds 2,000 characters). Each chunk went through the production `produceAudioSegment` (Gemini 3.8 Flash-Lite, Charon, speech policy 6, Sonic ×1.05) via Cloudflare AI Gateway on 2026-11-12; each run's stored segment MP3s are joined byte for byte as the narration track joins them. Each run was also synthesized as one request (its chunks joined with blank lines) as a continuous reference. 25 requests, 12,424 characters.

Measurements per boundary: the silence at the join below −45 dBFS (including about 50 ms of MP3 padding), each side's edge silence, the step in mean speech power between the last 3 s before and the first 3 s after, and the step in median autocorrelation F0 between the last 2 s before and the first 2 s after. The same is measured at the matching pause of the continuous take, located as the longest pause near the boundary's share of the text.

## Files

- `render.mjs`: the 25 paid synthesis calls through `produceAudioSegment`, with an in-memory bucket and an AI binding stand-in that forwards to the gateway's universal endpoint.
- `build-page.mjs`: joins each run, measures every segment and boundary, and writes `summary.json` and the page data.
- `make-html.mjs`: writes the listening page (`page/index.html`, with `page/audio/`), published privately as the [Segment Boundary Diagnosis](https://claude.ai/artifact/TUfrAcXbLgio5NNzjAW9w8) artifact.
- `summary.json`: every segment's and boundary's measurements.
- `answers.md`: the operator's answers as pasted from the page.
