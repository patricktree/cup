// PROTOTYPE (patricktree/cup#290), throwaway, never merged: joins each run's segment MP3s byte for
// byte (as the narration track does), measures every boundary, and writes the listening page.
// Usage: node build-page.mjs <out-dir> <page-dir>
import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join } from "node:path";

const [outDir, pageDir] = process.argv.slice(2);
mkdirSync(join(pageDir, "audio"), { recursive: true });
const runs = JSON.parse(readFileSync(join(outDir, "runs.json"), "utf8"));
const RATE = 24_000;
const FRAME = 240; // 10 ms
const SILENCE_DB = -45;

const decode = (mp3) =>
  new Int16Array(
    Uint8Array.from(execFileSync("ffmpeg", ["-v", "error", "-i", mp3, "-f", "s16le", "-ac", "1", "-ar", String(RATE), "-"], { maxBuffer: 1 << 28 })).buffer,
  );
function measureLufs(mp3) {
  const res = execFileSync("sh", ["-c", `ffmpeg -hide_banner -nostats -i "${mp3}" -af ebur128 -f null - 2>&1 | grep -E "^\\s+I:" | tail -1`]).toString();
  return +/(-?[\d.]+) LUFS/.exec(res)?.[1];
}

// Per-10-ms frame level in dBFS.
function frameDb(pcm) {
  const out = new Float64Array(Math.floor(pcm.length / FRAME));
  for (let f = 0; f < out.length; f++) {
    let s = 0;
    for (let i = f * FRAME; i < (f + 1) * FRAME; i++) s += (pcm[i] / 32768) ** 2;
    out[f] = 10 * Math.log10(s / FRAME + 1e-12);
  }
  return out;
}
const median = (xs) => {
  const s = xs.filter(Number.isFinite).sort((a, b) => a - b);
  return s.length ? s[Math.floor(s.length / 2)] : NaN;
};
// Speech level: mean power of non-silent frames in [from, to) seconds, in dBFS.
function speechLevel(db, from, to) {
  const fr = db.slice(Math.max(0, Math.round(from * 100)), Math.round(to * 100)).filter((d) => d > SILENCE_DB);
  if (!fr.length) return NaN;
  return 10 * Math.log10(fr.reduce((s, d) => s + 10 ** (d / 10), 0) / fr.length);
}
// Autocorrelation F0 for 40 ms windows every 10 ms between 60 and 300 Hz; NaN when unvoiced.
function f0Track(pcm, db) {
  const win = 960, minLag = RATE / 300, maxLag = RATE / 60;
  const out = new Float64Array(db.length).fill(NaN);
  for (let f = 0; f < db.length; f++) {
    if (db[f] < -35) continue;
    const start = f * FRAME - win / 2;
    if (start < 0 || start + win + maxLag > pcm.length) continue;
    let e0 = 0;
    for (let i = 0; i < win; i++) e0 += pcm[start + i] ** 2;
    let best = 0, bestLag = 0;
    for (let lag = Math.floor(minLag); lag <= maxLag; lag++) {
      let c = 0, e1 = 0;
      for (let i = 0; i < win; i++) { c += pcm[start + i] * pcm[start + i + lag]; e1 += pcm[start + i + lag] ** 2; }
      const r = c / Math.sqrt(e0 * e1 + 1e-9);
      if (r > best) { best = r; bestLag = lag; }
    }
    if (best > 0.6) out[f] = RATE / bestLag;
  }
  return out;
}
const f0In = (f0, from, to) => median(Array.from(f0.slice(Math.max(0, Math.round(from * 100)), Math.round(to * 100))));
const semis = (a, b) => 12 * Math.log2(b / a);
// Silence runs (≥ minMs) as [startS, endS].
function silences(db, minMs) {
  const runs = [];
  let s = -1;
  for (let f = 0; f <= db.length; f++) {
    const silent = f < db.length && db[f] <= SILENCE_DB;
    if (silent && s < 0) s = f;
    if (!silent && s >= 0) { if ((f - s) * 10 >= minMs) runs.push([s / 100, f / 100]); s = -1; }
  }
  return runs;
}
function edges(db) {
  let a = 0; while (a < db.length && db[a] <= SILENCE_DB) a++;
  let b = db.length; while (b > 0 && db[b - 1] <= SILENCE_DB) b--;
  return { lead: a / 100, trail: (db.length - b) / 100, speechStart: a / 100, speechEnd: b / 100 };
}
// Level envelope (20 ms) of [from, to) for the inline SVG.
const envelope = (db, from, to) => {
  const pts = [];
  for (let t = from; t < to; t += 0.02) pts.push(Math.max(-60, db[Math.round(t * 100)] ?? -60));
  return pts;
};

function kindOf(run, a, b) {
  if (run.split) return { kind: "mid-paragraph split", group: "split" };
  const isTitle = (t) => t.length < 80 && !/[.!?:”"]$/.test(t.trim());
  if (b.includes("\n\n") && b.split("\n\n").every(isTitle)) return { kind: "paragraph → heading-only segment", group: "heading" };
  if (b.includes("\n\n")) return { kind: "paragraph → heading-led segment (new section)", group: "heading" };
  if (isTitle(b)) return { kind: "paragraph → step title as its own segment", group: "heading" };
  if (a.split("\n\n").every(isTitle)) return { kind: "heading- or title-only segment → paragraph", group: "after-heading" };
  if (isTitle(a)) return { kind: "step title → paragraph", group: "after-heading" };
  return { kind: "paragraph → paragraph", group: "paragraph" };
}

const page = [];
const summary = [];
for (const run of runs) {
  const segs = run.texts.map((text, i) => {
    const mp3 = join(outDir, `${run.id}-s${i}.mp3`);
    const meta = JSON.parse(readFileSync(join(outDir, `${run.id}-s${i}.json`), "utf8")).customMetadata;
    const pcm = decode(mp3);
    const db = frameDb(pcm);
    const e = edges(db);
    const f0 = f0Track(pcm, db);
    const speechS = e.speechEnd - e.speechStart;
    return {
      text, mp3, pcm, db, f0, ...e,
      durationMs: +meta["audio-duration-milliseconds"],
      lufs: measureLufs(mp3),
      level: speechLevel(db, e.speechStart, e.speechEnd),
      levelStart: speechLevel(db, e.speechStart, e.speechStart + 3),
      levelEnd: speechLevel(db, e.speechEnd - 3, e.speechEnd),
      f0All: f0In(f0, e.speechStart, e.speechEnd),
      f0Start: f0In(f0, e.speechStart, e.speechStart + 2),
      f0End: f0In(f0, e.speechEnd - 2, e.speechEnd),
      charsPerS: text.length / speechS,
    };
  });
  // The narration track: stored segment objects back to back, nothing stripped or added.
  const trackFile = `${run.id}-joined.mp3`;
  writeFileSync(join(pageDir, "audio", trackFile), Buffer.concat(segs.map((s) => readFileSync(s.mp3))));
  const contFile = `${run.id}-continuous.mp3`;
  copyFileSync(join(outDir, `${run.id}-continuous.mp3`), join(pageDir, "audio", contFile));

  const track = decode(join(pageDir, "audio", trackFile));
  const trackDb = frameDb(track);
  const cont = decode(join(pageDir, "audio", contFile));
  const contDb = frameDb(cont);
  const contF0 = f0Track(cont, contDb);
  const contEdges = edges(contDb);
  const contPauses = silences(contDb, 120).filter(([s, e]) => s > contEdges.speechStart && e < contEdges.speechEnd);

  // Locate each boundary in the continuous take: the longest pause near the character-proportional
  // position. Approximate; the page says so.
  const totalChars = run.texts.reduce((s, t) => s + t.length, 0);
  const contSpeech = contEdges.speechEnd - contEdges.speechStart;
  let offset = 0, charsBefore = 0;
  const boundaries = [];
  for (let i = 0; i < segs.length - 1; i++) {
    const a = segs[i], b = segs[i + 1];
    offset += a.durationMs / 1000;
    charsBefore += a.text.length;
    const gapRun = silences(trackDb, 10).find(([s, e]) => s <= offset + 0.2 && e >= offset - 0.2);
    const expected = contEdges.speechStart + (contSpeech * charsBefore) / totalChars;
    const near = contPauses.filter(([s, e]) => Math.abs((s + e) / 2 - expected) < 4);
    const contPause = near.sort((x, y) => y[1] - y[0] - (x[1] - x[0]))[0];
    const cp = contPause ? (contPause[0] + contPause[1]) / 2 : expected;
    const cLevelEnd = contPause ? speechLevel(contDb, contPause[0] - 3, contPause[0]) : NaN;
    const cLevelStart = contPause ? speechLevel(contDb, contPause[1], contPause[1] + 3) : NaN;
    const cF0End = contPause ? f0In(contF0, contPause[0] - 2, contPause[0]) : NaN;
    const cF0Start = contPause ? f0In(contF0, contPause[1], contPause[1] + 2) : NaN;
    const { kind, group } = kindOf(run, a.text, b.text);
    boundaries.push({
      id: `${run.id}-b${i}`,
      index: `${run.firstIndex + i} → ${run.firstIndex + i + 1}`,
      kind, group,
      tail: a.text.slice(-110), head: b.text.slice(0, 110),
      at: offset,
      gapMs: gapRun ? Math.round((gapRun[1] - gapRun[0]) * 1000) : 0,
      gap: gapRun,
      trailMs: Math.round(a.trail * 1000), leadMs: Math.round(b.lead * 1000),
      levelJump: b.levelStart - a.levelEnd,
      f0EndA: a.f0End, f0StartB: b.f0Start, f0Jump: semis(a.f0End, b.f0Start),
      cont: contPause ? { pauseMs: Math.round((contPause[1] - contPause[0]) * 1000), at: cp, levelJump: cLevelStart - cLevelEnd, f0Jump: semis(cF0End, cF0Start), f0End: cF0End, f0Start: cF0Start } : null,
      envJoined: envelope(trackDb, Math.max(0, offset - 4), offset + 4),
      envCont: envelope(contDb, Math.max(0, cp - 4), cp + 4),
    });
  }
  const segRows = segs.map((s, i) => ({
    index: run.firstIndex + i, chars: s.text.length, seconds: s.durationMs / 1000,
    leadMs: Math.round(s.lead * 1000), trailMs: Math.round(s.trail * 1000),
    lufs: s.lufs, level: s.level, levelStart: s.levelStart, levelEnd: s.levelEnd,
    f0All: s.f0All, f0Start: s.f0Start, f0End: s.f0End, charsPerS: s.charsPerS,
    text: s.text,
  }));
  const contInfo = {
    seconds: cont.length / RATE, lufs: measureLufs(join(pageDir, "audio", contFile)),
    level: speechLevel(contDb, contEdges.speechStart, contEdges.speechEnd),
    leadMs: Math.round(contEdges.lead * 1000), trailMs: Math.round(contEdges.trail * 1000),
    charsPerS: totalChars / contSpeech, f0All: f0In(contF0, contEdges.speechStart, contEdges.speechEnd),
    pausesOver250: contPauses.filter(([s, e]) => e - s >= 0.25).map(([s, e]) => Math.round((e - s) * 1000)),
  };
  const joinedSpeech = segs.reduce((s, x) => s + (x.speechEnd - x.speechStart), 0);
  page.push({ ...run, trackFile, contFile, boundaries, segRows, contInfo, joinedSeconds: track.length / RATE, joinedCharsPerS: totalChars / joinedSpeech });
  summary.push({
    run: run.id,
    joinedSeconds: +(track.length / RATE).toFixed(2), continuousSeconds: +contInfo.seconds.toFixed(2),
    joinedCharsPerS: +(totalChars / joinedSpeech).toFixed(2), continuousCharsPerS: +contInfo.charsPerS.toFixed(2),
    continuousLufs: contInfo.lufs, continuousPausesOver250Ms: contInfo.pausesOver250,
    segments: segRows.map(({ text, ...r }) => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, typeof v === "number" ? +v.toFixed(2) : v]))),
    boundaries: boundaries.map((b) => ({ index: b.index, kind: b.kind, gapMs: b.gapMs, trailMs: b.trailMs, leadMs: b.leadMs, levelJumpDb: +b.levelJump.toFixed(1), f0JumpSemitones: +b.f0Jump.toFixed(1), continuous: b.cont && { pauseMs: b.cont.pauseMs, levelJumpDb: +b.cont.levelJump.toFixed(1), f0JumpSemitones: +b.cont.f0Jump.toFixed(1) } })),
  });
}
writeFileSync(join(pageDir, "summary.json"), JSON.stringify(summary, null, 2));
writeFileSync(join(pageDir, "page-data.json"), JSON.stringify(page.map(({ ...r }) => r)));
console.log(JSON.stringify(summary.map((r) => ({ run: r.run, b: r.boundaries.map((b) => `${b.index} ${b.kind}: gap ${b.gapMs} (trail ${b.trailMs}+lead ${b.leadMs}) ΔL ${b.levelJumpDb} dB ΔF0 ${b.f0JumpSemitones} st | cont pause ${b.continuous?.pauseMs} ΔL ${b.continuous?.levelJumpDb} ΔF0 ${b.continuous?.f0JumpSemitones}`), segs: r.segments.map((s) => `${s.index}: ${s.lufs} LUFS f0 ${s.f0All} start ${s.f0Start} end ${s.f0End} ${s.charsPerS} c/s`), cont: `${r.continuousSeconds}s vs ${r.joinedSeconds}s, ${r.continuousCharsPerS} vs ${r.joinedCharsPerS} c/s, ${r.continuousLufs} LUFS, pauses ${r.continuousPausesOver250Ms}` })), null, 1));
