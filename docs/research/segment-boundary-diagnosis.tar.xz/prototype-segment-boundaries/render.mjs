// PROTOTYPE (patricktree/cup#290), throwaway, never merged: renders real fixture boundaries under
// speech policy 6 through the production `produceAudioSegment`, plus one continuous reference per run.
// Usage (from libs/audiobook-production): node prototype-segment-boundaries/render.mjs <env-file> <out-dir>
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";

import { produceAudioSegment } from "@cup/audiobook-production";

const [envFile, outDir] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
mkdirSync(outDir, { recursive: true });

const cases = new URL("../../narration-source-analysis/test/evals/cases/", import.meta.url);
const chunksOf = (name) =>
  JSON.parse(readFileSync(new URL(`${name}/expected.json`, cases), "utf8")).map((u) => u.narrationText);

// Splits one paragraph at the sentence boundary nearest its middle, as `splitNarrationBlock` would
// for an oversized narration block (the fixtures have none over 2,000 characters).
function splitAtMiddleSentence(text) {
  const ends = [...text.matchAll(/(?<=[.!?])\s+/gu)].map((m) => m.index);
  const at = ends.reduce((best, i) => (Math.abs(i - text.length / 2) < Math.abs(best - text.length / 2) ? i : best));
  return [text.slice(0, at), text.slice(at).trimStart()];
}

const anthropic = chunksOf("anthropic-demystifying-evals-for-ai-agents");
const cloudflare = chunksOf("cloudflare-kitesurf");
const derstandard = chunksOf("derstandard-source-with-navigation-noise");

export const runs = [
  { id: "en-anthropic", title: "English: Anthropic, “Demystifying evals”, chunks 91–96", language: "en", texts: anthropic.slice(91, 97), firstIndex: 91 },
  { id: "en-cloudflare", title: "English: Cloudflare, “Kitesurf”, chunks 56–60", language: "en", texts: cloudflare.slice(56, 61), firstIndex: 56 },
  { id: "de-derstandard", title: "German: derStandard, farm subsidies, chunks 8–12", language: "de-AT", texts: derstandard.slice(8, 13), firstIndex: 8 },
  { id: "en-split", title: "English: Anthropic chunk 99 split mid-paragraph", language: "en", texts: splitAtMiddleSentence(anthropic[99]), firstIndex: 99, split: true },
  { id: "de-split", title: "German: derStandard chunk 13 split mid-paragraph", language: "de-AT", texts: splitAtMiddleSentence(derstandard[13]), firstIndex: 13, split: true },
];

// Forwards the Worker AI binding's gateway call to the Cloudflare AI Gateway universal endpoint.
const ai = {
  gateway: (gatewayId) => ({
    run: async (body, options) =>
      fetch(`https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/${gatewayId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
          "cf-aig-skip-cache": "true",
          "cf-aig-collect-log-payload": "false",
          "cf-aig-metadata": JSON.stringify(options.gateway.metadata),
        },
        body: JSON.stringify([{ ...body, headers: Object.fromEntries(Object.entries(body.headers).map(([k, v]) => [k, String(v)])) }]),
        signal: options.signal,
      }),
  }),
};

// In-memory R2 stand-in; stores the segment MP3 and its metadata on disk.
function bucketFor(name) {
  return {
    head: async () => null,
    put: async (key, value, { customMetadata }) => {
      writeFileSync(join(outDir, `${name}.mp3`), value);
      writeFileSync(join(outDir, `${name}.json`), JSON.stringify({ key, customMetadata }, null, 2));
      return { key, size: value.byteLength, etag: "proto", customMetadata };
    },
  };
}

const jobs = [];
for (const run of runs) {
  run.texts.forEach((text, i) => jobs.push({ name: `${run.id}-s${i}`, text, language: run.language }));
  jobs.push({ name: `${run.id}-continuous`, text: run.texts.join("\n\n"), language: run.language });
}
console.log(`${jobs.length} requests, ${jobs.reduce((s, j) => s + j.text.length, 0)} characters`);

async function render({ name, text, language }) {
  if (existsSync(join(outDir, `${name}.mp3`))) return;
  const started = Date.now();
  try {
    await produceAudioSegment({
      ai,
      bucket: bucketFor(name),
      conversionId: "prototype-segment-boundaries",
      sequence: 0,
      narrationChunk: { text },
      narrationLanguage: language,
    });
    writeFileSync(join(outDir, `${name}.txt`), text);
    console.log(name, "ok", `${((Date.now() - started) / 1000).toFixed(1)} s`);
  } catch (error) {
    console.log(name, "FAILED", error.message);
  }
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  const queue = [...jobs];
  await Promise.all(Array.from({ length: 4 }, async () => { while (queue.length) await render(queue.shift()); }));
  writeFileSync(join(outDir, "runs.json"), JSON.stringify(runs, null, 2));
}
