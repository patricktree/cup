// Plays the joined tracks from reproduce.ts in a real Chrome through <audio src> over HTTP with
// Range support, and measures the reported duration and where seeks actually land.
//
// Usage: node chrome-check.ts <cup-checkout> <output-directory-of-reproduce.ts>
// Uses Playwright from the checkout and the locally installed Google Chrome (channel "chrome").
import fs from "node:fs";
import http from "node:http";
import { createRequire } from "node:module";
import path from "node:path";

const [repositoryRoot, outputDirectory] = process.argv.slice(2);

if (!repositoryRoot || !outputDirectory) {
  throw new Error("Usage: node chrome-check.ts <cup-checkout> <output-directory>");
}

const requireFromRepository = createRequire(path.resolve(repositoryRoot, "node_modules/.pnpm/node_modules/"));
const { chromium } = requireFromRepository("playwright-core") as typeof import("playwright-core");
const report = JSON.parse(fs.readFileSync(path.join(outputDirectory, "report.json"), "utf8"));

// A one-hour track: the 5.928 s joined sample repeated, so seeks far into the file are covered.
const joined = fs.readFileSync(path.join(outputDirectory, "joined.mp3"));
const repetitions = 608;
fs.writeFileSync(path.join(outputDirectory, "joined-long.mp3"), Buffer.concat(Array(repetitions).fill(joined)));

const server = http.createServer((request, response) => {
  if (request.url === "/") {
    response.writeHead(200, { "content-type": "text/html" }).end("<!doctype html><title>t</title>");
    return;
  }
  const file = path.join(outputDirectory, path.basename(request.url ?? ""));
  if (!file.endsWith(".mp3") || !fs.existsSync(file)) {
    response.writeHead(404).end();
    return;
  }
  const body = fs.readFileSync(file);
  const range = /bytes=(\d+)-(\d*)/.exec(request.headers.range ?? "");
  if (!range) {
    response.writeHead(200, { "content-type": "audio/mpeg", "accept-ranges": "bytes", "content-length": body.length });
    response.end(body);
    return;
  }
  const start = Number(range[1]);
  const end = range[2] ? Number(range[2]) : body.length - 1;
  response.writeHead(206, {
    "content-type": "audio/mpeg",
    "accept-ranges": "bytes",
    "content-range": `bytes ${start}-${end}/${body.length}`,
    "content-length": end - start + 1,
  });
  response.end(body.subarray(start, end + 1));
});
await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
const { port } = server.address() as { port: number };

const browser = await chromium.launch({
  channel: "chrome",
  args: ["--autoplay-policy=no-user-gesture-required"],
});
const page = await browser.newPage();
await page.goto(`http://127.0.0.1:${port}/`);

const starts = report.joined.segmentStarts as { reportedStartMilliseconds: number; firstAudibleMilliseconds: number }[];
const sampleMilliseconds = report.joined.analyzeMp3DurationMilliseconds as number;

// Seek a known lead before each segment's first audible sample (inside the previous segment's
// tone), record what the element plays, and compare the time from the first recorded sound to the
// next segment's onset with that lead. The difference is where the seek really landed.
const cases = [];
for (const [file, baseMilliseconds] of [
  ["joined.mp3", 0],
  ["joined-long.mp3", 0],
  ["joined-long.mp3", (repetitions - 3) * sampleMilliseconds],
] as const) {
  for (const [index, start] of starts.slice(1).entries()) {
    // Segment d opens with 400 ms of intended silence, so its seeks start further back to land
    // in segment c's tone. The odd extra milliseconds put the targets at different frame phases.
    for (const extra of [0, 7, 19]) {
      cases.push({
        file,
        targetOnsetMilliseconds: baseMilliseconds + start.firstAudibleMilliseconds,
        leadMilliseconds: (index === 2 ? 600 : 300) + extra,
      });
    }
  }
}

const results = await page.evaluate(async ({ cases }) => {
  const output = [];
  const durations: Record<string, number> = {};
  for (const testCase of cases) {
    const audio = new Audio(`/${testCase.file}`);
    audio.preload = "auto";
    await new Promise((resolve, reject) => {
      audio.addEventListener("loadedmetadata", resolve, { once: true });
      audio.addEventListener("error", () => reject(new Error(String(audio.error?.message))), { once: true });
    });
    durations[testCase.file] = audio.duration;
    const context = new AudioContext();
    const source = context.createMediaElementSource(audio);
    const processor = context.createScriptProcessor(1024, 1, 1);
    const recorded: number[] = [];
    let recording = false;
    processor.onaudioprocess = (event) => {
      if (recording) recorded.push(...event.inputBuffer.getChannelData(0));
    };
    source.connect(processor);
    processor.connect(context.destination);
    const seekTo = (testCase.targetOnsetMilliseconds - testCase.leadMilliseconds) / 1_000;
    audio.currentTime = seekTo;
    await new Promise((resolve) => audio.addEventListener("seeked", resolve, { once: true }));
    const currentTimeAfterSeek = audio.currentTime;
    recording = true;
    await audio.play();
    await new Promise((resolve) => setTimeout(resolve, testCase.leadMilliseconds + 500));
    audio.pause();
    recording = false;
    await context.close();
    const threshold = 300 / 32_768;
    const first = recorded.findIndex((sample) => Math.abs(sample) > threshold);
    // The next onset follows a run of at least 20 ms below the threshold.
    const minimumGap = Math.round(context.sampleRate * 0.02);
    let quiet = 0;
    let onset = -1;
    for (let index = first; index < recorded.length; index += 1) {
      if (Math.abs(recorded[index]!) > threshold) {
        if (quiet >= minimumGap) {
          onset = index;
          break;
        }
        quiet = 0;
      } else {
        quiet += 1;
      }
    }
    const measuredLead = ((onset - first) / context.sampleRate) * 1_000;
    output.push({
      file: testCase.file,
      seekToSeconds: seekTo,
      currentTimeAfterSeek,
      contextSampleRate: context.sampleRate,
      measuredLeadMilliseconds: measuredLead,
      // Positive: playback started earlier in the file than requested.
      seekErrorMilliseconds: measuredLead - testCase.leadMilliseconds,
    });
  }
  return { durations, output };
}, { cases });

const chromeReport = {
  chrome: browser.version(),
  longTrack: { repetitions, bytes: joined.length * repetitions, expectedDurationSeconds: (repetitions * sampleMilliseconds) / 1_000 },
  expectedJoinedDurationSeconds: sampleMilliseconds / 1_000,
  ...results,
};
fs.writeFileSync(path.join(outputDirectory, "chrome-report.json"), `${JSON.stringify(chromeReport, null, 2)}\n`);
console.log(JSON.stringify(chromeReport, null, 2));
await browser.close();
server.close();
