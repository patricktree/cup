// Encodes synthetic segments with Cup's real LAME WASM bridge, stores them as production does,
// joins them byte for byte, and measures frames, headers, the bit reservoir, and join gaps.
//
// Usage: node reproduce.ts <cup-checkout> <output-directory>
// Requires ffmpeg and ffprobe on PATH (measured with FFmpeg 8.0).
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const [repositoryRoot, outputDirectory] = process.argv.slice(2);

if (!repositoryRoot || !outputDirectory) {
  throw new Error("Usage: node reproduce.ts <cup-checkout> <output-directory>");
}

const { encodePcmAsMp3 } = await import(
  pathToFileURL(path.join(repositoryRoot, "libs/mp3-encoding/src/mp3-encoding.ts")).href
);
const { analyzeMp3 } = await import(
  pathToFileURL(path.join(repositoryRoot, "libs/audiobook-production/src/audio-format.ts")).href
);

const SAMPLE_RATE = 24_000;
const BITRATE = 128;
const SILENCE_THRESHOLD = 300;

// Lengths deliberately not multiples of the 576-sample frame. Each segment is a speech-like
// amplitude-modulated tone that starts and stops abruptly at full level, so its onset and end
// are measurable in the decoded output. The last one is a different tone after 400 ms silence.
const segmentSpecs = [
  { name: "a", samples: 24_000 + 137, frequency: 220, leadingSilence: 0 },
  { name: "b", samples: 56_281, frequency: 330, leadingSilence: 0 },
  { name: "c", samples: 17_003, frequency: 440, leadingSilence: 0 },
  { name: "d", samples: 30_000, frequency: 550, leadingSilence: 9_600 },
];

fs.mkdirSync(outputDirectory, { recursive: true });

const segments = [];

for (const spec of segmentSpecs) {
  const pcm = createPcm(spec);
  const encoded = await encodePcmAsMp3(pcm, {
    bitrateKilobitsPerSecond: BITRATE,
    sampleRate: SAMPLE_RATE,
  });
  // Production stores exactly the frames analyzeMp3 reports, with ID3 tags removed.
  const { audioStart, audioEnd, durationMilliseconds } = analyzeMp3(encoded);
  const stored = encoded.slice(audioStart, audioEnd);
  const frames = parseFrames(stored);
  const file = path.join(outputDirectory, `segment-${spec.name}.mp3`);
  fs.writeFileSync(file, stored);
  segments.push({ spec, pcm, encoded, stored, audioStart, audioEnd, durationMilliseconds, frames, file });
}

const joined = concat(segments.map((segment) => segment.stored));
const joinedFile = path.join(outputDirectory, "joined.mp3");
fs.writeFileSync(joinedFile, joined);

const report: Record<string, unknown> = {
  ffmpeg: execFileSync("ffmpeg", ["-version"]).toString().split("\n")[0],
  node: process.version,
  segments: segments.map((segment) => describeSegment(segment)),
};

// Start offsets the server would report: the running sum of analyzeMp3 durations.
let startMilliseconds = 0;
const starts: number[] = [];
for (const segment of segments) {
  starts.push(startMilliseconds);
  startMilliseconds += segment.durationMilliseconds;
}

const joinedFrames = parseFrames(joined);
const joinedDecoded = decode(joinedFile);
const separateDecoded = segments.map((segment) => decode(segment.file));
const separateConcatenated = concatInt16(separateDecoded);

report.joined = {
  bytes: joined.byteLength,
  frames: joinedFrames.length,
  analyzeMp3DurationMilliseconds: analyzeMp3(joined).durationMilliseconds,
  sumOfSegmentDurationsMilliseconds: startMilliseconds,
  contentLengthTimes8OverBitrateMilliseconds: (joined.byteLength * 8) / BITRATE,
  ffprobe: probe(joinedFile),
  decodedSamples: joinedDecoded.length,
  decodedMilliseconds: (joinedDecoded.length / SAMPLE_RATE) * 1_000,
  // Each reported start offset against where the segment's first audible sample decodes.
  segmentStarts: segments.map((segment, index) => {
    const startSample = Math.round((starts[index]! / 1_000) * SAMPLE_RATE);
    const onset = firstLoud(joinedDecoded, startSample + segment.spec.leadingSilence);
    return {
      segment: segment.spec.name,
      reportedStartMilliseconds: starts[index],
      firstAudibleMilliseconds: (onset / SAMPLE_RATE) * 1_000,
      firstAudibleMinusReportedMilliseconds:
        ((onset - startSample) / SAMPLE_RATE) * 1_000 - (segment.spec.leadingSilence / SAMPLE_RATE) * 1_000,
    };
  }),
  joins: segments.slice(1).map((segment, index) => {
    const previous = segments[index]!;
    const joinSample = Math.round((starts[index + 1]! / 1_000) * SAMPLE_RATE);
    const previousLastLoud = lastLoud(joinedDecoded, Math.round((starts[index]! / 1_000) * SAMPLE_RATE), joinSample);
    const nextOnset = firstLoud(joinedDecoded, joinSample);
    const window = joinedDecoded.subarray(previousLastLoud + 1, nextOnset);
    return {
      join: `${previous.spec.name}|${segment.spec.name}`,
      silentGapMilliseconds: ((nextOnset - previousLastLoud - 1) / SAMPLE_RATE) * 1_000,
      intendedGapMilliseconds: (segment.spec.leadingSilence / SAMPLE_RATE) * 1_000,
      maxAbsSampleInGap: maxAbs(window),
      maxAbsSampleStepAcrossJoin: maxStep(joinedDecoded, joinSample - 48, joinSample + 48),
    };
  }),
  // How far a joined decode differs from decoding every segment on its own and concatenating.
  maxAbsDifferenceFromSeparateDecodes: maxAbsDifference(joinedDecoded, separateConcatenated),
  separateDecodesTotalSamples: separateConcatenated.length,
};

fs.writeFileSync(path.join(outputDirectory, "report.json"), `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify(report, null, 2));

function createPcm(spec: (typeof segmentSpecs)[number]): Uint8Array {
  const total = spec.leadingSilence + spec.samples;
  const samples = new Int16Array(total);
  for (let index = 0; index < spec.samples; index += 1) {
    const time = index / SAMPLE_RATE;
    // 4 Hz syllable-rate envelope between 50 % and 100 %, so the signal never falls silent.
    const envelope = 0.75 + 0.25 * Math.sin(2 * Math.PI * 4 * time);
    samples[spec.leadingSilence + index] = Math.round(
      12_000 * envelope * Math.sin(2 * Math.PI * spec.frequency * time + Math.PI / 2),
    );
  }
  return new Uint8Array(samples.buffer);
}

type Frame = {
  offset: number;
  length: number;
  version: "MPEG-1" | "MPEG-2" | "MPEG-2.5";
  bitrateKilobits: number;
  sampleRate: number;
  padding: number;
  protection: boolean;
  mainDataBegin: number;
  mainDataSlotBytes: number;
  part23LengthBits: number;
  ascii: string;
};

function parseFrames(bytes: Uint8Array): Frame[] {
  const frames: Frame[] = [];
  let offset = 0;
  while (offset < bytes.byteLength) {
    const header = ((bytes[offset]! << 24) | (bytes[offset + 1]! << 16) | (bytes[offset + 2]! << 8) | bytes[offset + 3]!) >>> 0;
    if ((header & 0xffe0_0000) >>> 0 !== 0xffe0_0000) {
      throw new Error(`No frame sync at byte ${offset}`);
    }
    const versionBits = (header >>> 19) & 0b11;
    const protection = ((header >>> 16) & 1) === 0;
    const bitrateIndex = (header >>> 12) & 0b1111;
    const sampleRateIndex = (header >>> 10) & 0b11;
    const padding = (header >>> 9) & 1;
    const channelMode = (header >>> 6) & 0b11;
    if (versionBits === 0b11) {
      throw new Error("This script only handles the MPEG-2 LSF frames Cup produces");
    }
    const sampleRate = [22_050, 24_000, 16_000][sampleRateIndex]! / (versionBits === 0b10 ? 1 : 2);
    const bitrateKilobits = [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160][bitrateIndex]!;
    const length = Math.floor((72 * bitrateKilobits * 1_000) / sampleRate) + padding;
    // MPEG-2 LSF side information: 9 bytes mono, 17 bytes stereo (ISO/IEC 13818-3, 2.4.1.7).
    const sideInfoStart = offset + 4 + (protection ? 2 : 0);
    const sideInfoBytes = channelMode === 0b11 ? 9 : 17;
    const bits = createBitReader(bytes, sideInfoStart);
    const mainDataBegin = bits.read(8);
    bits.read(channelMode === 0b11 ? 1 : 2); // private_bits
    const part23LengthBits = bits.read(12);
    frames.push({
      offset,
      length,
      version: versionBits === 0b10 ? "MPEG-2" : "MPEG-2.5",
      bitrateKilobits,
      sampleRate,
      padding,
      protection,
      mainDataBegin,
      mainDataSlotBytes: length - 4 - (protection ? 2 : 0) - sideInfoBytes,
      part23LengthBits,
      ascii: Buffer.from(bytes.subarray(offset, offset + length)).toString("latin1").replace(/[^\x20-\x7e]/g, "."),
    });
    offset += length;
  }
  return frames;
}

function createBitReader(bytes: Uint8Array, byteOffset: number) {
  let bit = byteOffset * 8;
  return {
    read(count: number): number {
      let value = 0;
      for (let index = 0; index < count; index += 1) {
        value = (value << 1) | ((bytes[bit >> 3]! >> (7 - (bit & 7))) & 1);
        bit += 1;
      }
      return value;
    },
  };
}

function describeSegment(segment: (typeof segments)[number]) {
  const { frames } = segment;
  // A frame may borrow main data only from slots of earlier frames; inside one segment that pool
  // starts empty, so main_data_begin must never exceed the bytes already seen in this segment.
  let reservoirPool = 0;
  let maxBorrow = 0;
  let borrowsOutsideSegment = 0;
  let framesUsingReservoir = 0;
  for (const frame of frames) {
    if (frame.mainDataBegin > reservoirPool) {
      borrowsOutsideSegment += 1;
    }
    if (frame.mainDataBegin > 0) {
      framesUsingReservoir += 1;
    }
    maxBorrow = Math.max(maxBorrow, frame.mainDataBegin);
    reservoirPool += frame.mainDataSlotBytes;
  }
  const decoded = decode(segment.file);
  const onset = firstLoud(decoded, segment.spec.leadingSilence);
  const end = lastLoud(decoded, 0, decoded.length);
  const inputSamples = segment.spec.leadingSilence + segment.spec.samples;
  return {
    name: segment.spec.name,
    inputSamples,
    inputMilliseconds: (inputSamples / SAMPLE_RATE) * 1_000,
    encoderOutputBytes: segment.encoded.byteLength,
    id3Bytes: { leading: segment.audioStart, trailing: segment.encoded.byteLength - segment.audioEnd },
    storedBytes: segment.stored.byteLength,
    frames: frames.length,
    distinctFrameLengths: [...new Set(frames.map((frame) => frame.length))],
    framesWithPaddingBit: frames.filter((frame) => frame.padding === 1).length,
    framesWithCrc: frames.filter((frame) => frame.protection).length,
    distinctBitrates: [...new Set(frames.map((frame) => frame.bitrateKilobits))],
    version: [...new Set(frames.map((frame) => frame.version))],
    // A Xing/Info tag starts right after the side information (byte 13 for MPEG-2 mono), a VBRI
    // tag at byte 36. LAME also fills unused ancillary bits with its version string; that filler
    // is ordinary audio-frame content, not a tag.
    framesWithXingInfoOrVbriTag: frames.filter((frame) => isTagFrame(frame)).length,
    framesContainingLameFillerText: frames.filter((frame) => frame.ascii.includes("LAME")).length,
    firstFrameMainDataBegin: frames[0]!.mainDataBegin,
    framesUsingReservoir,
    maxMainDataBeginBytes: maxBorrow,
    framesBorrowingBytesFromBeforeSegment: borrowsOutsideSegment,
    analyzeMp3DurationMilliseconds: segment.durationMilliseconds,
    decodedSamples: decoded.length,
    decodedMinusInputSamples: decoded.length - inputSamples,
    leadingDelaySamples: onset - segment.spec.leadingSilence,
    leadingDelayMilliseconds: ((onset - segment.spec.leadingSilence) / SAMPLE_RATE) * 1_000,
    trailingSamplesAfterContent: decoded.length - 1 - end,
    trailingMilliseconds: ((decoded.length - 1 - end) / SAMPLE_RATE) * 1_000,
  };
}

function isTagFrame(frame: Frame): boolean {
  const xing = frame.ascii.slice(13, 17);
  return xing === "Xing" || xing === "Info" || frame.ascii.slice(36, 40) === "VBRI";
}

function decode(file: string): Int16Array {
  const output = execFileSync("ffmpeg", ["-v", "error", "-i", file, "-f", "s16le", "-acodec", "pcm_s16le", "-"], {
    maxBuffer: 1 << 28,
  });
  return new Int16Array(output.buffer, output.byteOffset, output.byteLength / 2);
}

function probe(file: string) {
  const output = execFileSync("ffprobe", [
    "-v", "error", "-count_packets", "-show_entries",
    "format=duration,bit_rate:stream=duration,nb_read_packets,start_time", "-of", "json", file,
  ]).toString();
  return JSON.parse(output) as unknown;
}

function firstLoud(samples: Int16Array, from: number): number {
  for (let index = Math.max(0, from); index < samples.length; index += 1) {
    if (Math.abs(samples[index]!) > SILENCE_THRESHOLD) return index;
  }
  return -1;
}

function lastLoud(samples: Int16Array, from: number, to: number): number {
  let last = -1;
  for (let index = from; index < to; index += 1) {
    if (Math.abs(samples[index]!) > SILENCE_THRESHOLD) last = index;
  }
  return last;
}

function maxAbs(samples: Int16Array): number {
  let max = 0;
  for (const sample of samples) max = Math.max(max, Math.abs(sample));
  return max;
}

function maxStep(samples: Int16Array, from: number, to: number): number {
  let max = 0;
  for (let index = from + 1; index < to; index += 1) {
    max = Math.max(max, Math.abs(samples[index]! - samples[index - 1]!));
  }
  return max;
}

function maxAbsDifference(left: Int16Array, right: Int16Array): number {
  let max = 0;
  for (let index = 0; index < Math.min(left.length, right.length); index += 1) {
    max = Math.max(max, Math.abs(left[index]! - right[index]!));
  }
  return max;
}

function concat(parts: Uint8Array[]): Uint8Array {
  const result = new Uint8Array(parts.reduce((sum, part) => sum + part.byteLength, 0));
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.byteLength;
  }
  return result;
}

function concatInt16(parts: Int16Array[]): Int16Array {
  const result = new Int16Array(parts.reduce((sum, part) => sum + part.length, 0));
  let offset = 0;
  for (const part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
