// Asks AVFoundation, the media engine behind Safari's <audio> on macOS and iOS, for the joined
// tracks' duration, and decodes from seek targets to see where its MP3 parser maps a time.
// This is a proxy, not Safari: WebKit plays through AVPlayer, which this script does not drive.
//
// Usage: swift avfoundation-check.swift <output-directory-of-reproduce.ts>
import AVFoundation
import Foundation

let outputDirectory = CommandLine.arguments[1]
let report = try JSONSerialization.jsonObject(
  with: Data(contentsOf: URL(fileURLWithPath: outputDirectory + "/report.json"))) as! [String: Any]
let joined = report["joined"] as! [String: Any]
let starts = (joined["segmentStarts"] as! [[String: Any]]).map { $0["firstAudibleMilliseconds"] as! Double }
let sampleMilliseconds = joined["analyzeMp3DurationMilliseconds"] as! Double
let longRepetitions = 608.0

func duration(_ file: String, precise: Bool) async throws -> Double {
  let asset = AVURLAsset(
    url: URL(fileURLWithPath: outputDirectory + "/" + file),
    options: [AVURLAssetPreferPreciseDurationAndTimingKey: precise])
  return try await asset.load(.duration).seconds
}

func playerItemDuration(_ file: String) async throws -> Double {
  // WebKit's MediaPlayerPrivateAVFoundationObjC reports AVPlayerItem.duration once it is ready.
  let item = AVPlayerItem(url: URL(fileURLWithPath: outputDirectory + "/" + file))
  let player = AVPlayer(playerItem: item)
  player.isMuted = true
  for _ in 0..<200 where item.status != .readyToPlay {
    try await Task.sleep(nanoseconds: 20_000_000)
  }
  return item.duration.seconds
}

// Decodes from (onset - lead) and returns the measured lead minus the requested one.
func seekError(_ file: String, onsetMilliseconds: Double, leadMilliseconds: Double) async throws -> Double {
  let asset = AVURLAsset(url: URL(fileURLWithPath: outputDirectory + "/" + file))
  let track = try await asset.loadTracks(withMediaType: .audio)[0]
  let reader = try AVAssetReader(asset: asset)
  let start = CMTime(seconds: (onsetMilliseconds - leadMilliseconds) / 1_000, preferredTimescale: 24_000)
  reader.timeRange = CMTimeRange(start: start, duration: CMTime(seconds: 1.2, preferredTimescale: 24_000))
  let output = AVAssetReaderTrackOutput(
    track: track,
    outputSettings: [
      AVFormatIDKey: kAudioFormatLinearPCM, AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false,
      AVLinearPCMIsBigEndianKey: false, AVNumberOfChannelsKey: 1, AVSampleRateKey: 24_000,
    ])
  reader.add(output)
  reader.startReading()
  var samples: [Int16] = []
  while let buffer = output.copyNextSampleBuffer(), let block = CMSampleBufferGetDataBuffer(buffer) {
    var length = 0
    var pointer: UnsafeMutablePointer<CChar>?
    CMBlockBufferGetDataPointer(block, atOffset: 0, lengthAtOffsetOut: nil, totalLengthOut: &length, dataPointerOut: &pointer)
    pointer!.withMemoryRebound(to: Int16.self, capacity: length / 2) {
      samples.append(contentsOf: UnsafeBufferPointer(start: $0, count: length / 2))
    }
  }
  let threshold: Int16 = 300
  guard let first = samples.firstIndex(where: { abs($0) > threshold }) else { return .nan }
  var quiet = 0
  for index in first..<samples.count {
    if abs(samples[index]) > threshold {
      if quiet >= 480 { return Double(index - first) / 24 - leadMilliseconds }
      quiet = 0
    } else {
      quiet += 1
    }
  }
  return .nan
}

var result: [String: Any] = [
  "macOS": ProcessInfo.processInfo.operatingSystemVersionString,
  "expectedSeconds": ["joined.mp3": sampleMilliseconds / 1_000, "joined-long.mp3": sampleMilliseconds * longRepetitions / 1_000],
]
var durations: [String: Any] = [:]
for file in ["joined.mp3", "joined-long.mp3"] {
  durations[file] = [
    "asset": try await duration(file, precise: false),
    "assetPrecise": try await duration(file, precise: true),
    "playerItem": try await playerItemDuration(file),
  ]
}
result["durations"] = durations

var seeks: [[String: Any]] = []
for (file, base) in [("joined.mp3", 0.0), ("joined-long.mp3", (longRepetitions - 3) * sampleMilliseconds)] {
  for (index, onset) in starts.dropFirst().enumerated() {
    for extra in [0.0, 7, 19] {
      let lead = (index == 2 ? 600 : 300) + extra
      seeks.append([
        "file": file, "seekToSeconds": (base + onset - lead) / 1_000,
        "seekErrorMilliseconds": try await seekError(file, onsetMilliseconds: base + onset, leadMilliseconds: lead),
      ])
    }
  }
}
result["assetReaderSeeks"] = seeks

let data = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
try data.write(to: URL(fileURLWithPath: outputDirectory + "/avfoundation-report.json"))
print(String(data: data, encoding: .utf8)!)
