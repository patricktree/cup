// Measures the speech-level step across every pause longer than 400 ms in a 24 kHz mono s16le PCM
// file: mean power of voiced 20 ms frames in the 3 s before against the 3 s after.
// Usage: node steps.mjs <pcm-file>
import { readFileSync } from "node:fs";

const buf = readFileSync(process.argv[2]);
const samples = new Int16Array(buf.buffer, buf.byteOffset, buf.length / 2);
const RATE = 24000;
const FRAME = RATE / 50;
const db = [];
for (let i = 0; i + FRAME <= samples.length; i += FRAME) {
  let sum = 0;
  for (let j = i; j < i + FRAME; j++) sum += (samples[j] / 32768) ** 2;
  db.push(10 * Math.log10(sum / FRAME + 1e-12));
}
const silent = db.map((d) => d < -45);
const pauses = [];
for (let i = 0; i < silent.length; ) {
  if (!silent[i]) { i++; continue; }
  let j = i;
  while (j < silent.length && silent[j]) j++;
  if ((j - i) * 20 >= 400 && i > 0 && j < silent.length) pauses.push({ start: i, end: j });
  i = j;
}
const level = (from, to) => {
  const voiced = db.slice(Math.max(0, from), Math.min(db.length, to)).filter((d) => d > -45);
  return 10 * Math.log10(voiced.reduce((s, d) => s + 10 ** (d / 10), 0) / voiced.length);
};
const rows = pauses.map((p) => ({
  atS: +(p.start / 50).toFixed(1),
  pauseMs: (p.end - p.start) * 20,
  stepDb: +(level(p.end, p.end + 150) - level(p.start - 150, p.start)).toFixed(2),
}));
console.log(`duration ${(samples.length / RATE).toFixed(1)} s, pauses >= 400 ms: ${rows.length}`);
for (const r of rows) console.log(`${r.atS}\t${r.pauseMs}\t${r.stepDb}`);
const abs = rows.map((r) => Math.abs(r.stepDb)).sort((a, b) => a - b);
console.log("median |step|", abs[Math.floor(abs.length / 2)], "max", abs.at(-1));
