// Transcribes the long take with Workers AI Whisper (word timestamps), finds where each narration
// chunk (paragraph) starts, and measures the level and median F0 step across each paragraph pause:
// 3 s of voiced frames before against 3 s after (level), 2 s before against 2 s after (F0).
// Usage: node paragraph-steps.mjs <env-file> <out-dir> <label>
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const [envFile, outDir, label] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
const meta = JSON.parse(readFileSync(join(outDir, `${label}.json`), "utf8"));
const wordsPath = join(outDir, `${label}-words.json`);
let words;
if (existsSync(wordsPath)) words = JSON.parse(readFileSync(wordsPath, "utf8"));
else {
  const mp3 = readFileSync(join(outDir, `${label}.mp3`));
  const res = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/openai/whisper-large-v3-turbo`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.CLOUDFLARE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ audio: mp3.toString("base64"), language: "en" }),
    },
  );
  const json = await res.json();
  if (!res.ok) throw new Error(`whisper ${res.status} ${JSON.stringify(json).slice(0, 300)}`);
  words = json.result.segments.flatMap((s) => s.words ?? []);
  writeFileSync(wordsPath, JSON.stringify(words));
}

// Align each paragraph's first words with the transcript by searching a normalized word sequence.
const norm = (s) => s.toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}]/gu, "");
const heard = words.map((w) => norm(w.word));
let cursor = 0;
const starts = meta.texts.map((t, i) => {
  const probe = t.split(/\s+/).map(norm).filter(Boolean).slice(0, 3);
  for (let j = cursor; j < heard.length; j++) {
    if (probe.every((p, k) => heard[j + k] === p)) {
      cursor = j + 1;
      return { paragraph: 80 + i, wordIndex: j, start: words[j].start, prevEnd: j > 0 ? words[j - 1].end : 0 };
    }
  }
  return { paragraph: 80 + i, wordIndex: null };
});

const buf = readFileSync(join(outDir, `${label}.pcm`));
const s = new Int16Array(buf.buffer, buf.byteOffset, buf.length / 2);
const RATE = 24000;
const FRAME = 480;
const db = [];
for (let i = 0; i + FRAME <= s.length; i += FRAME) {
  let sum = 0;
  for (let j = i; j < i + FRAME; j++) sum += (s[j] / 32768) ** 2;
  db.push(10 * Math.log10(sum / FRAME + 1e-12));
}
const level = (fromS, toS) => {
  const v = db.slice(Math.max(0, Math.round(fromS * 50)), Math.round(toS * 50)).filter((d) => d > -45);
  return 10 * Math.log10(v.reduce((a, d) => a + 10 ** (d / 10), 0) / v.length);
};
// Autocorrelation F0 per 40 ms frame between 70 and 300 Hz, voiced frames only.
function f0(fromS, toS) {
  const out = [];
  for (let t = fromS; t + 0.04 <= toS; t += 0.02) {
    const a = Math.round(t * RATE);
    const n = Math.round(0.04 * RATE);
    let energy = 0;
    for (let j = a; j < a + n; j++) energy += s[j] * s[j];
    if (10 * Math.log10(energy / n / 32768 ** 2 + 1e-12) < -35) continue;
    let best = 0;
    let bestLag = 0;
    for (let lag = Math.round(RATE / 300); lag <= Math.round(RATE / 70); lag++) {
      let c = 0;
      for (let j = a; j < a + n - lag; j++) c += s[j] * s[j + lag];
      if (c > best) { best = c; bestLag = lag; }
    }
    if (best / energy > 0.5) out.push(RATE / bestLag);
  }
  out.sort((x, y) => x - y);
  return out[Math.floor(out.length / 2)];
}
const rows = starts.slice(1).map((st) => {
  if (st.wordIndex == null) return { ...st };
  return {
    paragraph: st.paragraph,
    atS: +st.start.toFixed(1),
    wordIndex: st.wordIndex,
    pauseMs: Math.round((st.start - st.prevEnd) * 1000),
    levelStepDb: +(level(st.start, st.start + 3) - level(st.prevEnd - 3, st.prevEnd)).toFixed(2),
    f0StepHz: +(f0(st.start, st.start + 2) - f0(st.prevEnd - 2, st.prevEnd)).toFixed(1),
  };
});
console.log(`whisper words ${words.length}, text words ${meta.words}`);
console.table(rows);
writeFileSync(join(outDir, `${label}-paragraph-steps.json`), JSON.stringify(rows, null, 2));
