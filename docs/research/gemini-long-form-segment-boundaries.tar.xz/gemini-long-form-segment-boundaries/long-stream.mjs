// Probe for patricktree/cup#319: does one long Gemini 3.8 Flash-Lite TTS request run as several
// internal invocations, and does the usage report them? Writes PCM and full JSON (minus audio).
// Usage: node long-request.mjs <env-file> <repo-root> <out-dir> <first-chunk> <last-chunk> [label]
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const [envFile, repoRoot, outDir, first, last, label = "long"] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
mkdirSync(outDir, { recursive: true });

const chunks = JSON.parse(
  readFileSync(
    join(repoRoot, "libs/narration-source-analysis/test/evals/cases/anthropic-demystifying-evals-for-ai-agents/expected.json"),
    "utf8",
  ),
).map((u) => u.narrationText);
const texts = chunks.slice(Number(first), Number(last) + 1);
const text = texts.join("\n\n");
const words = text.split(/\s+/).filter(Boolean).length;

const body = [
  {
    provider: "google-ai-studio",
    endpoint: "v1beta/interactions",
    headers: { "Api-Revision": "2026-05-20", "Content-Type": "application/json", "cf-aig-collect-log-payload": "false" },
    query: {
      model: "gemini-3.8-flash-lite-tts",
      input: [
        {
          type: "user_input",
          content: [
            { type: "text", text, annotations: [{ type: "speech_metadata", style: "Read in English with standard English pronunciation." }] },
          ],
        },
      ],
      response_format: { type: "audio", mime_type: "audio/l16", sample_rate: 24000 },
      generation_config: { speech_config: [{ voice: "Charon", language: "en" }] },
      stream: true,
    },
  },
];
const started = Date.now();
const res = await fetch(`https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/default`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
    "cf-aig-skip-cache": "true",
    "cf-aig-collect-log-payload": "false",
    "cf-aig-metadata": JSON.stringify({ conversionId: "research-gemini-long-form-seams" }),
  },
  body: JSON.stringify(body),
  signal: AbortSignal.timeout(300_000),
});
const json = await readSse(res);
const elapsed = Date.now() - started;
let pcmBytes = 0;
for (const step of json.steps ?? []) {
  for (const c of step.content ?? []) {
    if (c.type === "audio" && c.data) {
      const pcm = Buffer.from(c.data, "base64");
      pcmBytes += pcm.length;
      writeFileSync(join(outDir, `${label}.pcm`), pcm);
      c.data = `<${pcm.length} bytes>`;
    }
  }
}
writeFileSync(join(outDir, `${label}.json`), JSON.stringify({ status: res.status, elapsed, words, chars: text.length, texts, response: json }, null, 2));
console.log(JSON.stringify({ status: res.status, elapsed, words, chars: text.length, seconds: pcmBytes / 48000, usage: json.usage, topKeys: Object.keys(json) }, null, 2));

// Reads the SSE body, recording each audio delta's arrival time and size, and returns a response-shaped object.
async function readSse(res) {
  const decoder = new TextDecoder();
  let buffer = "";
  const arrivals = [];
  const pcmParts = [];
  let usage;
  const eventTypes = {};
  const samples = [];
  console.error("content-type", res.headers.get("content-type"));
  for await (const chunk of res.body) {
    if (!globalThis.seen) { globalThis.seen = 1; console.error(JSON.stringify(decoder.decode(chunk.slice(0, 400), { stream: false }))); }
    buffer += decoder.decode(chunk, { stream: true }).replace(/\r\n/g, "\n");
    let index;
    while ((index = buffer.indexOf("\n\n")) !== -1) {
      const raw = buffer.slice(0, index);
      buffer = buffer.slice(index + 2);
      const data = raw.split("\n").filter((l) => l.startsWith("data:")).map((l) => l.slice(5).trim()).join("");
      if (!data || data === "[DONE]") continue;
      const event = JSON.parse(data);
      eventTypes[event.event_type] = (eventTypes[event.event_type] ?? 0) + 1;
      if (event.delta?.data) {
        const pcm = Buffer.from(event.delta.data, "base64");
        arrivals.push({ ms: Date.now() - started, bytes: pcm.length });
        pcmParts.push(pcm);
      } else if (samples.length < 6) {
        samples.push(JSON.stringify(event).slice(0, 600));
      }
      const u = event.interaction?.usage ?? event.usage;
      if (u) usage = u;
    }
  }
  writeFileSync(join(outDir, `${label}-arrivals.json`), JSON.stringify(arrivals));
  console.error(JSON.stringify(eventTypes), samples.join("\n"));
  return { usage, eventTypes, steps: [{ content: [{ type: "audio", data: Buffer.concat(pcmParts).toString("base64") }] }] };
}
