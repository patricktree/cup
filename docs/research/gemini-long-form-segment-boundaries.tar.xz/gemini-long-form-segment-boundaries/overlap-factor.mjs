// Estimates overlap and cut's extra synthesized text (a proxy for audio) per eval fixture when each
// request speaks its neighbours' edge sentences, for today's one-chunk-per-request and for requests
// that group consecutive narration chunks up to a character budget.
// Usage: node overlap-factor.mjs <repo-root>
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const casesDir = join(process.argv[2], "libs/narration-source-analysis/test/evals/cases");
const firstSentence = (t) => (t.match(/^[\s\S]*?[.!?](?=\s|$)/u)?.[0] ?? t).trim();
const lastSentence = (t) => {
  const ends = [...t.matchAll(/(?<=[.!?:])\s+/gu)].map((m) => m.index + m[0].length);
  return t.slice(ends.filter((i) => i < t.length - 1).at(-1) ?? 0).trim();
};

function group(chunks, budget) {
  if (budget === 0) return chunks;
  const out = [];
  let current = "";
  for (const c of chunks) {
    if (current && current.length + 2 + c.length > budget) {
      out.push(current);
      current = c;
    } else current = current ? `${current}\n\n${c}` : c;
  }
  if (current) out.push(current);
  return out;
}

function factor(segments) {
  let own = 0;
  let spoken = 0;
  segments.forEach((s, i) => {
    own += s.length;
    spoken += s.length;
    if (i > 0) spoken += lastSentence(segments[i - 1]).length;
    if (i < segments.length - 1) spoken += firstSentence(segments[i + 1]).length;
  });
  return { requests: segments.length, factor: +(spoken / own).toFixed(2) };
}

const totals = {};
for (const name of readdirSync(casesDir)) {
  const chunks = JSON.parse(readFileSync(join(casesDir, name, "expected.json"), "utf8")).map((u) => u.narrationText);
  const row = { name, chunks: chunks.length, chars: chunks.join("").length };
  for (const budget of [0, 2000, 4000, 6000]) {
    const r = factor(group(chunks, budget));
    row[`b${budget}`] = `${r.requests} req, ×${r.factor}`;
    totals[budget] ??= { own: 0, spoken: 0 };
  }
  console.log(JSON.stringify(row));
}
