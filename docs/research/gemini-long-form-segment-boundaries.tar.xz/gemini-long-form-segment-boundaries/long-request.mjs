// Probe for patricktree/cup#319: does one long Gemini 3.8 Flash-Lite TTS request run as several
// internal invocations, and does the usage report them? Writes PCM and full JSON (minus audio).
// Usage: node long-request.mjs <env-file> <repo-root> <out-dir> <first-chunk> <last-chunk> [label]
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const [envFile, repoRoot, outDir, first, last, label = "long"] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
mkdirSync(outDir, { recursive: true });

const chunks = JSON.parse(
  readFileSync(
    join(repoRoot, "libs/narration-source-analysis/test/evals/cases/anthropic-demystifying-evals-for-ai-agents/expected.json"),
    "utf8",
  ),
).map((u) => u.narrationText);
const texts = chunks.slice(Number(first), Number(last) + 1);
const text = texts.join("\n\n");
const words = text.split(/\s+/).filter(Boolean).length;

const body = [
  {
    provider: "google-ai-studio",
    endpoint: "v1beta/interactions",
    headers: { "Api-Revision": "2026-05-20", "Content-Type": "application/json", "cf-aig-collect-log-payload": "false" },
    query: {
      model: "gemini-3.8-flash-lite-tts",
      input: [
        {
          type: "user_input",
          content: [
            { type: "text", text, annotations: [{ type: "speech_metadata", style: "Read in English with standard English pronunciation." }] },
          ],
        },
      ],
      response_format: { type: "audio", mime_type: "audio/l16", sample_rate: 24000 },
      generation_config: { speech_config: [{ voice: "Charon", language: "en" }] },
      stream: false,
    },
  },
];
const started = Date.now();
const res = await fetch(`https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/default`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
    "cf-aig-skip-cache": "true",
    "cf-aig-collect-log-payload": "false",
    "cf-aig-metadata": JSON.stringify({ conversionId: "research-gemini-long-form-seams" }),
  },
  body: JSON.stringify(body),
  signal: AbortSignal.timeout(300_000),
});
const json = await res.json();
const elapsed = Date.now() - started;
let pcmBytes = 0;
for (const step of json.steps ?? []) {
  for (const c of step.content ?? []) {
    if (c.type === "audio" && c.data) {
      const pcm = Buffer.from(c.data, "base64");
      pcmBytes += pcm.length;
      writeFileSync(join(outDir, `${label}.pcm`), pcm);
      c.data = `<${pcm.length} bytes>`;
    }
  }
}
writeFileSync(join(outDir, `${label}.json`), JSON.stringify({ status: res.status, elapsed, words, chars: text.length, texts, response: json }, null, 2));
console.log(JSON.stringify({ status: res.status, elapsed, words, chars: text.length, seconds: pcmBytes / 48000, usage: json.usage, topKeys: Object.keys(json) }, null, 2));
