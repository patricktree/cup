// Research probe (patricktree/cup#316): one short block through synthesis, Whisper and Gemini 3.5
// Transcribe in several request shapes, to settle the request shapes before the full run.
// Usage: node smoke.mjs <env-file> <out-dir>
import { writeFileSync, mkdirSync } from "node:fs";
import { loadEnv, synthesize, whisper, geminiTranscribe, toMp3, toWav } from "./lib.mjs";

loadEnv(process.argv[2]);
const out = process.argv[3];
mkdirSync(out, { recursive: true });
const text = "In 2024, Dr. Smith's team at the U.S. NIH spent $3.5 million.\n\nResults\n\nThe e.g. 42% improvement held at 10:30 a.m. on 1 May.";
const s = await synthesize(text, "en");
writeFileSync(`${out}/smoke.pcm`, s.pcm);
console.log("tts", s.ms, "ms", s.pcm.length / 48000, "s", JSON.stringify(s.usage));
const mp3 = toMp3(s.pcm);
const wav = toWav(s.pcm);
const w = await whisper(mp3, "en");
console.log("whisper", w.ms, w.text, JSON.stringify(w.words.slice(0, 4)));
const record = { text, tts: { ms: s.ms, usage: s.usage }, whisper: w, gemini: [] };
for (const [m, a, lc] of [["audio/mp3", mp3, ["en-US"]], ["audio/wav", wav, ["en-US"]], ["audio/mp3", mp3, undefined], ["audio/mp3", mp3, ["en"]]]) {
  try {
    const g = await geminiTranscribe(a, m, lc);
    record.gemini.push({ mime: m, languageCodes: lc, ...g });
    console.log("gemini", m, lc, g.ms, g.text, JSON.stringify(g.words.slice(0, 4)), JSON.stringify(g.usage), g.words.length);
  } catch (e) {
    record.gemini.push({ mime: m, languageCodes: lc, error: e.message });
    console.log("gemini", m, lc, "ERR", e.message);
  }
}
writeFileSync(`${out}/smoke.json`, JSON.stringify(record, null, 2));
