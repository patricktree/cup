// Research probe (patricktree/cup#316): for each selected segment, synthesizes its overlap block once
// (previous chunk's last sentence + narration chunk + next chunk's first sentence), finds both cuts
// with each candidate aligner, and transcribes every distinct cut segment with Whisper and with
// Gemini 3.5 Transcribe to check which words it speaks. Paid calls; reruns skip finished segments.
// Usage: node render.mjs <env-file> <segments.json> <out-dir> [concurrency]
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { loadEnv, synthesize, whisper, geminiTranscribe, toMp3, frameDb, tokens, alignedCut, silenceCut, RATE } from "./lib.mjs";

const [envFile, segmentsFile, outDir, concurrency = "5"] = process.argv.slice(2);
loadEnv(envFile);
mkdirSync(outDir, { recursive: true });
const segments = JSON.parse(readFileSync(segmentsFile, "utf8"));
const LOCALE = { en: "en-US", de: "de-DE", fr: "fr-FR" };

export const METHODS = ["whisper", "gemini", "silence1.5", "silence3"];

async function render(s) {
  const done = join(outDir, `${s.id}.json`);
  if (existsSync(done)) return JSON.parse(readFileSync(done, "utf8"));
  const pcmPath = join(outDir, `${s.id}.pcm`);
  let tts;
  if (existsSync(pcmPath)) tts = { pcm: readFileSync(pcmPath), ...JSON.parse(readFileSync(`${pcmPath}.json`, "utf8")) };
  else {
    tts = await synthesize(s.block, s.language);
    writeFileSync(pcmPath, tts.pcm);
    writeFileSync(`${pcmPath}.json`, JSON.stringify({ usage: tts.usage, ms: tts.ms, logId: tts.logId }));
  }
  const pcm = tts.pcm;
  const providerSeconds = pcm.length / 2 / RATE;
  const mp3 = toMp3(pcm);
  writeFileSync(join(outDir, `${s.id}.mp3`), mp3);
  const db = frameDb(pcm);

  const [w, g] = await Promise.all([whisper(mp3, s.language), geminiTranscribe(mp3, "audio/mp3", [LOCALE[s.language]])]);
  const startWord = tokens(s.tail).length;
  const endWord = startWord + tokens(s.own).length;
  const startChar = s.tail.length + s.sepBefore.length;
  const endChar = startChar + s.own.length;
  const cuts = {
    whisper: [alignedCut(w.words, db, s.block, startWord), alignedCut(w.words, db, s.block, endWord)],
    gemini: [alignedCut(g.words, db, s.block, startWord), alignedCut(g.words, db, s.block, endWord)],
    "silence1.5": [silenceCut(db, s.block, startChar, 1.5), silenceCut(db, s.block, endChar, 1.5)],
    silence3: [silenceCut(db, s.block, startChar, 3), silenceCut(db, s.block, endChar, 3)],
  };

  // Verify each distinct cut segment once (cuts within 20 ms of each other cut the same pause).
  const verified = [];
  const verification = {};
  for (const m of METHODS) {
    const [a, z] = cuts[m];
    let v = verified.find((x) => Math.abs(x.a - a.at) < 0.02 && Math.abs(x.z - z.at) < 0.02);
    if (!v) {
      const cut = pcm.subarray(Math.round(a.at * RATE) * 2, Math.max(Math.round(a.at * RATE) * 2, Math.round(z.at * RATE) * 2));
      const seconds = cut.length / 2 / RATE;
      if (seconds < 0.2) {
        // Both cuts landed in the same pause (or crossed): nothing of the chunk is left.
        v = { a: a.at, z: z.at, method: m, empty: true, seconds };
      } else {
        const cutMp3 = toMp3(cut);
        writeFileSync(join(outDir, `${s.id}-${m}.mp3`), cutMp3);
        const settle = (p) => p.then((x) => x, (e) => ({ error: e.message.slice(0, 300) }));
        const [vw, vg] = await Promise.all([settle(whisper(cutMp3, s.language)), settle(geminiTranscribe(cutMp3, "audio/mp3", [LOCALE[s.language]], { timestamps: false }))]);
        v = { a: a.at, z: z.at, method: m, whisper: { text: vw.text, ms: vw.ms, error: vw.error }, gemini: { text: vg.text, ms: vg.ms, usage: vg.usage, error: vg.error }, seconds };
      }
      verified.push(v);
    }
    verification[m] = { sameAs: v.method === m ? undefined : v.method, ...(v.method === m ? v : {}) };
  }

  const record = {
    id: s.id, language: s.language, kind: s.kind, features: s.features, tail: s.tail, own: s.own, lead: s.lead, block: s.block,
    providerSeconds, synthesis: { ms: tts.ms, usage: tts.usage, logId: tts.logId },
    aligners: {
      whisper: { ms: w.ms, text: w.text, words: w.words },
      gemini: { ms: g.ms, text: g.text, words: g.words, usage: g.usage, logId: g.logId },
    },
    cuts, verification,
  };
  writeFileSync(done, JSON.stringify(record, null, 2));
  return record;
}

const queue = [...segments];
let failed = 0;
await Promise.all(
  Array.from({ length: Number(concurrency) }, async () => {
    while (queue.length) {
      const s = queue.shift();
      const started = Date.now();
      try {
        const r = await render(s);
        console.log(s.id, "ok", `${((Date.now() - started) / 1000).toFixed(1)} s`, `${r.providerSeconds.toFixed(1)} s audio`);
      } catch (error) {
        failed++;
        console.log(s.id, "FAILED", error.message.slice(0, 300));
      }
    }
  }),
);
console.log(failed ? `${failed} failed` : "all done");
