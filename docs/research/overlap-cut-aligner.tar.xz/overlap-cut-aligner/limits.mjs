// Research probe (patricktree/cup#316): sends ever longer audio to Whisper and to Gemini 3.5
// Transcribe, built by concatenating provider audio render.mjs already synthesized (no new
// synthesis), to find where request size or audio length stops either aligner. Paid calls.
// Usage: node limits.mjs <env-file> <render-out-dir> <out-file>
import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { loadEnv, whisper, geminiTranscribe, toMp3, RATE } from "./lib.mjs";

const [envFile, dir, outFile] = process.argv.slice(2);
loadEnv(envFile);
const english = readdirSync(dir).filter((f) => f.endsWith(".pcm") && /^(anthropic|wikipedia-en|cloudflare)/.test(f)).sort();
const pool = Buffer.concat(english.map((f) => readFileSync(join(dir, f))));
const results = [];
for (const [aligner, minutes] of [["whisper", 3], ["gemini", 3], ["whisper", 10], ["gemini", 10], ["whisper", 20]]) {
  const bytes = Math.min(pool.length, minutes * 60 * RATE * 2);
  const mp3 = toMp3(pool.subarray(0, bytes));
  const entry = { aligner, minutes: bytes / 2 / RATE / 60, mp3Bytes: mp3.length, base64Bytes: Math.ceil(mp3.length / 3) * 4 };
  try {
    const r = aligner === "whisper" ? await whisper(mp3, "en") : await geminiTranscribe(mp3, "audio/mp3", ["en-US"]);
    Object.assign(entry, { ok: true, ms: r.ms, words: r.words.length, lastWordEnd: r.words.at(-1)?.end, usage: r.usage });
  } catch (error) {
    Object.assign(entry, { ok: false, error: error.message.slice(0, 400) });
  }
  console.log(JSON.stringify(entry));
  results.push(entry);
}
writeFileSync(outFile, JSON.stringify(results, null, 2));
