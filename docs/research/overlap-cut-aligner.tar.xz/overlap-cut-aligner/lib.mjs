// Research probe (patricktree/cup#316), throwaway: shared helpers for synthesizing overlap blocks,
// transcribing them with Whisper or Gemini 3.5 Transcribe, and cutting them.
import { readFileSync, writeFileSync, mkdtempSync, rmSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join } from "node:path";
import { tmpdir } from "node:os";

export const RATE = 24_000;

export function loadEnv(envFile) {
  for (const line of readFileSync(envFile, "utf8").split("\n")) {
    const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
    if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}

const GATEWAY = () => `https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/default`;
const gatewayHeaders = (tag) => ({
  "Content-Type": "application/json",
  "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
  "cf-aig-skip-cache": "true",
  "cf-aig-collect-log-payload": "false",
  "cf-aig-metadata": JSON.stringify({ conversionId: `research-overlap-cut-aligner-${tag}` }),
});

async function withRetries(label, fn) {
  for (let attempt = 1; ; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt >= 4 || error.permanent) throw error;
      console.log(`  retry ${label} after: ${error.message.slice(0, 160)}`);
      await new Promise((r) => setTimeout(r, 4000 * attempt));
    }
  }
}

// The production request shape of policy 6 (synthesize-gemini-audio.ts), sent over REST.
export async function synthesize(text, language) {
  const name = new Intl.DisplayNames(["en"], { type: "language" }).of(language.split("-")[0]);
  const body = [
    {
      provider: "google-ai-studio",
      endpoint: "v1beta/interactions",
      headers: { "Api-Revision": "2026-05-20", "Content-Type": "application/json", "cf-aig-collect-log-payload": "false" },
      query: {
        model: "gemini-3.8-flash-lite-tts",
        input: [
          {
            type: "user_input",
            content: [
              { type: "text", text, annotations: [{ type: "speech_metadata", style: `Read in ${name} with standard ${name} pronunciation.` }] },
            ],
          },
        ],
        response_format: { type: "audio", mime_type: "audio/l16", sample_rate: RATE },
        generation_config: { speech_config: [{ voice: "Charon", language }] },
        stream: false,
      },
    },
  ];
  return withRetries("synthesis", async () => {
    const started = Date.now();
    const res = await fetch(GATEWAY(), { method: "POST", headers: gatewayHeaders("tts"), body: JSON.stringify(body), signal: AbortSignal.timeout(180_000) });
    const json = await res.json().catch(() => ({}));
    const data = json.steps?.flatMap((s) => s.content ?? []).find((c) => c.type === "audio")?.data;
    if (!res.ok || !data) throw new Error(`synthesis ${res.status}: ${JSON.stringify(json).slice(0, 300)}`);
    return { pcm: Buffer.from(data, "base64"), usage: json.usage, ms: Date.now() - started, logId: res.headers.get("cf-aig-log-id") };
  });
}

export async function whisper(mp3, language) {
  return withRetries("whisper", async () => {
    const started = Date.now();
    const res = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/openai/whisper-large-v3-turbo`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${process.env.CLOUDFLARE_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ audio: Buffer.from(mp3).toString("base64"), language: language.split("-")[0] }),
        signal: AbortSignal.timeout(180_000),
      },
    );
    const json = await res.json().catch(() => ({}));
    if (!res.ok || !json.result) {
      const e = new Error(`whisper ${res.status}: ${JSON.stringify(json).slice(0, 300)}`);
      e.permanent = res.status === 400 || res.status === 413;
      throw e;
    }
    const words = json.result.segments.flatMap((s) => s.words ?? []).map((w) => ({ word: w.word, start: w.start, end: w.end }));
    return { text: json.result.text, words, info: json.result.transcription_info, ms: Date.now() - started };
  });
}

// Gemini 3.5 Transcribe with word timestamps, inline audio, through the AI Gateway Universal Endpoint.
export async function geminiTranscribe(audio, mimeType, languageCodes, { timestamps = true } = {}) {
  const body = [
    {
      provider: "google-ai-studio",
      endpoint: "v1beta/interactions",
      headers: { "Content-Type": "application/json", "cf-aig-collect-log-payload": "false" },
      query: {
        model: "gemini-3.5-transcribe",
        input: [{ type: "audio", data: Buffer.from(audio).toString("base64"), mime_type: mimeType }],
        generation_config: {
          transcription_config: {
            ...(languageCodes ? { language_codes: languageCodes } : {}),
            ...(timestamps ? { mode: { type: "verbatim", timestamp_granularities: ["word"] } } : {}),
          },
        },
      },
    },
  ];
  return withRetries("transcribe", async () => {
    const started = Date.now();
    const res = await fetch(GATEWAY(), { method: "POST", headers: gatewayHeaders("transcribe"), body: JSON.stringify(body), signal: AbortSignal.timeout(180_000) });
    const json = await res.json().catch(() => ({}));
    const content = json.steps?.flatMap((s) => s.content ?? []).filter((c) => c.type === "text") ?? [];
    if (!res.ok || content.length === 0) {
      const e = new Error(`transcribe ${res.status}: ${JSON.stringify(json).slice(0, 400)}`);
      e.permanent = res.status === 400;
      throw e;
    }
    const sec = (s) => (typeof s === "string" ? parseFloat(s) : s);
    const words = content
      .flatMap((c) => c.annotations ?? [])
      .filter((a) => a.type === "word_info")
      .map((a) => ({ word: a.text, start: sec(a.start_offset), end: sec(a.end_offset) }));
    return { text: content.map((c) => c.text).join(" "), words, usage: json.usage, ms: Date.now() - started, logId: res.headers.get("cf-aig-log-id") };
  });
}

function ffmpeg(args, input) {
  const dir = mkdtempSync(join(tmpdir(), "oca-"));
  try {
    const inPath = join(dir, "in.pcm");
    writeFileSync(inPath, input);
    const outPath = join(dir, `out.${args.ext}`);
    execFileSync("ffmpeg", ["-hide_banner", "-loglevel", "error", "-f", "s16le", "-ar", String(RATE), "-ac", "1", "-i", inPath, ...args.codec, outPath]);
    return readFileSync(outPath);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
export const toMp3 = (pcm) => ffmpeg({ ext: "mp3", codec: ["-c:a", "libmp3lame", "-b:a", "128k"] }, pcm);
export const toWav = (pcm) => ffmpeg({ ext: "wav", codec: [] }, pcm);

export function frameDb(pcm) {
  const view = new Int16Array(pcm.buffer, pcm.byteOffset, Math.floor(pcm.byteLength / 2));
  const out = new Float64Array(Math.floor(view.length / 240));
  for (let f = 0; f < out.length; f++) {
    let s = 0;
    for (let i = f * 240; i < (f + 1) * 240; i++) s += (view[i] / 32768) ** 2;
    out[f] = 10 * Math.log10(s / 240 + 1e-12);
  }
  return out;
}

// Silent runs (10 ms frames ≤ −45 dBFS), as [startFrame, endFrame) pairs.
export function silentRuns(db, from = 0, to = db.length) {
  const runs = [];
  let s = -1;
  for (let f = Math.max(0, from); f <= Math.min(to, db.length); f++) {
    const silent = f < Math.min(to, db.length) && db[f] <= -45;
    if (silent && s < 0) s = f;
    if (!silent && s >= 0) { runs.push([s, f]); s = -1; }
  }
  return runs;
}

export const norm = (s) => s.toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}]/gu, "");
export const tokens = (s) => s.split(/\s+/u).map(norm).filter(Boolean);

// Longest-common-subsequence alignment of two token arrays: pairs [i, j] of equal tokens.
export function lcsPairs(a, b) {
  const L = Array.from({ length: a.length + 1 }, () => new Int32Array(b.length + 1));
  for (let i = a.length - 1; i >= 0; i--) for (let j = b.length - 1; j >= 0; j--) L[i][j] = a[i] && a[i] === b[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const pairs = [];
  for (let i = 0, j = 0; i < a.length && j < b.length; ) {
    if (a[i] === b[j]) { pairs.push([i, j]); i++; j++; } else if (L[i + 1][j] >= L[i][j + 1]) i++; else j++;
  }
  return pairs;
}

// The prototype's cut (prototype-segment-boundary-approaches/render.mjs `cutAt`): aligns the
// transcript's words with the block's words, takes the largest inter-word gap between the last
// matched word before text word `boundary` and the first matched word at or after it, and cuts in
// the middle of the longest silence around that gap.
export function alignedCut(words, db, blockText, boundary) {
  const a = tokens(blockText);
  const b = words.map((w) => norm(w.word));
  const pairs = lcsPairs(a, b);
  const before = pairs.filter(([i]) => i < boundary).at(-1)?.[1] ?? 0;
  const after = pairs.find(([i]) => i >= boundary)?.[1] ?? words.length - 1;
  let best = null;
  for (let j = Math.max(1, before + 1); j <= Math.max(1, after); j++) {
    const gap = words[j].start - words[j - 1].end;
    if (!best || gap > best.gap) best = { j, gap };
  }
  const from = Math.floor((words[best.j - 1].end - 0.25) * 100);
  const to = Math.ceil((words[best.j].start + 0.25) * 100);
  const run = silentRuns(db, from, to).reduce((x, r) => (!x || r[1] - r[0] > x[1] - x[0] ? r : x), null);
  const at = run ? (run[0] + run[1]) / 2 / 100 : (words[best.j - 1].end + words[best.j].start) / 2;
  return { at, silenceMs: run ? (run[1] - run[0]) * 10 : 0, matchedBefore: pairs.filter(([i]) => i < boundary).at(-1)?.[0] === boundary - 1, matchedAfter: pairs.find(([i]) => i >= boundary)?.[0] === boundary, gapMs: Math.round(best.gap * 1000) };
}

// Cutting on silence alone: estimates the boundary's time from the share of characters spoken
// before it and cuts in the middle of the longest silence within ± `windowS` of that estimate.
export function silenceCut(db, blockText, boundaryChar, windowS) {
  const seconds = db.length / 100;
  // Trim the provider's edge silence from the estimate's time base.
  const voiced = [...db].map((d, i) => [d, i]).filter(([d]) => d > -45);
  const t0 = (voiced[0]?.[1] ?? 0) / 100, t1 = (voiced.at(-1)?.[1] ?? db.length) / 100;
  const expected = t0 + (t1 - t0) * (boundaryChar / blockText.length);
  const from = Math.max(Math.round(t0 * 100) + 1, Math.round((expected - windowS) * 100));
  const to = Math.min(Math.round(t1 * 100) - 1, Math.round((expected + windowS) * 100));
  const run = silentRuns(db, from, to).reduce((x, r) => (!x || r[1] - r[0] > x[1] - x[0] ? r : x), null);
  return { at: run ? (run[0] + run[1]) / 2 / 100 : expected, silenceMs: run ? (run[1] - run[0]) * 10 : 0, expected, seconds };
}
