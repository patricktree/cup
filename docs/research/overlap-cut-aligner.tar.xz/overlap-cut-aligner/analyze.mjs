// Research probe (patricktree/cup#316): checks, for every cut segment render.mjs verified, whether
// its transcripts speak exactly its own narration chunk at both edges, and summarizes accuracy,
// latency and cost per aligner. No paid calls.
// Usage: node analyze.mjs <out-dir> [judgements.json] > summary.json
import { readFileSync, readdirSync, existsSync } from "node:fs";
import { join } from "node:path";
import { norm, lcsPairs } from "./lib.mjs";

const [outDir, judgementsFile] = process.argv.slice(2);
const judgements = judgementsFile && existsSync(judgementsFile) ? JSON.parse(readFileSync(judgementsFile, "utf8")) : {};
const METHODS = ["whisper", "gemini", "silence1.5", "silence3"];
const records = readdirSync(outDir)
  .filter((f) => f.endsWith(".json") && !f.endsWith(".pcm.json"))
  .map((f) => JSON.parse(readFileSync(join(outDir, f), "utf8")))
  .sort((a, b) => a.id.localeCompare(b.id));

// Classifies the start and end edge of one transcript of a cut segment against tail | own | lead.
// The transcript is aligned with the chunk's words alone (longest common subsequence), then the
// words before the first and after the last aligned chunk word are compared with the overlap
// sentences. "repeat": overlap words are spoken; "skip": chunk edge words are missing and nothing
// stands in for them; "substituted": missing chunk words with other words in their place (a number
// or unit spoken differently); "extra": unknown words at the edge (a cut word, an insertion).
const checkTokens = (s) => s.replace(/\[\d+\]/gu, " ").split(/[\s\-‐–—]+/u).map(norm).filter(Boolean);
export function edges(transcript, r) {
  const A = checkTokens(r.tail).slice(-8), O = checkTokens(r.own), Z = checkTokens(r.lead).slice(0, 8);
  const v = checkTokens(transcript);
  const pairs = lcsPairs(O, v);
  if (pairs.length === 0) return { start: "skip", end: "skip", detail: "no chunk word" };
  const [firstO, firstV] = pairs[0];
  const [lastO, lastV] = pairs.at(-1);
  const leading = v.slice(0, firstV), trailing = v.slice(lastV + 1);
  const startRepeat = lcsPairs(A, leading).length, endRepeat = lcsPairs(Z, trailing).length;
  const startSkipped = firstO, endSkipped = O.length - 1 - lastO;
  const side = (repeat, skipped, extra) => (repeat > 0 ? "repeat" : skipped > 0 ? (extra > 0 ? "substituted" : "skip") : extra > 0 ? "extra" : "clean");
  return {
    start: side(startRepeat, startSkipped, leading.length),
    end: side(endRepeat, endSkipped, trailing.length),
    detail: { leading: leading.join(" "), startSkipped: O.slice(0, startSkipped).join(" "), trailing: trailing.join(" "), endSkipped: O.slice(lastO + 1).join(" "), matched: pairs.length, own: O.length },
  };
}

// Both verifiers agree, or one hears exactly the chunk's edge and the other only spells it differently.
const combine = (a, b) => (a === b ? a : [a, b].includes("clean") && [a, b].every((x) => ["clean", "substituted", "extra"].includes(x)) ? "clean*" : "disagree");

const rows = [];
for (const r of records) {
  for (const m of METHODS) {
    const v = r.verification[m].sameAs ? r.verification[r.verification[m].sameAs] : r.verification[m];
    const key = (edge) => `${r.id}:${m}:${edge}`;
    let start, end, detail;
    if (v.empty) {
      start = end = "empty";
    } else {
      const ew = edges(v.whisper.text ?? "", r);
      const eg = edges(v.gemini.text ?? "", r);
      start = combine(ew.start, eg.start);
      end = combine(ew.end, eg.end);
      detail = { whisper: ew, gemini: eg };
    }
    for (const [edge, verdict] of [["start", start], ["end", end]]) {
      const judged = judgements[key(edge)] ?? judgements[`${r.id}:*:${edge}:${r.cuts[m][edge === "start" ? 0 : 1].at.toFixed(2)}`];
      rows.push({ id: r.id, language: r.language, kind: r.kind, features: r.features, method: m, edge, at: r.cuts[m][edge === "start" ? 0 : 1].at, auto: verdict, verdict: judged?.verdict ?? verdict, note: judged?.note, detail, transcripts: v.empty ? undefined : { whisper: v.whisper.text, gemini: v.gemini.text } });
    }
  }
}

const tally = (list) => list.reduce((t, x) => ((t[x.verdict] = (t[x.verdict] ?? 0) + 1), t), {});
const summary = { segments: records.length, cutsPerMethod: records.length * 2, byMethod: {}, byMethodLanguage: {}, byMethodKind: {} };
for (const m of METHODS) {
  const mine = rows.filter((x) => x.method === m);
  summary.byMethod[m] = tally(mine);
  for (const l of ["en", "de", "fr"]) summary.byMethodLanguage[`${m}:${l}`] = tally(mine.filter((x) => x.language === l));
  for (const k of ["paragraph", "split", "long"]) summary.byMethodKind[`${m}:${k}`] = tally(mine.filter((x) => x.kind === k));
}

// Latency and usage.
const sum = (f) => records.reduce((n, r) => n + f(r), 0);
const providerSeconds = sum((r) => r.providerSeconds);
const verifiedSeconds = sum((r) => METHODS.reduce((n, m) => n + (r.verification[m].sameAs || r.verification[m].empty ? 0 : r.verification[m].seconds), 0));
const tok = (u, key, modality) => (u?.[key] ?? []).filter((x) => x.modality === modality).reduce((n, x) => n + x.tokens, 0);
summary.usage = {
  providerSeconds,
  verifiedSeconds,
  ttsTextIn: sum((r) => tok(r.synthesis.usage, "input_tokens_by_modality", "text")),
  ttsAudioOut: sum((r) => tok(r.synthesis.usage, "output_tokens_by_modality", "audio")),
  transcribeAudioIn: sum((r) => tok(r.aligners.gemini.usage, "input_tokens_by_modality", "audio")),
  transcribeTextOut: sum((r) => r.aligners.gemini.usage?.total_output_tokens ?? 0),
  verifyTranscribeAudioIn: sum((r) => METHODS.reduce((n, m) => n + tok(r.verification[m].gemini?.usage, "input_tokens_by_modality", "audio"), 0)),
  verifyTranscribeTextOut: sum((r) => METHODS.reduce((n, m) => n + (r.verification[m].gemini?.usage?.total_output_tokens ?? 0), 0)),
};
const pct = (xs, p) => { const s = [...xs].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
const lat = (f) => { const xs = records.map(f); return { median: pct(xs, 0.5), p90: pct(xs, 0.9), max: Math.max(...xs) }; };
summary.latencyMs = {
  synthesis: lat((r) => r.synthesis.ms),
  whisper: lat((r) => r.aligners.whisper.ms),
  gemini: lat((r) => r.aligners.gemini.ms),
  whisperPerAudioMinute: lat((r) => r.aligners.whisper.ms / (r.providerSeconds / 60)),
  geminiPerAudioMinute: lat((r) => r.aligners.gemini.ms / (r.providerSeconds / 60)),
};
const longest = records.reduce((a, r) => (r.providerSeconds > a.providerSeconds ? r : a));
summary.longest = { id: longest.id, ownChars: longest.own.length, blockChars: longest.block.length, providerSeconds: longest.providerSeconds, synthesisMs: longest.synthesis.ms, whisperMs: longest.aligners.whisper.ms, geminiMs: longest.aligners.gemini.ms };
summary.rows = rows.filter((x) => x.verdict !== "clean");
console.log(JSON.stringify(summary, null, 2));
