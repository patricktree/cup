// Research probe (patricktree/cup#316): picks the narration chunks whose overlap-and-cut edges are
// hardest for an aligner (numbers, abbreviations, names, headings, mid-paragraph splits) from the
// narration-source-analysis eval fixtures, and writes segments.json.
// Usage (from the repository root): node docs/research/overlap-cut-aligner/select.mjs <out-file>
import { readFileSync, writeFileSync } from "node:fs";

const cases = new URL("../../../libs/narration-source-analysis/test/evals/cases/", import.meta.url);
const units = (name) => JSON.parse(readFileSync(new URL(`${name}/expected.json`, cases), "utf8")).map((u) => u.narrationText);

// As in render.mjs of the boundary-approaches prototype.
export const firstSentence = (t) => (t.match(/^[\s\S]*?[.!?](?=\s|$)/u)?.[0] ?? t).trim();
export const lastSentence = (t) => {
  const ends = [...t.matchAll(/(?<=[.!?:])\s+/gu)].map((m) => m.index + m[0].length);
  return t.slice(ends.filter((i) => i < t.length - 1).at(-1) ?? 0).trim();
};
const firstWords = (t, n) => t.split(/\s+/u).slice(0, n).join(" ");
const lastWords = (t, n) => t.split(/\s+/u).slice(-n).join(" ");

const NUMBER = /\d/u;
const ABBREVIATION = /\b(?:[A-ZÄÖÜ]{2,}s?|[A-Za-z]\.[A-Za-z]\.|Dr\.|Mr\.|Mrs\.|St\.|Nr\.|bzw\.|ca\.|etc\.|z\. ?B\.|d\. ?h\.|u\. ?a\.|vs\.|Jh\.|M\.)(?=\W|$)/u;
const NAME = /(?<=[a-zäöüß,;:]\s)[A-ZÄÖÜ][a-zäöüß]+/u; // a capitalized word mid-sentence (weak in German)
const isHeading = (t) => !/[.!?:"”»)]$/u.test(t.trim()) && t.length < 120;
const startsWithHeading = (t) => t.includes("\n\n") && isHeading(t.split("\n\n")[0]);

function features(prev, own, next) {
  // The words an aligner must place at each edge: the overlap sentence's end and the chunk's start,
  // the chunk's end and the overlap sentence's start.
  const startEdge = `${lastWords(lastSentence(prev), 6)} ${firstWords(own, 6)}`;
  const endEdge = `${lastWords(own, 6)} ${firstWords(firstSentence(next), 6)}`;
  const f = new Set();
  for (const edge of [startEdge, endEdge]) {
    if (NUMBER.test(edge)) f.add("number");
    if (ABBREVIATION.test(edge)) f.add("abbreviation");
    if (NAME.test(edge)) f.add("name");
  }
  if (isHeading(prev) || isHeading(own) || isHeading(next) || startsWithHeading(own) || startsWithHeading(next)) f.add("heading");
  return [...f];
}

function splitAtMiddleSentence(text) {
  const ends = [...text.matchAll(/(?<=[.!?])\s+/gu)].map((m) => m.index);
  if (ends.length === 0) return undefined;
  const at = ends.reduce((best, i) => (Math.abs(i - text.length / 2) < Math.abs(best - text.length / 2) ? i : best));
  return [text.slice(0, at), text.slice(at).trimStart()];
}

const FIXTURES = [
  { name: "anthropic-demystifying-evals-for-ai-agents", language: "en", take: 11 },
  { name: "cloudflare-kitesurf", language: "en", take: 8 },
  { name: "wikipedia-en-ich-bin-ein-berliner", language: "en", take: 7 },
  { name: "derstandard-source-with-navigation-noise", language: "de", take: 8 },
  { name: "wikipedia-de-ich-bin-ein-berliner", language: "de", take: 9 },
  { name: "wikipedia-fr-sherlock-holmes", language: "fr", take: 6 },
];

const segments = [];
for (const fixture of FIXTURES) {
  const u = units(fixture.name);
  const candidates = [];
  for (let i = 1; i < u.length - 1; i++) {
    if (u[i].length > 1300) continue; // long chunks get their own probe below
    const f = features(u[i - 1], u[i], u[i + 1]);
    candidates.push({ i, f, score: f.length + (f.includes("heading") ? 0.5 : 0) + (f.includes("number") ? 0.5 : 0) });
  }
  // Highest score first, no two picks adjacent, so the sample covers more of the article.
  candidates.sort((a, b) => b.score - a.score || a.i - b.i);
  const picked = [];
  for (const c of candidates) {
    if (picked.length >= fixture.take) break;
    if (picked.some((p) => Math.abs(p.i - c.i) < 2)) continue;
    picked.push(c);
  }
  for (const { i, f } of picked.sort((a, b) => a.i - b.i)) {
    segments.push({ id: `${fixture.name.split("-").slice(0, 2).join("-")}-u${i}`, fixture: fixture.name, language: fixture.language, kind: "paragraph", features: f, prev: u[i - 1], own: u[i], next: u[i + 1], sepBefore: "\n\n", sepAfter: "\n\n" });
  }
}

// Mid-paragraph boundaries: an oversized narration block split into narration chunks; the two
// halves meet with a space, and each is one segment with the other half as its overlap.
for (const [name, language, i] of [
  ["anthropic-demystifying-evals-for-ai-agents", "en", 0],
  ["wikipedia-en-ich-bin-ein-berliner", "en", 0],
  ["derstandard-source-with-navigation-noise", "de", 0],
  ["wikipedia-de-ich-bin-ein-berliner", "de", 0],
]) {
  const u = units(name);
  const longest = u.map((t, k) => [t.length, k]).filter(([, k]) => k > 0 && k < u.length - 1).sort((a, b) => b[0] - a[0])[i][1];
  const [a, b] = splitAtMiddleSentence(u[longest]);
  const base = `${name.split("-").slice(0, 2).join("-")}-u${longest}`;
  segments.push({ id: `${base}a`, fixture: name, language, kind: "split", features: features(u[longest - 1], a, b), prev: u[longest - 1], own: a, next: b, sepBefore: "\n\n", sepAfter: " " });
  segments.push({ id: `${base}b`, fixture: name, language, kind: "split", features: features(a, b, u[longest + 1]), prev: a, own: b, next: u[longest + 1], sepBefore: " ", sepAfter: "\n\n" });
}

// The longest narration chunk Cup makes is 2,000 characters (MAX_CHUNK_CHARACTERS in
// narration-chunking.ts): two adjacent long units joined as one paragraph, plus overlap.
{
  const name = "wikipedia-en-ich-bin-ein-berliner";
  const u = units(name);
  const k = u.findIndex((t) => t.length === Math.max(...u.map((x) => x.length)));
  let own = u[k];
  let j = k + 1;
  while (own.length + 1 + u[j].length <= 2000 && j < u.length - 2) own = `${own} ${u[j++]}`;
  if (own.length < 1900) {
    // pad from the following unit at a sentence end
    const extra = u[j].split(/(?<=[.!?])\s+/u);
    while (extra.length && own.length + 1 + extra[0].length <= 2000) own = `${own} ${extra.shift()}`;
  }
  segments.push({ id: `wikipedia-en-long`, fixture: name, language: "en", kind: "long", features: features(u[k - 1], own, u[j + 1]), prev: u[k - 1], own, next: u[j + 1], sepBefore: "\n\n", sepAfter: "\n\n" });
}

for (const s of segments) {
  s.tail = lastSentence(s.prev);
  s.lead = firstSentence(s.next);
  s.block = `${s.tail}${s.sepBefore}${s.own}${s.sepAfter}${s.lead}`;
}
writeFileSync(process.argv[2], JSON.stringify(segments, null, 2));
const count = (p) => segments.filter(p).length;
console.log(`${segments.length} segments, ${segments.length * 2} cuts; en ${count((s) => s.language === "en")}, de ${count((s) => s.language === "de")}, fr ${count((s) => s.language === "fr")}`);
for (const f of ["number", "abbreviation", "name", "heading"]) console.log(f, count((s) => s.features.includes(f)));
console.log("block chars", segments.reduce((n, s) => n + s.block.length, 0), "longest own", Math.max(...segments.map((s) => s.own.length)), "longest block", Math.max(...segments.map((s) => s.block.length)));
