// Computes ms of narration audio per character of narration text from archived research runs and
// local development conversions. Reads data only; makes no API calls.
// Usage: node analyze.mjs <extracted-archives-dir> <db-copies-dir> <r2-copies-dir> <r2-blobs-dir>
import { execFileSync } from "node:child_process";
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const [xDir, dbDir, r2Dir, blobsDir] = process.argv.slice(2);
const readJson = (p) => JSON.parse(readFileSync(p, "utf8"));

/** @type {{source:string, model:string, policy:string, lang:string, kind:string, text:string, chars:number, ms:number, id:string}[]} */
const rows = [];

function classify(text) {
  const t = text.trim();
  if (/^(Gerald John|Gerald John and)/.test(t) && t.length < 60) return "names-only";
  if (t.length < 90 && !/\n/.test(t)) return "heading-only";
  if (/\n\n/.test(t) && t.split("\n\n")[0].length < 100) return "heading+body";
  return "body";
}

// 1. Gemini 3.8 comparison (2026-09-30): no language, no style (policy-4 request shape).
const cmpDir = join(xDir, "gemini-3.8-tts-comparison/gemini-3.8-tts-comparison");
const caseLang = (id) => (id.startsWith("derstandard") ? "de" : "en");
for (const r of readJson(join(cmpDir, "gemini-results.json")).results) {
  rows.push({
    source: "3.8-comparison",
    model: r.model,
    policy: "4-shape",
    lang: caseLang(r.caseId),
    kind: classify(r.input),
    text: r.input,
    chars: r.input.length,
    ms: r.audioSeconds * 1000,
    id: `${r.caseId}#${r.chunkIndex}`,
  });
}
// Baselines (3.1, Eleven, Speechify), excerpt totals only.
const baseline = readJson(join(cmpDir, "baseline-results.json"));
const baselineSummary = JSON.stringify(baseline).slice(0, 400);

// 2. Narration-language-by-ear prototype (2026-11-09): Flash-Lite, Charon, 2 takes per variant.
const protoDir = join(xDir, "narration-language-by-ear/prototype-narration-language");
const src = readFileSync(join(protoDir, "synthesize.mjs"), "utf8");
const texts = {};
for (const m of src.matchAll(/\{ id: "([^"]+)", text: "((?:[^"\\]|\\.)*)" \}/g)) {
  texts[m[1]] = texts[m[1]] ?? [];
  texts[m[1]].push(m[2]);
}
// Segment ids collide only for "title" and "byline" (one per article): first is de, second en.
const segText = (article, seg) => {
  if (seg === "lead+byline") return `${segText("de", "lead")}\n\n${segText("de", "byline")}`;
  if (seg === "title+byline") return `${segText("en", "title")}\n\n${segText("en", "byline")}`;
  const list = texts[seg];
  return list.length === 1 ? list[0] : list[article === "de" ? 0 : 1];
};
for (const file of readdirSync(join(protoDir, "out")).filter((f) => f.endsWith(".mp3"))) {
  const [article, seg, variant, take] = file.replace(/\.mp3$/, "").split("--");
  const text = segText(article, seg);
  const seconds = Number(
    execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", join(protoDir, "out", file)], { encoding: "utf8" }).trim(),
  );
  rows.push({
    source: "by-ear-prototype",
    model: "gemini-3.8-flash-lite-tts",
    policy: variant === "code+style" ? "5-shape" : variant === "none" ? "4-shape" : `other:${variant}`,
    lang: article,
    kind: classify(text),
    text,
    chars: text.length,
    ms: seconds * 1000,
    id: `${article}/${seg}/${take}`,
  });
}

// 3. Language probes (2026-11-09), Flash-Lite, two runs.
for (const dir of ["gemini-3.8-tts-language/gemini-3.8-tts-language"]) {
  for (const f of readdirSync(join(xDir, dir)).filter((f) => f.endsWith(".json") && !f.includes("transcript"))) {
    const r = readJson(join(xDir, dir, f));
    if (!r.audioSeconds) continue;
    const text = r.request.input[0].content[0].text;
    const sc = r.request.generation_config.speech_config[0];
    const style = r.request.input[0].content[0].annotations?.[0]?.style;
    rows.push({
      source: "3.8-language-probes",
      model: r.request.model,
      policy: !sc.language && !style ? "4-shape" : `other:${sc.language ?? ""}${style ? "+style" : ""}`,
      lang: /Korrespondent/.test(text) ? "de" : "de",
      kind: classify(text),
      text,
      chars: text.length,
      ms: r.audioSeconds * 1000,
      id: r.id,
    });
  }
}
for (const file of ["results.json", "results-followup.json"]) {
  const data = readJson(join(xDir, "gemini-tts-language/gemini-tts-language", file));
  for (const r of data.results) {
    if (!r.audioSeconds) continue;
    const text = r.text ?? r.request.input[0].content[0].text;
    const sc = r.request.generation_config?.speech_config?.[0] ?? {};
    const style = r.request.input?.[0]?.content?.[0]?.annotations?.[0]?.style;
    const isPolicy5 =
      sc.language && style && /^Read in \w+ with standard \w+ pronunciation\.$/.test(style);
    rows.push({
      source: `tts-language-${file.replace(".json", "")}`,
      model: r.request.model ?? data.model,
      policy: !sc.language && !style ? "4-shape" : isPolicy5 ? "5-shape" : `other:${sc.language ?? ""}${style ? "+style" : ""}`,
      lang: /^(The|Austria|Asked|Reporting)/.test(text) ? "en" : "de",
      kind: classify(text),
      text,
      chars: text.length,
      ms: r.audioSeconds * 1000,
      id: r.id,
    });
  }
}

// 4. Local development conversions (real Gemini through the dev Worker), from the ledger + manifests.
const objectsDb = readdirSync(r2Dir).find((f) => f.endsWith(".sqlite") && f !== "metadata.sqlite");
const objects = execFileSync("sqlite3", ["-json", join(r2Dir, objectsDb), "select key, blob_id from _mf_objects where key like '%audiobook.json'"], { encoding: "utf8" });
const manifests = {};
for (const o of JSON.parse(objects)) {
  const id = /conversions\/([^/]+)\/audiobook\.json/.exec(o.key)[1];
  manifests[id] = readJson(join(blobsDir, o.blob_id));
}
const ledgerRows = [];
for (const f of readdirSync(dbDir).filter((f) => f.endsWith(".sqlite") && f !== "metadata.sqlite")) {
  for (const [table, chars, ms] of [["account_audio_segments", "narration_characters", "actual_ms"], ["segment_usage", "narration_text_characters", "actual_milliseconds"]]) {
    try {
      const out = execFileSync("sqlite3", ["-json", join(dbDir, f), `select conversion_id, sequence, ${chars} as chars, ${ms} as ms from ${table} where state='settled'`], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
      if (out.trim()) ledgerRows.push(...JSON.parse(out));
    } catch {}
  }
}
for (const l of ledgerRows) {
  const m = manifests[l.conversion_id];
  if (!m) continue;
  const unit = m.narrationDocument.synchronizationUnits[l.sequence];
  if (unit.narrationText.length !== l.chars) throw new Error(`char mismatch ${l.conversion_id}#${l.sequence}`);
  rows.push({
    source: "local-dev",
    model: m.speechConfig.model,
    policy: `${m.speechConfig.policyVersion}`,
    lang: m.narrationLanguage ?? (/derstandard/.test(m.originalUrl) ? "de" : "en"),
    kind: classify(unit.narrationText),
    text: unit.narrationText,
    chars: l.chars,
    ms: l.ms,
    id: `${l.conversion_id.slice(0, 8)}#${l.sequence}`,
    url: m.originalUrl,
  });
}

// Output
const q = (xs, p) => {
  const s = [...xs].sort((a, b) => a - b);
  const i = (s.length - 1) * p;
  return s[Math.floor(i)] + (s[Math.ceil(i)] - s[Math.floor(i)]) * (i - Math.floor(i));
};
function summarize(label, rs) {
  if (rs.length === 0) return;
  const per = rs.map((r) => r.ms / r.chars);
  const pooled = rs.reduce((a, r) => a + r.ms, 0) / rs.reduce((a, r) => a + r.chars, 0);
  const mean = per.reduce((a, b) => a + b, 0) / per.length;
  const sd = Math.sqrt(per.reduce((a, b) => a + (b - mean) ** 2, 0) / Math.max(1, per.length - 1));
  console.log(
    [label.padEnd(58), `n=${String(rs.length).padStart(3)}`, `chars=${String(rs.reduce((a, r) => a + r.chars, 0)).padStart(5)}`, `pooled=${pooled.toFixed(1)}`, `median=${q(per, 0.5).toFixed(1)}`, `min=${Math.min(...per).toFixed(1)}`, `p25=${q(per, 0.25).toFixed(1)}`, `p75=${q(per, 0.75).toFixed(1)}`, `max=${Math.max(...per).toFixed(1)}`, `sd=${sd.toFixed(1)}`, `vs80=${((pooled / 80) * 100).toFixed(0)}%`].join("  "),
  );
}
const by = (f) => (r) => f(r);
const groups = {};
for (const r of rows) {
  const k = `${r.source} | ${r.model.replace("gemini-", "")} | p${r.policy} | ${r.lang}`;
  (groups[k] ??= []).push(r);
}
console.log("== by source/model/policy/lang");
for (const k of Object.keys(groups).sort()) summarize(k, groups[k]);

const fl = rows.filter((r) => r.model === "gemini-3.8-flash-lite-tts" && (r.policy === "5" || r.policy === "5-shape" || r.policy === "4" || r.policy === "4-shape"));
console.log("\n== Flash-Lite, policy 4/5 shapes, by kind and language");
for (const lang of ["en", "de"]) for (const kind of ["body", "heading+body", "heading-only", "names-only"]) summarize(`FL ${lang} ${kind}`, fl.filter((r) => r.lang === lang && r.kind === kind));
console.log("\n== Flash-Lite, policy 5 shape only, by kind and language");
const p5 = rows.filter((r) => r.model === "gemini-3.8-flash-lite-tts" && (r.policy === "5" || r.policy === "5-shape"));
for (const lang of ["en", "de"]) for (const kind of ["body", "heading+body", "heading-only", "names-only"]) summarize(`P5 ${lang} ${kind}`, p5.filter((r) => r.lang === lang && r.kind === kind));
console.log("\n== Flash-Lite, policy 4 shape only, by kind and language");
const p4 = rows.filter((r) => r.model === "gemini-3.8-flash-lite-tts" && (r.policy === "4" || r.policy === "4-shape"));
for (const lang of ["en", "de"]) for (const kind of ["body", "heading+body", "heading-only", "names-only"]) summarize(`P4 ${lang} ${kind}`, p4.filter((r) => r.lang === lang && r.kind === kind));
console.log("\n== Flash-Lite, policy 4/5, segments >= 200 chars");
for (const lang of ["en", "de"]) summarize(`FL ${lang} >=200`, fl.filter((r) => r.lang === lang && r.chars >= 200));
console.log("\n== Flash (not Lite) 3.8 comparison");
for (const lang of ["en", "de"]) summarize(`Flash ${lang}`, rows.filter((r) => r.model === "gemini-3.8-flash-tts" && r.lang === lang));


console.log("\n== Flash-Lite p4/p5 body: digits vs none");
for (const lang of ["en","de"]) { summarize(`FL ${lang} body digits`, fl.filter(r=>r.lang===lang&&r.kind==="body"&&/\d/.test(r.text))); summarize(`FL ${lang} body no digits`, fl.filter(r=>r.lang===lang&&r.kind==="body"&&!/\d/.test(r.text))); }
console.log("\n== least squares ms = a + b*chars, Flash-Lite p4/p5, excluding names-only");
for (const [label, sel] of [["en all", r=>r.lang==="en"],["de all", r=>r.lang==="de"],["en p5", r=>r.lang==="en"&&/5/.test(r.policy)],["de p5", r=>r.lang==="de"&&/5/.test(r.policy)],["en p4", r=>r.lang==="en"&&/4/.test(r.policy)],["de p4", r=>r.lang==="de"&&/4/.test(r.policy)]]) {
  const rs = fl.filter(r=>r.kind!=="names-only"&&sel(r)); const n=rs.length; const mx=rs.reduce((a,r)=>a+r.chars,0)/n, my=rs.reduce((a,r)=>a+r.ms,0)/n;
  const b=rs.reduce((a,r)=>a+(r.chars-mx)*(r.ms-my),0)/rs.reduce((a,r)=>a+(r.chars-mx)**2,0); const a=my-b*mx;
  console.log(label.padEnd(8), "n="+n, "intercept="+a.toFixed(0)+"ms", "slope="+b.toFixed(1)+"ms/char");
}
console.log("\n== document totals (Flash-Lite p4/p5 shapes; local conversions and comparison excerpts)");
const docs={};
for (const r of fl.filter(r=>r.source==="local-dev"||r.source==="3.8-comparison")) { const k=r.source+" "+r.id.split("#")[0]+" "+r.lang; (docs[k]??={chars:0,ms:0,n:0,est:0}); docs[k].chars+=r.chars; docs[k].ms+=r.ms; docs[k].n++; docs[k].est+=Math.max(1000,r.chars*80); }
for (const [k,d] of Object.entries(docs)) console.log(k.padEnd(70), "segments="+d.n, "chars="+d.chars, "audio="+(d.ms/1000).toFixed(1)+"s", "ms/char="+(d.ms/d.chars).toFixed(1), "reserved="+(d.est/1000).toFixed(1)+"s", "actual/reserved="+(d.ms/d.est*100).toFixed(0)+"%");
console.log("\n== other models per language (3.8 comparison + archived baselines)");
for (const r of baseline.results) rows.push({source:"baseline",model:r.provider,policy:"-",lang:caseLang(r.caseId),kind:"x",text:"",chars:r.characters,ms:r.audioSeconds*1000,id:r.caseId});
for (const m of [...new Set(rows.filter(r=>r.source==="baseline"||r.source==="3.8-comparison").map(r=>r.model))]) for (const lang of ["en","de"]) summarize(`${m} ${lang}`, rows.filter(r=>(r.source==="baseline"||r.source==="3.8-comparison")&&r.model===m&&r.lang===lang));
console.log("\n== rows (Flash-Lite, policy 4/5 shapes)");
for (const r of fl.sort((a, b) => a.source.localeCompare(b.source) || a.id.localeCompare(b.id)))
  console.log([r.source, `p${r.policy}`, r.lang, r.kind, r.id, r.chars, Math.round(r.ms), (r.ms / r.chars).toFixed(1), /\d/.test(r.text) ? "digits" : "", JSON.stringify(r.text.slice(0, 70))].join("\t"));
console.log("\nbaseline-results head:", baselineSummary);
console.log("local manifests:", Object.entries(manifests).map(([id, m]) => `${id.slice(0, 8)} p${m.speechConfig.policyVersion} ${m.narrationLanguage ?? "?"} ${m.originalUrl}`).join("\n  "));
