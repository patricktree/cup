// Throwaway experiment for docs/research/playwright-loading-flash-detection.md; not committed.
import { expect, test, type Page } from "@playwright/test";

async function installRecorder(page: Page) {
  await page.route("http://flash.test/", (route) => route.fulfill({ contentType: "text/html", body: "<!doctype html><body><h1>flash</h1></body>" }));
  await page.addInitScript(() => {
    const log = { mo: [] as string[], raf: [] as string[], element: [] as string[], frames: 0 };
    Object.assign(window, { flashLog: log });
    const seen = (element: Element) =>
      element.matches("[data-loading]")
        ? [element]
        : [...element.querySelectorAll("[data-loading]")];
    new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (node instanceof Element) {
            for (const hit of seen(node)) log.mo.push(hit.getAttribute("data-loading") ?? "");
          }
        }
      }
    }).observe(document, { childList: true, subtree: true });
    const sample = () => {
      log.frames += 1;
      for (const hit of document.querySelectorAll("[data-loading]")) {
        const id = hit.getAttribute("data-loading") ?? "";
        if (!log.raf.includes(id)) log.raf.push(id);
      }
      requestAnimationFrame(sample);
    };
    requestAnimationFrame(sample);
    try {
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          log.element.push((entry as unknown as { identifier: string }).identifier);
        }
      }).observe({ type: "element", buffered: true });
    } catch {}
  });
}

async function runScenarios(page: Page) {
  await page.evaluate(async () => {
    const add = (id: string) => {
      const element = document.createElement("p");
      element.dataset["loading"] = id;
      element.setAttribute("elementtiming", id);
      element.textContent = `Loading ${id}…`;
      document.body.append(element);
      return element;
    };
    const nextFrame = () => new Promise((resolve) => requestAnimationFrame(resolve));
    const realTimeout = (ms: number) =>
      new Promise((resolve) => (window as unknown as { realSetTimeout?: typeof setTimeout }).realSetTimeout
        ? null
        : setTimeout(resolve, ms));
    void realTimeout;
    add("same-task").remove();
    const microtask = add("microtask");
    await Promise.resolve();
    microtask.remove();
    const timeout = add("timeout-0");
    await new Promise((resolve) => setTimeout(resolve, 0));
    timeout.remove();
    const twoFrames = add("two-frames");
    await nextFrame();
    await nextFrame();
    twoFrames.remove();
    await nextFrame();
    await nextFrame();
  });
  return page.evaluate(() => (window as unknown as { flashLog: unknown }).flashLog);
}

test("real clock: which recorder sees which flash", async ({ page }) => {
  await installRecorder(page);
  await page.goto("http://flash.test/");
  const results = [];
  for (let run = 0; run < 5; run += 1) {
    await page.goto("http://flash.test/");
    results.push(await runScenarios(page));
  }
  console.log("REAL", JSON.stringify(results));
});

test("paused clock: rAF, MessageChannel and setTimeout", async ({ page }) => {
  await installRecorder(page);
  await page.clock.install({ time: new Date("2026-10-29T10:00:00Z") });
  await page.goto("http://flash.test/");
  await page.clock.pauseAt(new Date("2026-10-29T10:00:10Z"));
  const before = await page.evaluate(() => (window as unknown as { flashLog: { frames: number } }).flashLog.frames);
  const probe = await page.evaluate(async () => {
    const result = { messageChannel: false, timeout: false, mo: false };
    const channel = new MessageChannel();
    channel.port1.onmessage = () => (result.messageChannel = true);
    channel.port2.postMessage(null);
    setTimeout(() => (result.timeout = true), 0);
    new MutationObserver(() => (result.mo = true)).observe(document.body, { childList: true });
    document.body.append(document.createElement("i"));
    Object.assign(window, { probe: result });
    // wait real time without page timers: a fetch to a data URL resolves through the network stack
    for (let index = 0; index < 20; index += 1) await fetch("data:text/plain,x");
    return { ...result };
  });
  await page.waitForTimeout(300);
  const after = await page.evaluate(() => ({
    frames: (window as unknown as { flashLog: { frames: number } }).flashLog.frames,
    probe: (window as unknown as { probe: unknown }).probe,
  }));
  await page.clock.runFor(50);
  const afterRun = await page.evaluate(() => ({
    frames: (window as unknown as { flashLog: { frames: number } }).flashLog.frames,
    probe: (window as unknown as { probe: unknown }).probe,
  }));
  console.log("PAUSED", JSON.stringify({ before, probe, after, afterRun }));
  expect(true).toBe(true);
});

test("paused clock: setTimeout probe", async ({ page }) => {
  await installRecorder(page);
  await page.clock.install({ time: new Date("2026-10-29T10:00:00Z") });
  await page.goto("http://flash.test/");
  await page.clock.pauseAt(new Date("2026-10-29T10:00:10Z"));
  await page.evaluate(() => {
    const state = { t0: false, t50: false, fromChannel: false, now0: performance.now(), date0: Date.now() };
    Object.assign(window, { state });
    setTimeout(() => (state.t0 = true), 0);
    setTimeout(() => (state.t50 = true), 50);
    const channel = new MessageChannel();
    channel.port1.onmessage = () => setTimeout(() => (state.fromChannel = true), 0);
    channel.port2.postMessage(null);
  });
  await page.waitForTimeout(500);
  const paused = await page.evaluate(() => ({ ...(window as any).state, now1: performance.now(), date1: Date.now() }));
  await page.clock.runFor(100);
  const ran = await page.evaluate(() => ({ ...(window as any).state }));
  console.log("PROBE", JSON.stringify({ paused, ran }));
});
