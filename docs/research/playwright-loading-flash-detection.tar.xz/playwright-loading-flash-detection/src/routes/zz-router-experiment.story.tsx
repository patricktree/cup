// Throwaway experiment for docs/research/playwright-loading-flash-detection.md; not committed.
// oxlint-disable
// @ts-nocheck
import {
  createMemoryHistory,
  createRootRoute,
  createRoute,
  createRouter,
  Link,
  Outlet,
  RouterProvider,
} from "@tanstack/react-router";
import React from "react";

function createExperimentRouter() {
  const root = createRootRoute({
    component: () => (
      <>
        <Link to="/slow">Go slow</Link>
        <Outlet />
      </>
    ),
  });
  const index = createRoute({ getParentRoute: () => root, path: "/", component: () => <p>Home</p> });
  const slow = createRoute({
    getParentRoute: () => root,
    path: "/slow",
    loader: () => new Promise((resolve) => Object.assign(window, { releaseSlow: resolve })),
    pendingComponent: () => <p data-loading="route">Pending…</p>,
    component: () => <p>Slow done</p>,
  });
  return createRouter({
    routeTree: root.addChildren([index, slow]),
    history: createMemoryHistory({ initialEntries: ["/"] }),
    defaultPendingMs: 500,
    defaultPendingMinMs: 300,
    defaultPreload: false,
  });
}

export const Router = {
  component: function RouterStory() {
    const [router] = React.useState(createExperimentRouter);
    return <RouterProvider router={router} />;
  },
};
