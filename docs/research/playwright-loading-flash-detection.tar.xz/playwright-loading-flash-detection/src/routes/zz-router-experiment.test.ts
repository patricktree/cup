// Throwaway experiment for docs/research/playwright-loading-flash-detection.md; not committed.
import { expect, test, type Page } from "@playwright/test";

async function record(page: Page) {
  await page.addInitScript(() => {
    const log = { inserted: [] as number[], removed: [] as number[] };
    Object.assign(window, { routeLog: log });
    const has = (node: Node) =>
      node instanceof Element && (node.matches("[data-loading]") || node.querySelector("[data-loading]") !== null);
    new MutationObserver((records) => {
      for (const r of records) {
        for (const n of r.addedNodes) if (has(n)) log.inserted.push(performance.now());
        for (const n of r.removedNodes) if (has(n)) log.removed.push(performance.now());
      }
    }).observe(document, { childList: true, subtree: true });
  });
}
const readLog = (page: Page) => page.evaluate(() => (window as any).routeLog);
const release = (page: Page) => page.evaluate(() => (window as any).releaseSlow());

test("paused clock: pendingMs and pendingMinMs follow runFor", async ({ mount, page }) => {
  await record(page);
  await page.clock.install({ time: new Date("2026-10-29T10:00:00Z") });
  const component = await mount("routes/zz-router-experiment/Router");
  await expect(component.getByText("Home")).toBeVisible();
  await page.clock.pauseAt(new Date("2026-10-29T11:00:00Z"));
  await component.getByRole("link", { name: "Go slow" }).click();
  await page.waitForTimeout(1000);
  const afterRealSecond = await component.getByText("Pending…").count();
  await page.clock.runFor(499);
  await page.waitForTimeout(200);
  const at499 = await component.getByText("Pending…").count();
  await page.clock.runFor(1);
  await expect(component.getByText("Pending…")).toBeVisible();
  await release(page);
  await page.waitForTimeout(500);
  const releasedWhilePaused = await component.getByText("Pending…").count();
  await page.clock.runFor(299);
  await page.waitForTimeout(200);
  const at299 = await component.getByText("Pending…").count();
  await page.clock.runFor(1);
  await expect(component.getByText("Slow done")).toBeVisible();
  console.log("ROUTER-PAUSED", JSON.stringify({ afterRealSecond, at499, releasedWhilePaused, at299, log: await readLog(page) }));
});

test("real clock: fast data shows no pending", async ({ mount, page }) => {
  await record(page);
  const component = await mount("routes/zz-router-experiment/Router");
  await component.getByRole("link", { name: "Go slow" }).click();
  await release(page);
  await expect(component.getByText("Slow done")).toBeVisible();
  console.log("ROUTER-FAST", JSON.stringify(await readLog(page)));
});

test("real clock: data at about 600 ms shows pending for at least 300 ms", async ({ mount, page }) => {
  await record(page);
  const component = await mount("routes/zz-router-experiment/Router");
  await component.getByRole("link", { name: "Go slow" }).click();
  await page.waitForTimeout(600);
  await release(page);
  await expect(component.getByText("Slow done")).toBeVisible();
  const log = await readLog(page);
  console.log("ROUTER-SLOW", JSON.stringify({ ...log, shownMs: log.removed[0] - log.inserted[0] }));
});
