// Throwaway experiment for docs/research/playwright-loading-flash-detection.md; not committed.
import { expect, test, type Page } from "@playwright/test";

async function recordLoading(page: Page) {
  await page.addInitScript(() => {
    const log = { inserted: 0, painted: 0 };
    Object.assign(window, { loadingLog: log });
    const isLoading = (node: Node) =>
      node instanceof HTMLOutputElement && node.textContent.includes("Loading tracks");
    new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (isLoading(node) || (node instanceof Element && [...node.querySelectorAll("output")].some(isLoading))) {
            log.inserted += 1;
          }
        }
      }
    }).observe(document, { childList: true, subtree: true });
    const sample = () => {
      if ([...document.querySelectorAll("output")].some(isLoading)) log.painted += 1;
      requestAnimationFrame(sample);
    };
    requestAnimationFrame(sample);
  });
}

const readLog = (page: Page) =>
  page.evaluate(() => (window as unknown as { loadingLog: { inserted: number; painted: number } }).loadingLog);

test("fast: final state misses the loading line, the recorder does not", async ({ mount, page }) => {
  await recordLoading(page);
  const component = await mount("routes/zz-flash-experiment/Fast");
  await expect(component.getByRole("link", { name: "Add your first track" })).toBeVisible();
  await expect(component.getByText("Loading tracks…")).toHaveCount(0);
  console.log("FAST", JSON.stringify(await readLog(page)));
});

test("held: the loading line stays until the response is released", async ({ mount, page }) => {
  await recordLoading(page);
  const component = await mount("routes/zz-flash-experiment/Held");
  await expect(component.getByText("Loading tracks…")).toBeVisible();
  await page.evaluate(() => (window as unknown as { releaseRecents: () => void }).releaseRecents());
  await expect(component.getByRole("link", { name: "Add your first track" })).toBeVisible();
  console.log("HELD", JSON.stringify(await readLog(page)));
});

test("held + paused clock: does the released response reach the UI?", async ({ mount, page }) => {
  await recordLoading(page);
  await page.clock.install({ time: new Date("2026-10-29T10:00:00Z") });
  const component = await mount("routes/zz-flash-experiment/Held");
  await expect(component.getByText("Loading tracks…")).toBeVisible();
  await page.clock.pauseAt(new Date("2026-10-29T11:00:00Z"));
  await page.evaluate(() => (window as unknown as { releaseRecents: () => void }).releaseRecents());
  await page.waitForTimeout(1000);
  const whilePaused = await component.getByText("Loading tracks…").count();
  await page.clock.runFor(10);
  await expect(component.getByRole("link", { name: "Add your first track" })).toBeVisible();
  console.log("PAUSED-HELD", JSON.stringify({ loadingStillShownWhilePaused: whilePaused, ...(await readLog(page)) }));
});
