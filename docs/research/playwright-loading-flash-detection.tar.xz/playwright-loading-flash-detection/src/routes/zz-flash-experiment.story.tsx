// Throwaway experiment for docs/research/playwright-loading-flash-detection.md; not committed.
import { http, HttpResponse } from "msw";

import { accountStory } from "#src/ui-gallery/account-fixtures.jsx";

export const Fast = accountStory({ path: "/recent" });

/** Holds the Recents response until the test calls `window.releaseRecents()`. */
export const Held = accountStory({
  path: "/recent",
  handlers: [
    http.get("/api/account/conversions", async () => {
      await new Promise((resolve) => Object.assign(window, { releaseRecents: resolve }));
      return HttpResponse.json({ items: [], nextCursor: null });
    }),
  ],
});
