// Prints which grid-lanes related declarations the installed Chrome accepts, with the experimental flag.
// Usage: node supports.mjs <path-to-playwright-package>
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { chromium } = require(process.argv[2]);
const browser = await chromium.launch({
  channel: "chrome",
  args: ["--enable-experimental-web-platform-features"],
});
const page = await browser.newPage();
console.log(
  browser.version(),
  await page.evaluate(() => ({
    gridLanes: CSS.supports("display", "grid-lanes"),
    fitTolerance0: CSS.supports("fit-tolerance", "0"),
    flowTolerance0: CSS.supports("flow-tolerance", "0"),
    readingFlowGridLanes: CSS.supports("reading-flow", "grid-lanes"),
    readingFlowGridRows: CSS.supports("reading-flow", "grid-rows"),
  })),
);
await browser.close();
