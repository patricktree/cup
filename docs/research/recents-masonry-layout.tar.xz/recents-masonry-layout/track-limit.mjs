// Measures how many implicit 1px grid rows the installed Chrome creates before clamping.
// Usage: node track-limit.mjs <path-to-playwright-package>
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { chromium } = require(process.argv[2]);
const browser = await chromium.launch({ channel: "chrome" });
const page = await browser.newPage();
await page.setContent(`<div id=g style="display:grid;grid-auto-rows:1px"></div>`);
for (const rows of [1_000, 10_000, 100_000, 1_000_000, 2_000_000]) {
  const height = await page.evaluate((rows) => {
    const g = document.getElementById("g");
    g.innerHTML = "";
    const a = document.createElement("div");
    a.style.gridRow = "1 / span 10";
    const b = document.createElement("div");
    b.style.gridRow = `${rows} / span 1`;
    g.append(a, b);
    return Math.round(b.getBoundingClientRect().bottom - g.getBoundingClientRect().top);
  }, rows);
  console.log(`item placed at row ${rows}: bottom at ${height}px`);
}
console.log(browser.version());
await browser.close();
