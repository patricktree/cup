// Compares masonry techniques in Chromium: multi-column, grid row-span (JS sets spans), and
// display: grid-lanes (experimental flag). Prints the column each card lands in and whether
// placement matches greedy shortest-column assignment.
// Usage: node masonry-experiment.mjs <path-to-playwright-package> [--experimental]
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { chromium } = require(process.argv[2]);

const GAP = 12;
const COLS = 2;
const WIDTH = 360; // container inline size, about a phone
// Deterministic card heights (px), standing in for title + optional cover + host.
function heights(n, seed) {
  let s = seed;
  const out = [];
  for (let i = 0; i < n; i++) {
    s = (s * 1103515245 + 12345) % 2 ** 31;
    out.push(80 + (s % 220));
  }
  return out;
}

function shortestColumn(hs) {
  const ends = Array(COLS).fill(0);
  return hs.map((h) => {
    let c = 0;
    for (let k = 1; k < COLS; k++) if (ends[k] < ends[c]) c = k;
    ends[c] += h + GAP;
    return c;
  });
}

// The CSS Grid Level 3 placement with a tie threshold: lanes within `tolerance` of the shortest
// tie, and the first tied lane at or after the auto-placement cursor wins (§4.4).
function gridLanesSpec(hs, tolerance) {
  const ends = Array(COLS).fill(0);
  let cursor = 0;
  return hs.map((h) => {
    const min = Math.min(...ends);
    const tied = ends.flatMap((end, c) => (end <= min + tolerance ? [c] : []));
    const c = tied.find((k) => k >= cursor) ?? tied[0];
    ends[c] += h + GAP;
    cursor = c + 1;
    return c;
  });
}

const page1 = heights(12, 7);
const page2 = heights(12, 99);

const html = `<!doctype html><meta charset=utf-8><style>
body{margin:0;font:16px sans-serif}
.c{width:${WIDTH}px}
.card{box-sizing:border-box;background:#ddd}
#multicol{columns:${COLS};column-gap:${GAP}px}
#multicol .card{break-inside:avoid;margin-block-end:${GAP}px}
#rowspan{display:grid;grid-template-columns:repeat(${COLS},1fr);column-gap:${GAP}px;grid-auto-rows:1px;row-gap:0}
#lanes{display:grid;display:grid-lanes;grid-template-columns:repeat(${COLS},1fr);gap:${GAP}px}
#lanes0{display:grid;display:grid-lanes;grid-template-columns:repeat(${COLS},1fr);gap:${GAP}px;flow-tolerance:0;fit-tolerance:0}
</style>
<div class=c id=multicol></div><div class=c id=rowspan></div><div class=c id=lanes></div><div class=c id=lanes0></div>`;

const ids = ["multicol", "rowspan", "lanes", "lanes0"];
const browserArgs = process.argv.includes("--experimental")
  ? ["--enable-experimental-web-platform-features"]
  : [];
// The installed Google Chrome stable, so the result reflects shipping desktop Chrome.
const browser = await chromium.launch({ channel: "chrome", args: browserArgs });
const page = await browser.newPage();
await page.setContent(html);
console.log("Chromium", browser.version(), "args", browserArgs.join(" ") || "(none)");
console.log(
  "CSS.supports grid-lanes:",
  await page.evaluate(() => CSS.supports("display", "grid-lanes")),
);

await page.evaluate(
  ({ GAP, ids }) => {
    window.addCards = (hs) => {
      for (const id of ids) {
        const root = document.getElementById(id);
        for (const h of hs) {
          const el = document.createElement("div");
          el.className = "card";
          el.style.height = h + "px";
          root.append(el);
        }
      }
      window.syncSpans();
    };
    // Row-span technique: each card spans ceil(height + gap) 1px rows; sparse auto-placement does the rest.
    window.syncSpans = () => {
      for (const el of document.getElementById("rowspan").children) {
        const h = el.getBoundingClientRect().height;
        el.style.gridRowEnd = "span " + Math.ceil(h + GAP);
      }
    };
    window.readLayout = (id) => {
      const root = document.getElementById(id);
      const box = root.getBoundingClientRect();
      const colWidth = box.width / 2;
      return [...root.children].map((el) => {
        const r = el.getBoundingClientRect();
        return { col: Math.round((r.left - box.left) / colWidth), top: Math.round(r.top - box.top) };
      });
    };
  },
  { GAP, ids },
);

async function report(label, hs) {
  const expected = shortestColumn(hs);
  console.log(`\n# ${label}`);
  console.log("reference".padEnd(9), expected.join(""), "(greedy shortest column, DOM order)");
  console.log("spec 1em".padEnd(9), gridLanesSpec(hs, 16).join(""), "(grid-lanes, fit-tolerance: normal = 1em)");
  const layouts = {};
  for (const id of ids) {
    layouts[id] = await page.evaluate((id) => window.readLayout(id), id);
    const cols = layouts[id].map((p) => p.col).join("");
    console.log(id.padEnd(9), cols, cols === expected.join("") ? "(matches reference)" : "");
  }
  return layouts;
}

await page.evaluate((hs) => window.addCards(hs), page1);
const before = await report("first page (12 cards)", page1);

await page.evaluate((hs) => window.addCards(hs), page2);
const after = await report(
  "after appending a second page (24 cards)",
  [...page1, ...page2],
);
for (const id of ids) {
  const moved = before[id].filter(
    (p, i) => p.col !== after[id][i].col || p.top !== after[id][i].top,
  ).length;
  console.log(`${id}: first-page cards moved by the append: ${moved}/12`);
}

// A cover image loads late in card 1 (second newest): +120px.
await page.evaluate((ids) => {
  for (const id of ids) {
    const el = document.getElementById(id).children[1];
    el.style.height = parseFloat(el.style.height) + 120 + "px";
  }
  window.syncSpans();
}, ids);
const grown = [...page1, ...page2];
grown[1] += 120;
const late = await report("after card 1 grows by 120px (late image)", grown);
for (const id of ids) {
  const switched = after[id].filter((p, i) => p.col !== late[id][i].col).length;
  console.log(`${id}: cards that switched column after the late resize: ${switched}/24`);
}
await browser.close();
