// Usage: node transcribe.mjs <env-file> <out-dir>
import { readFileSync, writeFileSync, readdirSync, existsSync } from "node:fs";
import { join } from "node:path";

const [envFile, outDir] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}

for (const file of readdirSync(outDir).filter((f) => f.endsWith(".mp3")).sort()) {
  const out = join(outDir, `${file}.transcript.json`);
  if (existsSync(out)) continue;
  const response = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/openai/whisper-large-v3-turbo`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.CLOUDFLARE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ audio: readFileSync(join(outDir, file)).toString("base64"), vad_filter: true }),
    },
  );
  const json = await response.json();
  writeFileSync(out, JSON.stringify(json, null, 2));
  const r = json.result ?? {};
  console.log(file, response.status, r.transcription_info?.language, r.transcription_info?.language_probability?.toFixed?.(2), JSON.stringify(r.text));
}
