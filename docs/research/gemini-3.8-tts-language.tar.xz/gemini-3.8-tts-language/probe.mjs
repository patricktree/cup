// Usage: node probe.mjs <env-file> <out-dir> <probe-id>...
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";

const [envFile, outDir, ...ids] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
mkdirSync(outDir, { recursive: true });

const BYLINE = "Gerald John, Alicia Prager, Sandra Schieder";
const MIXED =
  "Der Korrespondent schreibt aus London. „The government will not back down“, sagte der Premierminister am Montag.";

const text = (t, annotations) => ({ type: "text", text: t, ...(annotations ? { annotations } : {}) });

const probes = {
  "byline-none": { content: [text(BYLINE)], speech: { voice: "Charon" } },
  "byline-de-DE": { content: [text(BYLINE)], speech: { voice: "Charon", language: "de-DE" } },
  "byline-de-AT": { content: [text(BYLINE)], speech: { voice: "Charon", language: "de-AT" } },
  "byline-de": { content: [text(BYLINE)], speech: { voice: "Charon", language: "de" } },
  "byline-german-word": { content: [text(BYLINE)], speech: { voice: "Charon", language: "German" } },
  "byline-invalid": { content: [text(BYLINE)], speech: { voice: "Charon", language: "zz-ZZ" } },
  "byline-eo": { content: [text(BYLINE)], speech: { voice: "Charon", language: "eo" } },
  "byline-sv-SE": { content: [text(BYLINE)], speech: { voice: "Charon", language: "sv-SE" } },
  "byline-style": {
    content: [text(BYLINE, [{ type: "speech_metadata", style: "Spoken by a native Austrian German news narrator, German pronunciation" }])],
    speech: { voice: "Charon" },
  },
  "byline-system": {
    content: [text(BYLINE)],
    speech: { voice: "Charon" },
    system_instruction: "The transcript is German. Pronounce every name as a native German speaker would.",
  },
  "mixed-none": { content: [text(MIXED)], speech: { voice: "Charon" } },
  "mixed-de-DE": { content: [text(MIXED)], speech: { voice: "Charon", language: "de-DE" } },
  "mixed-en-US": { content: [text(MIXED)], speech: { voice: "Charon", language: "en-US" } },
};

probes["byline-de-DE-2"] = probes["byline-de-DE"];
probes["byline-style-2"] = probes["byline-style"];

for (const id of ids) {
  const probe = probes[id];
  if (!probe) throw new Error(`Unknown probe ${id}`);
  const out = join(outDir, `${id}.json`);
  if (existsSync(out)) {
    console.log(`${id}: exists, skipping`);
    continue;
  }
  const query = {
    model: "gemini-3.8-flash-lite-tts",
    input: [{ type: "user_input", content: probe.content }],
    response_format: { type: "audio", mime_type: "audio/l16", sample_rate: 24_000 },
    generation_config: { speech_config: [probe.speech] },
    ...(probe.system_instruction ? { system_instruction: probe.system_instruction } : {}),
    stream: false,
  };
  const response = await fetch(`https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/default`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
      "cf-aig-skip-cache": "true",
      "cf-aig-collect-log-payload": "false",
    },
    body: JSON.stringify([
      {
        provider: "google-ai-studio",
        endpoint: "v1beta/interactions",
        headers: { "Content-Type": "application/json", "Api-Revision": "2026-05-20" },
        query,
      },
    ]),
    signal: AbortSignal.timeout(90_000),
  });
  const body = await response.text();
  let json;
  try {
    json = JSON.parse(body);
  } catch {
    json = undefined;
  }
  const audio = json?.steps?.flatMap((s) => s.content ?? []).find((c) => c.type === "audio");
  const record = {
    id,
    request: query,
    httpStatus: response.status,
    gatewayLogId: response.headers.get("cf-aig-log-id"),
    contentType: response.headers.get("content-type"),
    audioMimeType: audio?.mime_type,
    usage: json?.usage,
    status: json?.status,
    error: audio ? undefined : (json ?? body),
  };
  if (audio) {
    const pcm = Buffer.from(audio.data, "base64");
    writeFileSync(join(outDir, `${id}.pcm`), pcm);
    record.audioSeconds = pcm.length / 2 / 24_000;
  }
  writeFileSync(out, JSON.stringify(record, null, 2));
  console.log(`${id}: HTTP ${response.status}`, audio ? `${record.audioSeconds.toFixed(2)} s` : JSON.stringify(record.error).slice(0, 400));
}
