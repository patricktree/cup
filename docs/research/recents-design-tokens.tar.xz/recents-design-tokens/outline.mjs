import fs from "node:fs";
const data = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const hex = (c, o = 1) => { const h = (v) => Math.round(v * 255).toString(16).padStart(2, "0"); const a = (c.a ?? 1) * o; return `#${h(c.r)}${h(c.g)}${h(c.b)}${a < 1 ? h(a) : ""}`; };
function line(n) {
  const p = [];
  const bb = n.absoluteBoundingBox; if (bb) p.push(`${Math.round(bb.width)}x${Math.round(bb.height)}`);
  const f = (n.fills ?? []).filter((x) => x.visible !== false).map((x) => x.type === "SOLID" ? hex(x.color, x.opacity) : x.type);
  if (f.length) p.push(`fill=${f.join(",")}`);
  const s = (n.strokes ?? []).filter((x) => x.visible !== false).map((x) => x.type === "SOLID" ? hex(x.color, x.opacity) : x.type);
  if (s.length) p.push(`stroke=${s.join(",")}/${n.strokeWeight}`);
  if (n.cornerRadius) p.push(`r=${n.cornerRadius}`);
  if (n.rectangleCornerRadii) p.push(`r=${n.rectangleCornerRadii.join("/")}`);
  if (n.effects?.length) p.push(`fx=${JSON.stringify(n.effects.filter(e=>e.visible!==false).map(e=>({t:e.type,r:e.radius,o:e.offset,c:e.color&&hex(e.color),s:e.spread})))}`);
  if (n.layoutMode && n.layoutMode !== "NONE") p.push(`${n.layoutMode} gap=${n.itemSpacing ?? 0} pad=${[n.paddingTop,n.paddingRight,n.paddingBottom,n.paddingLeft].map(v=>v??0).join("/")}`);
  if (n.opacity !== undefined && n.opacity < 1) p.push(`op=${n.opacity}`);
  if (n.type === "TEXT") { const st = n.style; p.push(`font=${st.fontFamily} ${st.fontWeight} ${st.fontSize}/${st.lineHeightPx?.toFixed?.(1)} ls=${st.letterSpacing?.toFixed?.(2)}`); p.push(JSON.stringify(n.characters.slice(0, 60))); }
  if (n.styles) p.push(`styles=${JSON.stringify(n.styles)}`);
  if (n.componentId) p.push(`comp=${n.componentId}`);
  return p.join(" ");
}
function walk(n, d) {
  if (n.visible === false) return;
  console.log(`${"  ".repeat(d)}${n.type} [${n.id}] "${n.name}" ${line(n)}`);
  for (const c of n.children ?? []) walk(c, d + 1);
}
for (const [id, v] of Object.entries(data.nodes)) { console.log(`\n===== ${id}`); walk(v.document, 0); }
const styles = Object.assign({}, ...Object.values(data.nodes).map((v) => v.styles));
const comps = Object.assign({}, ...Object.values(data.nodes).map((v) => v.components));
console.log("\n===== STYLES", JSON.stringify(styles, null, 1));
console.log("\n===== COMPONENTS", JSON.stringify(Object.fromEntries(Object.entries(comps).map(([k,v])=>[k,v.name])), null, 1));
