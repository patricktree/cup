# Reproduction

Requires a Figma personal access token with the `file_content:read` scope in `FIGMA_TOKEN`.

```sh
curl -H "X-Figma-Token: ${FIGMA_TOKEN}" -o nodes.json "https://api.figma.com/v1/files/Mud3jhH7Lliuv0jIbCS63R/nodes?ids=260:1395,260:2009,260:2229,370:5944,338:1150,338:1253,357:2150"
node outline.mjs nodes.json > outline.txt
node details.mjs nodes.json > details.txt
curl -H "X-Figma-Token: ${FIGMA_TOKEN}" -o images.json "https://api.figma.com/v1/images/Mud3jhH7Lliuv0jIbCS63R?ids=260:1411,260:1882,260:1847,377:7791,260:2877,357:2138,357:2299,357:2134,357:2142,338:1158,377:7818,260:1870,260:1741,260:1900&format=svg&svg_outline_text=true&svg_include_id=false&svg_simplify_stroke=true"
mkdir -p out/icons out/out-of-scope-icons && node dl.mjs images.json out
```

`nodes.json` is the response from 2026-10-27; the file was last modified at 2026-10-27T16:09:21Z.
