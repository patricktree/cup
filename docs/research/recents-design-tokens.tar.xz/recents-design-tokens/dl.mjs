import fs from "node:fs";
const [imagesPath, dir] = process.argv.slice(2);
const { images } = JSON.parse(fs.readFileSync(imagesPath, "utf8"));
const names = {
  "260:1411": "icons/avatar-ring.svg",
  "260:1882": "icons/tab-recent.svg",
  "260:1847": "icons/tab-add.svg",
  "338:1158": "icons/back-chevron.svg",
  "377:7818": "icons/more.svg",
  "377:7791": "icons/skip-back-15-mini.svg",
  "260:2877": "icons/pause-mini.svg",
  "357:2134": "icons/skip-back-15.svg",
  "357:2142": "icons/skip-forward-15.svg",
  "357:2138": "icons/pause.svg",
  "357:2299": "icons/play-disabled.svg",
  "260:1870": "out-of-scope-icons/tab-library.svg",
  "260:1741": "out-of-scope-icons/card-bookmark.svg",
  "260:1900": "out-of-scope-icons/card-bookmark-filled.svg",
};
for (const [id, url] of Object.entries(images)) {
  const res = await fetch(url);
  const body = await res.text();
  fs.writeFileSync(`${dir}/${names[id]}`, body.endsWith("\n") ? body : `${body}\n`);
  console.log(id, names[id], res.status, body.length, body.match(/<svg[^>]*>/)[0]);
}
