import fs from "node:fs";
const data = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const idx = new Map();
const walk = (n) => { idx.set(n.id, n); (n.children ?? []).forEach(walk); };
Object.values(data.nodes).forEach((v) => walk(v.document));
const hex = (c, o = 1) => { const h = (v) => Math.round(v * 255).toString(16).padStart(2, "0"); const a = (c.a ?? 1) * o; return `#${h(c.r)}${h(c.g)}${h(c.b)}${a < 1 ? h(a) : ""}`; };
for (const id of ["338:1198", "338:1185", "338:1187", "338:1302"]) {
  const n = idx.get(id);
  console.log(id, n.name.slice(0, 40), JSON.stringify({ style: n.style, styles: n.styles, fills: n.fills.map((f) => hex(f.color, f.opacity)) }));
  const ov = n.styleOverrideTable ?? {};
  for (const [k, v] of Object.entries(ov)) {
    const ranges = []; let start = -1;
    n.characterStyleOverrides.forEach((c, i) => { if (String(c) === k && start < 0) start = i; if (String(c) !== k && start >= 0) { ranges.push(n.characters.slice(start, i).slice(0, 50)); start = -1; } });
    console.log("  override", k, JSON.stringify({ ...v, fills: v.fills?.map((f) => hex(f.color, f.opacity)) }), "e.g.", JSON.stringify(ranges.slice(0, 3)));
  }
  console.log("  text head:", JSON.stringify(n.characters.slice(0, 300)));
}
for (const id of ["260:1491", "357:2106", "338:1304", "357:2202"]) {
  const n = idx.get(id);
  console.log(id, JSON.stringify(n.fills.map((f) => ({ type: f.type, stops: f.gradientStops?.map((s) => `${hex(s.color)}@${s.position.toFixed(2)}`), handles: f.gradientHandlePositions?.map((p) => [p.x.toFixed(2), p.y.toFixed(2)]) }))));
}
for (const id of ["260:1411", "357:2132", "357:2047", "338:1158"]) { const n = idx.get(id); console.log(id, n.name, JSON.stringify({ strokeCap: n.strokeCap, strokeJoin: n.strokeJoin, w: n.strokeWeight, bb: n.absoluteBoundingBox })); }
