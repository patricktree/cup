// Usage: node probe.mjs <env-file> <out-dir> <probe-id>...
// Probes what gemini-3.8-flash-lite-tts accepts as unspoken context, through Cloudflare AI Gateway.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join } from "node:path";

const [envFile, outDir, ...ids] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
mkdirSync(outDir, { recursive: true });

// Cloudflare fixture excerpt, narration units 0060 and 0061 (consecutive segments).
const PREVIOUS =
  "It’s worth noting that the parts of a browser that are important to agents (e.g.,\nCSS, DOM, HTML, selection, SVG, and XHR) have good coverage already. Even things\nthat might not be particularly important in the context of agents, like streams,\nare now decently supported.";
const TARGET =
  "Performance-wise, Kitesurf is doing pretty well. Below are the medians of five\nBrowser Run\nquick-action\nruns across a\n14-URL corpus\ncomparing Chromium with Kitesurf.";

const BEFORE =
  "Kitesurf passes 215,000+ WPT tests and growing\n\nKitesurf works. It already passes around 215,000+\nWPT tests, and we are adding hundreds of passing tests every week. Here you can see the\nevolution over time, up to the latest version since we started the project:";

const text = (t, annotations) => ({ type: "text", text: t, ...(annotations ? { annotations } : {}) });
const style = (s) => [{ type: "speech_metadata", style: s }];
const AUDIO = { type: "audio", mime_type: "audio/l16", sample_rate: 24_000 };

const probes = {
  baseline: { input: [{ type: "user_input", content: [text(TARGET)] }] },
  "turns-model-output": {
    input: [
      { type: "user_input", content: [text(PREVIOUS)] },
      { type: "model_output", content: [text(PREVIOUS)] },
      { type: "user_input", content: [text(TARGET)] },
    ],
  },
  "turns-user-only": {
    input: [
      { type: "user_input", content: [text(PREVIOUS)] },
      { type: "user_input", content: [text(TARGET)] },
    ],
  },
  "style-previous-text": {
    input: [
      {
        type: "user_input",
        content: [
          text(
            TARGET,
            style(`Continue reading an article aloud, carrying on from the previous paragraph, which was: "${PREVIOUS}"`),
          ),
        ],
      },
    ],
  },
  "style-continuing": {
    input: [
      {
        type: "user_input",
        content: [text(TARGET, style("continuing mid-article, carrying on from the previous paragraph"))],
      },
    ],
  },
  "annotation-range": {
    // One text block holding both paragraphs, with a style annotation covering only the target bytes.
    input: [
      {
        type: "user_input",
        content: [
          text(`${PREVIOUS}\n\n${TARGET}`, [
            {
              type: "speech_metadata",
              style: "calm narration",
              start_index: Buffer.byteLength(`${PREVIOUS}\n\n`),
              end_index: Buffer.byteLength(`${PREVIOUS}\n\n${TARGET}`),
            },
          ]),
        ],
      },
    ],
  },
  "annotation-range-no-style": {
    // The same byte range, but the annotation carries no style.
    input: [
      {
        type: "user_input",
        content: [
          text(`${PREVIOUS}\n\n${TARGET}`, [
            {
              type: "speech_metadata",
              start_index: Buffer.byteLength(`${PREVIOUS}\n\n`),
              end_index: Buffer.byteLength(`${PREVIOUS}\n\n${TARGET}`),
            },
          ]),
        ],
      },
    ],
  },
  "annotation-range-middle": {
    // Narration units 0059, 0060 and 0061: the range covers only the middle one, 0060 (PREVIOUS).
    input: [
      {
        type: "user_input",
        content: [
          text(`${BEFORE}\n\n${PREVIOUS}\n\n${TARGET}`, [
            {
              type: "speech_metadata",
              style: "calm narration",
              start_index: Buffer.byteLength(`${BEFORE}\n\n`),
              end_index: Buffer.byteLength(`${BEFORE}\n\n${PREVIOUS}`),
            },
          ]),
        ],
      },
    ],
  },
  "store-previous": { input: [{ type: "user_input", content: [text(PREVIOUS)] }], store: true },
  "previous-interaction": {
    input: [{ type: "user_input", content: [text(TARGET)] }],
    previousFrom: "store-previous",
  },
  "transcription-config": {
    input: [{ type: "user_input", content: [text(TARGET)] }],
    generation: { transcription_config: { mode: { type: "verbatim", timestamp_granularities: ["word"] } } },
  },
  "response-format-text": {
    input: [{ type: "user_input", content: [text(TARGET)] }],
    responseFormat: [AUDIO, { type: "text" }],
  },
};

probes["annotation-range-2"] = probes["annotation-range"];

function redactAudio(value) {
  if (Array.isArray(value)) return value.map(redactAudio);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([k, v]) => [
        k,
        k === "data" && typeof v === "string" && v.length > 200 ? `<${v.length} base64 chars>` : redactAudio(v),
      ]),
    );
  }
  return value;
}

for (const id of ids) {
  const probe = probes[id];
  if (!probe) throw new Error(`Unknown probe ${id}`);
  const out = join(outDir, `${id}.json`);
  if (existsSync(out)) {
    console.log(`${id}: exists, skipping`);
    continue;
  }
  let previousInteractionId;
  if (probe.previousFrom) {
    previousInteractionId = JSON.parse(readFileSync(join(outDir, `${probe.previousFrom}.json`), "utf8")).interactionId;
    if (!previousInteractionId) throw new Error(`${probe.previousFrom} has no interaction ID`);
  }
  const query = {
    model: "gemini-3.8-flash-lite-tts",
    input: probe.input,
    response_format: probe.responseFormat ?? AUDIO,
    generation_config: { speech_config: [{ voice: "Charon", language: "en-US" }], ...probe.generation },
    ...(probe.store === undefined ? {} : { store: probe.store }),
    ...(previousInteractionId ? { previous_interaction_id: previousInteractionId } : {}),
    stream: false,
  };
  const started = Date.now();
  const response = await fetch(`https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/default`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
      "cf-aig-skip-cache": "true",
      "cf-aig-collect-log-payload": "false",
    },
    body: JSON.stringify([
      {
        provider: "google-ai-studio",
        endpoint: "v1beta/interactions",
        headers: { "Content-Type": "application/json", "Api-Revision": "2026-05-20" },
        query,
      },
    ]),
    signal: AbortSignal.timeout(90_000),
  });
  const body = await response.text();
  let json;
  try {
    json = JSON.parse(body);
  } catch {
    json = undefined;
  }
  const audio = json?.steps?.flatMap((s) => s.content ?? []).find((c) => c.type === "audio");
  const record = {
    id,
    request: query,
    httpStatus: response.status,
    elapsedMs: Date.now() - started,
    gatewayLogId: response.headers.get("cf-aig-log-id"),
    interactionId: json?.id,
    usage: json?.usage,
    status: json?.status,
    response: redactAudio(json ?? body),
  };
  if (audio) {
    const pcm = Buffer.from(audio.data, "base64");
    writeFileSync(join(outDir, `${id}.pcm`), pcm);
    record.audioSeconds = pcm.length / 2 / 24_000;
  }
  writeFileSync(out, JSON.stringify(record, null, 2));
  console.log(
    `${id}: HTTP ${response.status}`,
    audio
      ? `${record.audioSeconds.toFixed(2)} s, in ${JSON.stringify(record.usage?.input_tokens_by_modality)} out ${record.usage?.total_output_tokens}`
      : JSON.stringify(record.response).slice(0, 500),
  );
}
