// PROTOTYPE (throwaway, never merged): synthesizes a few narration segments under several ways of
// conveying the narration language, so they can be compared by ear. Paid: about 60 short calls.
// Usage: node synthesize.mjs   (reads apps/cloudflare-worker/.env.local, writes ./out and ./index.html)
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const envFile = join(here, "../../../apps/cloudflare-worker/.env.local");
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
const outDir = join(here, "out");
mkdirSync(outDir, { recursive: true });

const TAKES = 2;

// Segments as narration would split them: the derStandard byline is a segment of its own.
const articles = [
  {
    id: "de",
    title: "derStandard (German, declared de-AT): Kickls Aussagen im Faktencheck",
    language: "de-AT",
    languageName: "German",
    segments: [
      { id: "title", text: "Pensionen, Klimawandel, Distanz zur AfD: Kickls Aussagen im Faktencheck" },
      { id: "lead", text: "FPÖ-Chef Herbert Kickl hält ein höheres Pensionsalter für ebenso unnötig wie den heimischen Kampf gegen die Klimakrise, mit der AfD will er nicht verbündet sein. Wie haltbar sind seine Argumente?" },
      { id: "byline", text: "Gerald John, Alicia Prager, Sandra Schieder" },
      { id: "body", text: "Moderatorin Simone Stribl war mitunter anzusehen, dass sie Aussagen ihres Interviewpartners perplex machten. Mancher Seherin und manchem Seher des ORF-„Sommergesprächs“ mit dem angriffslustigen Kanzleranwärter aus der FPÖ mag es ähnlich ergangen sein." },
      { id: "quote-en", text: "Der Korrespondent schreibt aus London. „The government will not back down“, sagte der Premierminister am Montag." },
    ],
    // Option (c): the names-only segment joined with the narration text before it.
    joined: { id: "lead+byline", from: ["lead", "byline"] },
  },
  {
    id: "en",
    title: "English article quoting German (written for the prototype, declared en-GB)",
    language: "en-GB",
    languageName: "English",
    segments: [
      { id: "title", text: "Austria's far-right leader dismisses climate policy in televised interview" },
      { id: "byline", text: "Gerald John and Sandra Schieder in Vienna" },
      { id: "quote-de", text: "Asked about the pension age, Kickl was blunt. „Ein höheres Pensionsalter brauchen wir nicht, das ist eine Erfindung der Bürokraten in Brüssel“, he told the presenter, before turning to the climate." },
      { id: "passage-de", text: "The broadcaster's own summary read: „Kickl gibt sich im Sommergespräch angriffslustig und weicht bei der Frage nach der AfD aus.“ Critics called the interview a missed opportunity." },
    ],
    joined: { id: "title+byline", from: ["title", "byline"] },
  },
];

// Ways of conveying the language. `style` is a speech_metadata annotation, which is not spoken.
const variants = [
  { id: "none", label: "Nothing (today)", build: () => ({}) },
  { id: "code", label: "Language code", build: (a) => ({ language: a.language }) },
  { id: "code+style", label: "Code + style “Read in <L> with standard <L> pronunciation.”", build: (a) => ({ language: a.language, style: `Read in ${a.languageName} with standard ${a.languageName} pronunciation.` }) },
  { id: "code+style-mixed", label: "Code + style that names the exception", build: (a) => ({ language: a.language, style: `Read in ${a.languageName} with standard ${a.languageName} pronunciation. Say any passage clearly in another language, such as a quotation, in that language.` }) },
  { id: "style", label: "Style “Read in <L> …” without code", build: (a) => ({ style: `Read in ${a.languageName} with standard ${a.languageName} pronunciation.` }) },
];

async function synthesize(text, { language, style }) {
  const query = {
    model: "gemini-3.8-flash-lite-tts",
    input: [{ type: "user_input", content: [{ type: "text", text, ...(style ? { annotations: [{ type: "speech_metadata", style }] } : {}) }] }],
    response_format: { type: "audio", mime_type: "audio/l16", sample_rate: 24_000 },
    generation_config: { speech_config: [{ voice: "Charon", ...(language ? { language } : {}) }] },
    stream: false,
  };
  const response = await fetch(`https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/default`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
      "cf-aig-skip-cache": "true",
      "cf-aig-collect-log-payload": "false",
    },
    body: JSON.stringify([{ provider: "google-ai-studio", endpoint: "v1beta/interactions", headers: { "Content-Type": "application/json", "Api-Revision": "2026-05-20" }, query }]),
    signal: AbortSignal.timeout(90_000),
  });
  const body = await response.text();
  const audio = JSON.parse(body)?.steps?.flatMap((s) => s.content ?? []).find((c) => c.type === "audio");
  if (!audio) throw new Error(`HTTP ${response.status}: ${body.slice(0, 400)}`);
  return Buffer.from(audio.data, "base64");
}

const jobs = [];
for (const article of articles) {
  const rows = [...article.segments, { id: article.joined.id, text: article.joined.from.map((id) => article.segments.find((s) => s.id === id).text).join("\n\n") }];
  for (const row of rows) for (const variant of variants) for (let take = 1; take <= TAKES; take += 1) jobs.push({ article, row, variant, take, file: `${article.id}--${row.id}--${variant.id}--${take}.mp3` });
}

let next = 0;
async function worker() {
  while (next < jobs.length) {
    const job = jobs[next++];
    const mp3 = join(outDir, job.file);
    if (existsSync(mp3)) continue;
    const pcm = await synthesize(job.row.text, job.variant.build(job.article));
    const raw = mp3.replace(/\.mp3$/, ".pcm");
    writeFileSync(raw, pcm);
    execFileSync("ffmpeg", ["-loglevel", "error", "-y", "-f", "s16le", "-ar", "24000", "-ac", "1", "-i", raw, "-b:a", "64k", mp3]);
    execFileSync("rm", [raw]);
    console.log(job.file);
  }
}
await Promise.all(Array.from({ length: 4 }, worker));

// Listening page: one table per article, a row per segment, a column per variant.
const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
const tables = articles.map((article) => {
  const rows = [...article.segments, { id: article.joined.id, text: `(joined) ${article.joined.from.join(" + ")}` }];
  return `<h2>${esc(article.title)}</h2><table><tr><th>Segment</th>${variants.map((v) => `<th>${esc(v.build(article).style ? v.label.replace(/<L>/g, article.languageName) : v.label)}${v.build(article).language ? ` <code>${v.build(article).language}</code>` : ""}</th>`).join("")}</tr>${rows
    .map((row) => `<tr><td><b>${row.id}</b><div class="t">${esc(row.text)}</div></td>${variants.map((v) => `<td>${Array.from({ length: TAKES }, (_, i) => `<audio controls preload="none" src="out/${article.id}--${row.id}--${v.id}--${i + 1}.mp3"></audio>`).join("")}</td>`).join("")}</tr>`)
    .join("")}</table>`;
});
writeFileSync(join(here, "index.html"), `<!doctype html><meta charset="utf-8"><title>Narration language by ear</title>
<style>:root{color-scheme:light dark}body{font:14px system-ui;margin:16px;background:Canvas;color:CanvasText}table{border-collapse:collapse;width:100%}td,th{border:1px solid #8886;padding:6px;vertical-align:top;text-align:left}th{font-weight:600}.t{color:GrayText;font-size:12px;max-width:260px}audio{display:block;width:180px;height:32px;margin:2px 0}code{font-size:12px}</style>
<h1>PROTOTYPE: narration language by ear</h1><p>Gemini 3.8 Flash Lite TTS, voice Charon. Two takes per cell (the model varies between runs). Question: which column makes the German byline sound German while quotations in the other language keep their own language?</p>
${tables.join("\n")}`);
console.log(`${jobs.length} clips; open ${join(here, "index.html")}`);
