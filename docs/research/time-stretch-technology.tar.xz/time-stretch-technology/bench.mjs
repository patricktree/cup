// Usage: node bench.mjs <module.wasm> <input.pcm> <output.pcm> [factor] [runs]
import { readFileSync, writeFileSync, statSync } from "node:fs";
import { createHash } from "node:crypto";

const [wasmPath, inputPath, outputPath, factorArg = "1.05", runsArg = "5"] = process.argv.slice(2);
const factor = Number(factorArg);
const runs = Number(runsArg);
const sampleRate = 24000;

const module = await WebAssembly.compile(readFileSync(wasmPath));
const imports = {};
const importNames = WebAssembly.Module.imports(module).map((i) => `${i.module}.${i.name}`);
for (const { module: m, name } of WebAssembly.Module.imports(module)) {
  imports[m] ??= {};
  imports[m][name] = (...args) => { if (name === "proc_exit") throw new Error(`proc_exit ${args[0]}`); return 0; };
}
const input = readFileSync(inputPath);
const inputSamples = input.length / 2;
const capacity = Math.ceil(inputSamples / factor) + sampleRate;
const results = [];
let output;
for (let run = 0; run < runs; run++) {
  const { exports } = await WebAssembly.instantiate(module, imports);
  exports._initialize?.();
  const inPtr = exports.stretch_alloc(input.length);
  const outPtr = exports.stretch_alloc(capacity * 2);
  new Uint8Array(exports.memory.buffer, inPtr, input.length).set(input);
  const start = process.cpuUsage();
  const t0 = performance.now();
  const written = exports.stretch(inPtr, inputSamples, outPtr, capacity, factor, sampleRate);
  const wall = performance.now() - t0;
  const cpu = process.cpuUsage(start);
  if (written < 0) throw new Error("stretch failed");
  output = Buffer.from(new Uint8Array(exports.memory.buffer, outPtr, written * 2));
  results.push({ wall, cpu: (cpu.user + cpu.system) / 1000, written, sha: createHash("sha256").update(output).digest("hex").slice(0, 16), memoryMiB: exports.memory.buffer.byteLength / 2 ** 20 });
}
writeFileSync(outputPath, output);
const walls = results.map((r) => r.wall).sort((a, b) => a - b);
const median = walls[Math.floor(walls.length / 2)];
console.log(JSON.stringify({
  wasm: wasmPath.split("/").pop(),
  bytes: statSync(wasmPath).size,
  imports: importNames,
  inputSeconds: inputSamples / sampleRate,
  outputSamples: results[0].written,
  expectedSamples: Math.round(inputSamples / factor),
  achievedFactor: inputSamples / results[0].written,
  medianWallMs: Math.round(median),
  allWallMs: results.map((r) => Math.round(r.wall)),
  realtimeMultiple: Math.round((inputSamples / sampleRate) / (median / 1000)),
  deterministic: new Set(results.map((r) => r.sha)).size === 1,
  outputSha256Prefix: results[0].sha,
  peakMemoryMiB: Math.max(...results.map((r) => r.memoryMiB)),
}));
