#include <stdlib.h>
#define EXPORT(name) __attribute__((export_name(#name)))
#ifdef __cplusplus
extern "C" {
#endif
EXPORT(stretch_alloc) void *stretch_alloc(int bytes) { return malloc((size_t)bytes); }
EXPORT(stretch_free) void stretch_free(void *pointer) { free(pointer); }
#ifdef __cplusplus
}
#endif
