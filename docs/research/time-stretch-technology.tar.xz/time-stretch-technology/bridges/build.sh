#!/bin/sh
# Runs inside the pinned Emscripten container with no network. /src is read-only sources, /bridges the bridges, /work output.
set -eu
WASM_FLAGS="--no-entry -s MALLOC=emmalloc -s ALLOW_MEMORY_GROWTH -s STANDALONE_WASM -s NO_SUPPORT_ERRNO -Oz -flto -Wl,--strip-all -DNDEBUG"
mkdir -p /work/out

emcc /bridges/sonic-bridge.c /src/sonic/sonic.c -I/bridges -I/src/sonic $WASM_FLAGS -o /work/out/sonic.wasm

ST=/src/soundtouch/source/SoundTouch
em++ /bridges/soundtouch-bridge.cpp $ST/SoundTouch.cpp $ST/TDStretch.cpp $ST/RateTransposer.cpp $ST/FIFOSampleBuffer.cpp $ST/AAFilter.cpp $ST/FIRFilter.cpp $ST/InterpolateCubic.cpp $ST/InterpolateLinear.cpp $ST/InterpolateShannon.cpp $ST/cpu_detect_x86.cpp \
  -I/bridges -I/src/soundtouch/include -DSOUNDTOUCH_INTEGER_SAMPLES=1 -DSOUNDTOUCH_DISABLE_X86_OPTIMIZATIONS -DST_NO_EXCEPTION_HANDLING=1 -fno-exceptions $WASM_FLAGS -o /work/out/soundtouch.wasm

em++ -std=c++11 /bridges/signalsmith-bridge.cpp -I/bridges -I/src/stretch -I/src/linear/include -I/src/linear -fno-exceptions $WASM_FLAGS -o /work/out/signalsmith.wasm || echo "signalsmith build failed"

export TMPDIR=/work/tmp; mkdir -p "$TMPDIR"; rm -rf /work/ffmpeg && cp -r /src/ffmpeg-8.0.1 /work/ffmpeg && cd /work/ffmpeg
emconfigure ./configure --cc=emcc --cxx=em++ --ar=emar --ranlib=emranlib --nm=emnm \
  --target-os=none --arch=x86_32 --enable-cross-compile \
  --disable-asm --disable-inline-asm --disable-x86asm --disable-stripping --disable-debug \
  --disable-programs --disable-doc --disable-network --disable-autodetect --disable-runtime-cpudetect \
  --disable-pthreads --disable-w32threads --disable-os2threads \
  --disable-everything --disable-avdevice --disable-avformat --disable-avcodec --disable-swscale --disable-swresample \
  --enable-avfilter --enable-filter=atempo,abuffer,abuffersink --enable-small \
  --extra-cflags="-Oz -flto -DNDEBUG" --extra-ldflags="-Oz -flto" \
  --prefix=/work/ffmpeg-install > /work/out/ffmpeg-configure.log 2>&1
grep -E "^(License|libavfilter|libavutil|Enabled filters)" -A3 /work/out/ffmpeg-configure.log > /work/out/ffmpeg-configure-summary.txt || true
emmake make -j8 > /work/out/ffmpeg-make.log 2>&1
emmake make install > /dev/null 2>&1
ls -la /work/ffmpeg-install/lib > /work/out/ffmpeg-libs.txt
emcc /bridges/ffmpeg-bridge.c -I/bridges -I/work/ffmpeg-install/include /work/ffmpeg-install/lib/libavfilter.a /work/ffmpeg-install/lib/libavutil.a $WASM_FLAGS -o /work/out/ffmpeg-atempo.wasm
ls -la /work/out
