#include "common.h"
#include "sonic.h"
/* Stretches mono 16-bit PCM; returns the number of output samples or -1. */
EXPORT(stretch) int stretch(const short *input, int inputSamples, short *output, int outputCapacity, float speed, int sampleRate) {
  sonicStream stream = sonicCreateStream(sampleRate, 1);
  int written = 0;
  if (stream == NULL) return -1;
  sonicSetSpeed(stream, speed);
  sonicSetQuality(stream, 1);
  if (!sonicWriteShortToStream(stream, input, inputSamples) || !sonicFlushStream(stream)) { sonicDestroyStream(stream); return -1; }
  for (;;) {
    int read = sonicReadShortFromStream(stream, output + written, outputCapacity - written);
    if (read <= 0) break;
    written += read;
  }
  sonicDestroyStream(stream);
  return written;
}
