#include "common.h"
#include "signalsmith-stretch.h"
#include <vector>
extern "C" EXPORT(stretch) int stretch(const short *input, int inputSamples, short *output, int outputCapacity, float speed, int sampleRate) {
  signalsmith::stretch::SignalsmithStretch<float> stretcher(1L); // fixed seed; randomness is only used above x2
  stretcher.presetDefault(1, (float)sampleRate);
  int outputSamples = (int)(inputSamples / speed);
  if (outputSamples > outputCapacity) return -1;
  std::vector<float> in(inputSamples), out(outputSamples);
  for (int i = 0; i < inputSamples; ++i) in[i] = input[i] / 32768.0f;
  float *inChannels[1] = {in.data()};
  float *outChannels[1] = {out.data()};
  if (!stretcher.exact(inChannels, inputSamples, outChannels, outputSamples)) return -1;
  for (int i = 0; i < outputSamples; ++i) {
    float v = out[i] * 32768.0f;
    output[i] = (short)(v > 32767.0f ? 32767 : v < -32768.0f ? -32768 : v);
  }
  return outputSamples;
}
