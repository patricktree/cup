#include "common.h"
#include <stdio.h>
#include <string.h>
#include <libavfilter/avfilter.h>
#include <libavfilter/buffersink.h>
#include <libavfilter/buffersrc.h>
#include <libavutil/channel_layout.h>
#include <libavutil/frame.h>
#include <libavutil/samplefmt.h>
/* abuffer -> atempo -> abuffersink on mono s16. */
EXPORT(stretch) int stretch(const short *input, int inputSamples, short *output, int outputCapacity, float speed, int sampleRate) {
  AVFilterGraph *graph = avfilter_graph_alloc();
  AVFilterContext *source = NULL, *tempo = NULL, *sink = NULL;
  AVFrame *frame = av_frame_alloc();
  char args[256];
  int written = -1, offset = 0;
  const int chunk = 4096;
  if (!graph || !frame) goto done;
  snprintf(args, sizeof args, "sample_rate=%d:sample_fmt=s16:channel_layout=mono:time_base=1/%d", sampleRate, sampleRate);
  if (avfilter_graph_create_filter(&source, avfilter_get_by_name("abuffer"), "in", args, NULL, graph) < 0) goto done;
  snprintf(args, sizeof args, "tempo=%f", speed);
  if (avfilter_graph_create_filter(&tempo, avfilter_get_by_name("atempo"), "tempo", args, NULL, graph) < 0) goto done;
  if (avfilter_graph_create_filter(&sink, avfilter_get_by_name("abuffersink"), "out", NULL, NULL, graph) < 0) goto done;
  if (avfilter_link(source, 0, tempo, 0) < 0 || avfilter_link(tempo, 0, sink, 0) < 0) goto done;
  if (avfilter_graph_config(graph, NULL) < 0) goto done;
  written = 0;
  for (;;) {
    if (offset < inputSamples) {
      int n = inputSamples - offset < chunk ? inputSamples - offset : chunk;
      AVFrame *in = av_frame_alloc();
      in->format = AV_SAMPLE_FMT_S16;
      in->sample_rate = sampleRate;
      in->nb_samples = n;
      in->pts = offset;
      av_channel_layout_default(&in->ch_layout, 1);
      if (av_frame_get_buffer(in, 0) < 0) { written = -1; goto done; }
      memcpy(in->data[0], input + offset, (size_t)n * 2);
      offset += n;
      if (av_buffersrc_add_frame(source, in) < 0) { written = -1; goto done; }
      av_frame_free(&in);
      if (offset >= inputSamples && av_buffersrc_add_frame(source, NULL) < 0) { written = -1; goto done; }
    }
    for (;;) {
      int r = av_buffersink_get_frame(sink, frame);
      if (r < 0) {
        if (r == AVERROR_EOF) goto done;
        if (offset < inputSamples) break;
        written = -1; goto done;
      }
      if (written + frame->nb_samples > outputCapacity) { written = -1; goto done; }
      memcpy(output + written, frame->data[0], (size_t)frame->nb_samples * 2);
      written += frame->nb_samples;
      av_frame_unref(frame);
    }
  }
done:
  av_frame_free(&frame);
  avfilter_graph_free(&graph);
  return written;
}
