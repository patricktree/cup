#include "common.h"
#include "SoundTouch.h"
using namespace soundtouch;
extern "C" EXPORT(stretch) int stretch(const short *input, int inputSamples, short *output, int outputCapacity, float speed, int sampleRate) {
  SoundTouch st;
  st.setSampleRate(sampleRate);
  st.setChannels(1);
  st.setTempo(speed);
  // The soundstretch tool's -speech settings.
  st.setSetting(SETTING_SEQUENCE_MS, 40);
  st.setSetting(SETTING_SEEKWINDOW_MS, 15);
  st.setSetting(SETTING_OVERLAP_MS, 8);
  st.putSamples(input, inputSamples);
  st.flush();
  int written = 0;
  for (;;) {
    int read = st.receiveSamples(output + written, outputCapacity - written);
    if (read <= 0) break;
    written += read;
  }
  return written;
}
