// Usage (from libs/mp3-encoding): node <this> <input.pcm> <bitrate>
import { readFileSync } from "node:fs";
import { pathToFileURL } from "node:url";
const { encodePcmAsMp3 } = await import(pathToFileURL(process.cwd() + "/src/mp3-encoding.ts").href);
const pcm = new Uint8Array(readFileSync(process.argv[2]));
const times = [];
for (let i = 0; i < 3; i++) { const t = performance.now(); await encodePcmAsMp3(pcm, { sampleRate: 24000, bitrateKilobitsPerSecond: Number(process.argv[3]) }); times.push(Math.round(performance.now() - t)); }
console.log(JSON.stringify({ lameWallMs: times }));
