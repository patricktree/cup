// Installs a happy-dom window as the global DOM for React DOM, and exports the module paths of the
// versions Cup pins (resolved from the main checkout's pnpm store; pass its path as CUP_PNPM).
const P = process.env.CUP_PNPM ?? "/Users/pkerschbaum/workspace/cup/node_modules/.pnpm";

const { Window } = await import(`${P}/happy-dom@20.14.6/node_modules/happy-dom/lib/index.js`);
export const window = new Window({ url: "http://localhost/app/recent" });

for (const key of Object.getOwnPropertyNames(window)) {
  if (key in globalThis) continue;
  try {
    const value = window[key];
    globalThis[key] = typeof value === "function" && !/^[A-Z]/.test(key) ? value.bind(window) : value;
  } catch {}
}
globalThis.window = window;
globalThis.document = window.document;
Object.defineProperty(globalThis, "navigator", { value: window.navigator, configurable: true });
globalThis.location = window.location;
globalThis.history = window.history;
globalThis.IS_REACT_ACT_ENVIRONMENT = false;

export const React = (await import(`${P}/react@19.3.0/node_modules/react/index.js`)).default;
export const ReactDOMClient = (await import(`${P}/react-dom@19.3.0_react@19.3.0/node_modules/react-dom/client.js`)).default;
export const RQ = await import(`${P}/@tanstack+react-query@5.104.1_react@19.3.0/node_modules/@tanstack/react-query/build/modern/index.js`);
export const loadRouter = () =>
  import(`${P}/@tanstack+react-router@1.170.42_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@tanstack/react-router/dist/esm/index.js`);

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
