// What hiding a subtree in <Activity> does to ref callbacks, effects, state updates and
// useSyncExternalStore subscriptions. Usage: node refs.mjs
import { React, ReactDOMClient, sleep } from "./setup.mjs";

const h = React.createElement;
const log = [];
const t0 = Date.now();
const note = (message) => log.push(`${String(Date.now() - t0).padStart(5)} ms  ${message}`);

// A minimal external store, like the player host or a query observer.
let storeValue = 0;
const listeners = new Set();
const store = {
  subscribe(listener) {
    listeners.add(listener);
    note(`store subscribe (listeners=${listeners.size})`);
    return () => {
      listeners.delete(listener);
      note(`store unsubscribe (listeners=${listeners.size})`);
    };
  },
  get: () => storeValue,
  set(value) {
    storeValue = value;
    listeners.forEach((listener) => listener());
  },
};

let setChildState;
function Child() {
  const value = React.useSyncExternalStore(store.subscribe, store.get);
  const [state, setState] = React.useState(0);
  setChildState = setState;
  note(`Child render store=${value} state=${state}`);
  const ref = React.useCallback((element) => {
    note(`ref callback attach (${element?.tagName})`);
    return () => note("ref callback cleanup");
  }, []);
  React.useLayoutEffect(() => {
    note("layout effect mount");
    return () => note("layout effect cleanup");
  }, []);
  React.useEffect(() => {
    note("passive effect mount");
    return () => note("passive effect cleanup");
  }, []);
  return h("div", { ref }, `store ${value} state ${state}`);
}

let setMode;
function App() {
  const [mode, _setMode] = React.useState("visible");
  setMode = _setMode;
  return h(React.Activity, { mode }, h(Child));
}

const container = document.createElement("div");
document.body.append(container);
ReactDOMClient.createRoot(container).render(h(App));
await sleep(50);
note("--- hide");
setMode("hidden");
await sleep(50);
note("--- store.set(1) while hidden");
store.set(1);
await sleep(50);
note("--- child setState(1) while hidden");
setChildState(1);
await sleep(50);
note(`hidden DOM: "${container.textContent}" style="${container.firstChild.getAttribute("style")}"`);
note("--- show");
setMode("visible");
await sleep(50);
note(`shown DOM: "${container.textContent}" style="${container.firstChild.getAttribute("style")}"`);
console.log(log.join("\n"));
process.exit(0);
