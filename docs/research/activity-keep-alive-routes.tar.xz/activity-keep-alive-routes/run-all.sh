#!/bin/sh
# Runs every experiment and writes its log to results/. Needs Node 24 and a Cup checkout with
# installed dependencies; set CUP_PNPM to its node_modules/.pnpm directory if it is not the default.
set -eu
cd "$(dirname "$0")"
mkdir -p results
node refs.mjs > results/refs.txt
node query.mjs 0 infinite norerender > results/query-gc0-infinite.txt
node query.mjs 0 infinite > results/query-gc0-infinite-hidden-rerender.txt
node query.mjs 300000 infinite norerender > results/query-gc5min-infinite.txt
node query.mjs 0 suspense norerender > results/query-gc0-suspense-hidden-500ms.txt
HIDDEN_MS=1500 node query.mjs 0 suspense norerender > results/query-gc0-suspense-hidden-1500ms.txt
# the browser condition selects the client builds of the router (the node build renders as a server)
node --conditions=browser router.mjs match > results/router-match.txt 2>&1
HOOK=1 node --conditions=browser router.mjs match > results/router-match-route-hook.txt 2>&1
node --conditions=browser router.mjs component > results/router-component.txt 2>&1
