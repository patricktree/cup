// What hiding a screen in <Activity> does to its TanStack Query observers, polling and effects.
// Usage: node query.mjs <gcTimeMs> <infinite|suspense>
import { React, ReactDOMClient, RQ, sleep } from "./setup.mjs";

const gcTime = Number(process.argv[2] ?? 0);
const kind = process.argv[3] ?? "infinite";
const h = React.createElement;
const log = [];
const t0 = Date.now();
const note = (message) => log.push(`${String(Date.now() - t0).padStart(5)} ms  ${message}`);

const client = new RQ.QueryClient({
  defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false, gcTime, staleTime: 0 } },
});
let fetches = 0;
const key = ["account-history"];

function useScreenQuery() {
  if (kind === "suspense") {
    return RQ.useSuspenseQuery({
      queryKey: key,
      queryFn: async () => {
        fetches++;
        await sleep(20);
        return { status: "pending", n: fetches };
      },
      refetchInterval: 100,
      refetchIntervalInBackground: true,
    });
  }
  return RQ.useInfiniteQuery({
    queryKey: key,
    initialPageParam: 0,
    queryFn: async ({ pageParam }) => {
      fetches++;
      await sleep(20);
      return { items: [{ status: "pending", n: fetches }], next: pageParam < 2 ? pageParam + 1 : undefined };
    },
    getNextPageParam: (page) => page.next,
    refetchInterval: 100,
  });
}

function Screen({ label }) {
  const query = useScreenQuery();
  const pages = query.data?.pages?.length ?? (query.data ? 1 : 0);
  note(`render label=${label} status=${query.status} isLoading=${query.isLoading} fetchStatus=${query.fetchStatus} pages=${pages}`);
  React.useLayoutEffect(() => {
    note("layout effect mount");
    return () => note("layout effect cleanup");
  }, []);
  React.useEffect(() => {
    note("passive effect mount");
    return () => note("passive effect cleanup");
  }, []);
  return h("p", null, `pages ${pages}`);
}

let setMode;
let setLabel;
function App() {
  const [mode, _setMode] = React.useState("visible");
  const [label, _setLabel] = React.useState("a");
  setMode = _setMode;
  setLabel = _setLabel;
  return h(
    RQ.QueryClientProvider,
    { client },
    h(React.Activity, { mode }, h(React.Suspense, { fallback: h("p", null, "loading") }, h(Screen, { label }))),
  );
}

const cacheState = () => {
  const query = client.getQueryCache().find({ queryKey: key });
  return query ? `in cache, observers=${query.getObserversCount()}, fetchStatus=${query.state.fetchStatus}` : "not in cache";
};

const container = document.createElement("div");
document.body.append(container);
ReactDOMClient.createRoot(container).render(h(App));
await sleep(350);
note(`before hide: fetches=${fetches}, query ${cacheState()}`);
if (kind === "infinite") {
  note("fetchNextPage x2");
  await client.getQueryCache().find({ queryKey: key }).observers[0].fetchNextPage();
  await client.getQueryCache().find({ queryKey: key }).observers[0].fetchNextPage();
}
await sleep(50);
const beforeHide = fetches;
note("--- hide");
setMode("hidden");
await sleep(50);
note(`hidden +50 ms: query ${cacheState()}; DOM text="${container.textContent}" display=${container.firstChild?.style?.display}`);
if (process.argv[4] !== "norerender") setLabel("b");
await sleep(Number(process.env.HIDDEN_MS ?? 500));
note(`hidden end: fetches while hidden=${fetches - beforeHide}; query ${cacheState()}`);
const beforeShow = fetches;
note("--- show");
setMode("visible");
await sleep(10);
note(`shown +10 ms: query ${cacheState()}; DOM text="${container.textContent}"`);
await sleep(300);
note(`shown +310 ms: fetches since show=${fetches - beforeShow}; query ${cacheState()}; DOM text="${container.textContent}"`);
console.log(`gcTime=${gcTime} kind=${kind}\n${log.join("\n")}`);
process.exit(0);
