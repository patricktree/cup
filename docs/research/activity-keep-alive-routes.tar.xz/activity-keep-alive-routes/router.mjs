// Whether a shell layout can keep its Recents child mounted in <Activity> under TanStack Router.
// Usage: node router.mjs <match|component>
//   match:     the layout renders <Match routeId="/_shell/recent"> inside <Activity> once visited
//   component: the layout renders the Recents component itself (no <Match>) inside <Activity>
import { React, ReactDOMClient, RQ, loadRouter, sleep } from "./setup.mjs";

const variant = process.argv[2] ?? "match";
const R = await loadRouter();
const h = React.createElement;
const log = [];
const t0 = Date.now();
const note = (message) => log.push(`${String(Date.now() - t0).padStart(5)} ms  ${message}`);
const originalError = console.error;
console.error = (...args) => note(`console.error: ${args.map((a) => a?.stack ?? String(a)).join(" ").slice(0, 1500)}`);
process.on("uncaughtException", (error) => note(`uncaught: ${error.message.split("\n")[0]}`));

const client = new RQ.QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0, staleTime: 0 } } });
let fetches = 0;

function RecentPage() {
  const query = RQ.useQuery({
    queryKey: ["history"],
    queryFn: async () => {
      fetches++;
      await sleep(10);
      return ["one", "two"];
    },
    refetchInterval: 100,
  });
  const [counter, setCounter] = React.useState(0);
  globalThis.setRecentsCounter = setCounter;
  // HOOK=1 makes Recents read its own match, as `Route.useSearch()` or `Route.useParams()` would
  if (process.env.HOOK) recentRoute.useMatch();
  React.useEffect(() => {
    note("Recents effect mount");
    return () => note("Recents effect cleanup");
  }, []);
  note(`Recents render status=${query.status} counter=${counter}`);
  return h(
    "section",
    { id: "recents" },
    h("button", { id: "inc", onClick: () => setCounter((c) => c + 1) }, `count ${counter}`),
    query.isLoading ? "Loading tracks…" : (query.data ?? []).join(","),
    h(R.Link, { to: "/audiobooks/$conversionId", params: { conversionId: "c1" }, id: "open" }, "open"),
    // the Add and account dialogs are children of Recents
    h(R.Outlet),
  );
}

function DetailPage() {
  const { conversionId } = detailRoute.useParams();
  note(`Detail render ${conversionId}`);
  return h("section", { id: "detail" }, `detail ${conversionId}`);
}

const RECENT = "/_shell/recent";

function KeepAliveOutlet() {
  const childRouteId = R.useRouterState({
    select: (state) => state.matches[state.matches.findIndex((m) => m.routeId === "/_shell") + 1]?.routeId,
  });
  const [isRecentVisited, setIsRecentVisited] = React.useState(false);
  if (childRouteId === RECENT && !isRecentVisited) setIsRecentVisited(true);
  const isRecentShown = childRouteId === RECENT;
  note(`KeepAliveOutlet render child=${childRouteId}`);
  const kept = variant === "match" ? h(R.Match, { routeId: RECENT }) : h(RecentPage);
  return h(
    React.Fragment,
    null,
    isRecentVisited && h(React.Activity, { mode: isRecentShown ? "visible" : "hidden" }, kept),
    !isRecentShown && h(R.Outlet),
  );
}

class Boundary extends React.Component {
  state = { error: null };
  static getDerivedStateFromError(error) {
    return { error };
  }
  render() {
    return this.state.error ? h("p", { id: "error" }, `boundary: ${this.state.error.message.split("\n")[0]}`) : this.props.children;
  }
}

const rootRoute = R.createRootRoute({ component: () => h(Boundary, null, h(R.Outlet)) });
const shellRoute = R.createRoute({ getParentRoute: () => rootRoute, id: "_shell", component: KeepAliveOutlet });
const recentRoute = R.createRoute({ getParentRoute: () => shellRoute, path: "recent", component: RecentPage });
const addRoute = R.createRoute({ getParentRoute: () => recentRoute, path: "add", component: () => h("dialog", { open: true }, "add dialog") });
const detailRoute = R.createRoute({ getParentRoute: () => shellRoute, path: "audiobooks/$conversionId", component: DetailPage });
const routeTree = rootRoute.addChildren([shellRoute.addChildren([recentRoute.addChildren([addRoute]), detailRoute])]);
const router = R.createRouter({
  routeTree,
  history: R.createMemoryHistory({ initialEntries: ["/recent"] }),
  scrollRestoration: true,
});

const container = document.createElement("div");
document.body.append(container);
ReactDOMClient.createRoot(container).render(
  h(RQ.QueryClientProvider, { client }, h(R.RouterProvider, { router })),
);
const dom = () => container.textContent.replace(/\s+/g, " ");
const recentsDisplay = () => document.getElementById("recents")?.parentElement && document.getElementById("recents")?.style.display;

await sleep(300);
document.getElementById("inc")?.click();
await sleep(20);
note(`on Recents: DOM="${dom()}" fetches=${fetches}`);
note("--- navigate to detail");
await router.navigate({ to: "/audiobooks/$conversionId", params: { conversionId: "c1" } });
await sleep(400);
note(`on detail: DOM="${dom()}" recents display=${recentsDisplay()} fetches=${fetches}`);
note("--- state update inside hidden Recents (+10)");
globalThis.setRecentsCounter((c) => c + 10);
await sleep(100);
note(`on detail after hidden update: DOM="${dom()}"`);
note("--- navigate back");
router.history.back();
await sleep(300);
note(`back on Recents: DOM="${dom()}" recents display=${recentsDisplay()} fetches=${fetches}`);
note("--- navigate to /recent/add");
await router.navigate({ to: "/recent/add" });
await sleep(100);
note(`on add: DOM="${dom()}"`);
console.log(`variant=${variant}\n${log.join("\n")}`);
console.error = originalError;
process.exit(0);
