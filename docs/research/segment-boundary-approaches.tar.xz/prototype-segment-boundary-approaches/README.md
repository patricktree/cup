# PROTOTYPE: segment boundary approaches (throwaway, never merged)

Answers [Which approach makes segment boundaries inaudible?](https://github.com/patricktree/cup/issues/291), part of [Map: narration flows across segment boundaries](https://github.com/patricktree/cup/issues/288). Builds on the diagnosis prototype on the branch `prototype/segment-boundaries`.

**Verdict (2026-11-13, operator by ear, blind, all 10 boundaries judged):** overlap and cut is the only candidate that clearly beats today's speech policy 6. It flowed at 9 of 10 boundaries and was picked best at 7, across every boundary kind; the one jump was step title → paragraph (Anthropic 95 → 96). Policy 6, the blind control, flowed at 4 of 10. Unspoken context flowed at 4, the continuity style at 5 and both together at 4, so none of them is distinguishable from the control. Loudness evening made no audible difference. Whisper heard no skipped or repeated word at any boundary edge once the cut aligned word by word. A first character-count aligner misplaced 2 of 26 cuts on numbers that Whisper writes differently from the text.

## Candidates

Every segment was synthesized on its own on 2026-11-13 through Cloudflare AI Gateway with the production request shape (Gemini 3.8 Flash-Lite TTS, Charon, narration language and its style annotation, `audio/l16` at 24 kHz), stretched with Sonic ×1.05 and encoded as policy 6 does, then joined byte for byte.

- `p6`: policy 6 as it is today.
- `style`: the language style followed by "Carry on reading mid-article in one steady narrating voice."
- `ctx`: the previous and next narration chunk in the same text block, with the `speech_metadata` annotation's `start_index`/`end_index` byte range on this chunk only (undocumented, see `docs/research/gemini-tts-unspoken-context.md` on `research/gemini-tts-unspoken-context`).
- `ctxstyle`: `ctx` with the continuity style.
- `overlap`: the previous chunk's last sentence, this chunk and the next chunk's first sentence are spoken in one request. Whisper large v3 turbo (Workers AI) transcribes the provider audio with word timestamps; its words are aligned with the block's words (longest common subsequence), and the cut goes in the middle of the longest silence below −45 dBFS in the largest inter-word gap at each chunk edge, before the Sonic stretch. Each side keeps half the model's own pause, so joins pause for 790–1,270 ms, about what the model pauses between paragraphs in one request.

Each take also exists loudness-evened: a gain to −19 LUFS integrated per segment.

## Cost of overlap and cut

On these 13 segments the requests synthesized 395 s of provider audio to keep 244 s: 1.62 times the audio, from 1.06 for a 659-character paragraph to 4.16 for a 49-character step title. Audio output is about 99% of synthesis cost, so synthesis costs roughly that factor more, plus one Whisper pass over the provider audio.

## Files

- `render.mjs`: the 65 paid synthesis calls and Whisper passes, five candidates per segment.
- `build-page.mjs`: joins, measures every boundary, checks each segment's edge words against Whisper, and writes `summary.json` and the page data.
- `make-html.mjs`: writes the blind listening page (`page/index.html`), published privately as the [Segment Boundary Approaches](https://claude.ai/artifact/Mv5d8sC8yDQVvXbsdQvGsg) artifact.
- `summary.json`: per segment and candidate the usage, cut points, loudness, edge silence and transcript; per boundary the gap, level and pitch steps.
- `answers.md`: the operator's answers as pasted from the page.
