// PROTOTYPE (patricktree/cup#291), throwaway, never merged: renders each candidate approach for
// making segment boundaries inaudible, per narration chunk and independently of its neighbours'
// audio, then checks with Whisper which words each segment speaks.
// Usage (from libs/audiobook-production):
//   node prototype-segment-boundary-approaches/render.mjs <env-file> <out-dir>
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join } from "node:path";

import { analyzeMp3 } from "@cup/audiobook-production";
import { encodePcmAsMp3 } from "@cup/mp3-encoding";
import { stretchPcm } from "@cup/time-stretching";

const [envFile, outDir] = process.argv.slice(2);
for (const line of readFileSync(envFile, "utf8").split("\n")) {
  const m = /^(CLOUDFLARE_ACCOUNT_ID|CLOUDFLARE_API_KEY)=(.*)$/.exec(line.trim());
  if (m) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
}
mkdirSync(outDir, { recursive: true });

const RATE = 24_000;
const SPEED = 1.05; // speech policy 6
const LUFS_TARGET = -19;
const CONTINUITY = "Carry on reading mid-article in one steady narrating voice.";

const cases = new URL("../../narration-source-analysis/test/evals/cases/", import.meta.url);
const chunksOf = (name) =>
  JSON.parse(readFileSync(new URL(`${name}/expected.json`, cases), "utf8")).map((u) => u.narrationText);

// As in the diagnosis prototype: splits one paragraph at the sentence nearest its middle.
function splitAtMiddleSentence(text) {
  const ends = [...text.matchAll(/(?<=[.!?])\s+/gu)].map((m) => m.index);
  const at = ends.reduce((best, i) => (Math.abs(i - text.length / 2) < Math.abs(best - text.length / 2) ? i : best));
  return [text.slice(0, at), text.slice(at).trimStart()];
}

const anthropic = chunksOf("anthropic-demystifying-evals-for-ai-agents");
const derstandard = chunksOf("derstandard-source-with-navigation-noise");
const [deA, deB] = splitAtMiddleSentence(derstandard[13]);

// Each run lists its segments plus one real article neighbour on each side, which only serve as
// context. `joins[i]` is how segment i and i + 1 meet in the article: a paragraph break or, for a
// split narration block, a space.
export const runs = [
  {
    id: "en-anthropic", title: "English: Anthropic, “Demystifying evals”, chunks 91–96", language: "en", firstIndex: 91,
    before: anthropic[90], texts: anthropic.slice(91, 97), after: anthropic[97],
  },
  {
    id: "de-derstandard", title: "German: derStandard, farm subsidies, chunks 8–12", language: "de-AT", firstIndex: 8,
    before: derstandard[7], texts: derstandard.slice(8, 13), after: derstandard[13],
  },
  {
    id: "de-split", title: "German: derStandard chunk 13 split mid-paragraph", language: "de-AT", firstIndex: 13, split: true,
    before: derstandard[12], texts: [deA, deB], after: derstandard[14],
  },
];
const separators = (run) => {
  // between before|s0, s0|s1, …, s(n-1)|after
  const n = run.texts.length;
  return Array.from({ length: n + 1 }, (_, i) => (run.split && i > 0 && i < n ? " " : "\n\n"));
};

const languageStyle = (tag) => {
  const name = new Intl.DisplayNames(["en"], { type: "language" }).of(tag.split("-")[0]);
  return `Read in ${name} with standard ${name} pronunciation.`;
};
const firstSentence = (t) => (t.match(/^[\s\S]*?[.!?](?=\s|$)/u)?.[0] ?? t).trim();
const lastSentence = (t) => {
  const ends = [...t.matchAll(/(?<=[.!?:])\s+/gu)].map((m) => m.index + m[0].length);
  return t.slice(ends.filter((i) => i < t.length - 1).at(-1) ?? 0).trim();
};
const bytes = (s) => Buffer.byteLength(s);

export const VARIANTS = [
  { id: "p6", name: "Policy 6 (today)" },
  { id: "style", name: "Continuity style" },
  { id: "ctx", name: "Unspoken context" },
  { id: "ctxstyle", name: "Unspoken context + continuity style" },
  { id: "overlap", name: "Overlap and cut" },
];

// Builds the text block for one segment under one variant.
function block(run, i, variant) {
  const sep = separators(run);
  const prev = i === 0 ? run.before : run.texts[i - 1];
  const next = i === run.texts.length - 1 ? run.after : run.texts[i + 1];
  const own = run.texts[i];
  const lang = languageStyle(run.language);
  const style = variant === "style" || variant === "ctxstyle" ? `${lang} ${CONTINUITY}` : lang;
  if (variant === "p6" || variant === "style") return { text: own, annotation: { type: "speech_metadata", style } };
  if (variant === "ctx" || variant === "ctxstyle") {
    const head = `${prev}${sep[i]}`;
    return {
      text: `${head}${own}${sep[i + 1]}${next}`,
      annotation: { type: "speech_metadata", style, start_index: bytes(head), end_index: bytes(head + own) },
    };
  }
  // overlap: speak the previous chunk's last sentence and the next chunk's first sentence, cut later.
  const tail = lastSentence(prev);
  const lead = firstSentence(next);
  return { text: `${tail}${sep[i]}${own}${sep[i + 1]}${lead}`, annotation: { type: "speech_metadata", style }, tail, lead, sepBefore: sep[i], sepAfter: sep[i + 1] };
}

async function synthesize(text, annotation, language) {
  const body = [
    {
      provider: "google-ai-studio",
      endpoint: "v1beta/interactions",
      headers: { "Api-Revision": "2026-05-20", "Content-Type": "application/json", "cf-aig-collect-log-payload": "false" },
      query: {
        model: "gemini-3.8-flash-lite-tts",
        input: [{ type: "user_input", content: [{ type: "text", text, annotations: [annotation] }] }],
        response_format: { type: "audio", mime_type: "audio/l16", sample_rate: RATE },
        generation_config: { speech_config: [{ voice: "Charon", language }] },
        stream: false,
      },
    },
  ];
  for (let attempt = 1; ; attempt++) {
    const res = await fetch(`https://gateway.ai.cloudflare.com/v1/${process.env.CLOUDFLARE_ACCOUNT_ID}/default`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "cf-aig-authorization": `Bearer ${process.env.CLOUDFLARE_API_KEY}`,
        "cf-aig-skip-cache": "true",
        "cf-aig-collect-log-payload": "false",
        "cf-aig-metadata": JSON.stringify({ conversionId: "prototype-segment-boundary-approaches" }),
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(120_000),
    });
    const json = await res.json().catch(() => ({}));
    const data = json.steps?.flatMap((s) => s.content ?? []).find((c) => c.type === "audio")?.data;
    if (res.ok && data) return { pcm: new Uint8Array(Buffer.from(data, "base64")), usage: json.usage };
    if (attempt >= 4) throw new Error(`synthesis failed ${res.status}: ${JSON.stringify(json).slice(0, 300)}`);
    await new Promise((r) => setTimeout(r, 3000 * attempt));
  }
}

async function transcribe(mp3, language) {
  for (let attempt = 1; ; attempt++) {
    const res = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/openai/whisper-large-v3-turbo`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${process.env.CLOUDFLARE_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ audio: Buffer.from(mp3).toString("base64"), language: language.split("-")[0] }),
      },
    );
    const json = await res.json().catch(() => ({}));
    if (res.ok && json.result) {
      return { text: json.result.text, words: json.result.segments.flatMap((s) => s.words ?? []) };
    }
    if (attempt >= 4) throw new Error(`transcription failed ${res.status}: ${JSON.stringify(json).slice(0, 300)}`);
    await new Promise((r) => setTimeout(r, 3000 * attempt));
  }
}

const encode = async (pcm) => {
  const mp3 = await encodePcmAsMp3(pcm, { bitrateKilobitsPerSecond: 128, sampleRate: RATE });
  const { audioStart, audioEnd } = analyzeMp3(mp3);
  return mp3.slice(audioStart, audioEnd);
};
const norm = (s) => s.toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}]/gu, "");

function frameDb(pcm) {
  const view = new Int16Array(pcm.buffer, pcm.byteOffset, pcm.byteLength / 2);
  const out = new Float64Array(Math.floor(view.length / 240));
  for (let f = 0; f < out.length; f++) {
    let s = 0;
    for (let i = f * 240; i < (f + 1) * 240; i++) s += (view[i] / 32768) ** 2;
    out[f] = 10 * Math.log10(s / 240 + 1e-12);
  }
  return out;
}

// Finds the cut before text word `boundary` of the synthesized block: aligns the transcript's words
// with the block's words (longest common subsequence over normalized words), takes the largest
// inter-word gap between the last matched word before the boundary and the first matched word at or
// after it, and cuts in the middle of the longest silence (≤ −45 dBFS) around that gap.
const tokens = (s) => s.split(/\s+/u).map(norm).filter(Boolean);
function cutAt(words, db, blockText, boundary) {
  const a = tokens(blockText), b = words.map((w) => norm(w.word));
  const L = Array.from({ length: a.length + 1 }, () => new Int32Array(b.length + 1));
  for (let i = a.length - 1; i >= 0; i--) for (let j = b.length - 1; j >= 0; j--) L[i][j] = a[i] && a[i] === b[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const pairs = [];
  for (let i = 0, j = 0; i < a.length && j < b.length; ) {
    if (a[i] === b[j]) { pairs.push([i, j]); i++; j++; } else if (L[i + 1][j] >= L[i][j + 1]) i++; else j++;
  }
  const before = pairs.filter(([i]) => i < boundary).at(-1)?.[1] ?? 0;
  const after = pairs.find(([i]) => i >= boundary)?.[1] ?? words.length - 1;
  let best = null;
  for (let j = Math.max(1, before + 1); j <= Math.max(1, after); j++) {
    const gap = words[j].start - words[j - 1].end;
    if (!best || gap > best.gap) best = { j, gap };
  }
  const from = Math.floor((words[best.j - 1].end - 0.25) * 100);
  const to = Math.ceil((words[best.j].start + 0.25) * 100);
  let run = null, s = -1;
  for (let f = from; f <= to; f++) {
    const silent = f < to && db[f] <= -45;
    if (silent && s < 0) s = f;
    if (!silent && s >= 0) { if (!run || f - s > run[1] - run[0]) run = [s, f]; s = -1; }
  }
  const at = run ? (run[0] + run[1]) / 2 / 100 : (words[best.j - 1].end + words[best.j].start) / 2;
  return { at, wordIndex: best.j, silenceMs: run ? (run[1] - run[0]) * 10 : 0 };
}

const lufsOf = (mp3Path) => {
  const res = execFileSync("sh", ["-c", `ffmpeg -hide_banner -nostats -i "${mp3Path}" -af ebur128 -f null - 2>&1 | grep -E "^\\s+I:" | tail -1`]).toString();
  return +/(-?[\d.]+) LUFS/.exec(res)?.[1];
};
function gain(pcm, db) {
  const factor = 10 ** (db / 20);
  const src = new Int16Array(pcm.buffer.slice(pcm.byteOffset, pcm.byteOffset + pcm.byteLength));
  for (let i = 0; i < src.length; i++) src[i] = Math.max(-32768, Math.min(32767, Math.round(src[i] * factor)));
  return new Uint8Array(src.buffer);
}

async function renderSegment(run, i, variant) {
  const name = `${run.id}-s${i}-${variant}`;
  const done = join(outDir, `${name}.json`);
  if (existsSync(done)) return JSON.parse(readFileSync(done, "utf8"));
  const b = block(run, i, variant);
  const { pcm: provider, usage } = await synthesize(b.text, b.annotation, run.language);
  let pcm = provider;
  let cut;
  if (variant === "overlap") {
    // Align the provider audio with Whisper and keep only this chunk, cut in the pauses around it.
    const t = await transcribe(await encode(provider), run.language);
    const db = frameDb(provider);
    const start = cutAt(t.words, db, b.text, tokens(b.tail).length);
    const end = cutAt(t.words, db, b.text, tokens(b.tail).length + tokens(run.texts[i]).length);
    const a = Math.round(start.at * RATE) * 2, z = Math.round(end.at * RATE) * 2;
    pcm = provider.slice(a, z);
    cut = { startS: start.at, endS: end.at, startSilenceMs: start.silenceMs, endSilenceMs: end.silenceMs, providerSeconds: provider.byteLength / 2 / RATE, providerTranscript: t.text };
  }
  const stretched = await stretchPcm(pcm, { sampleRate: RATE, speedFactor: SPEED });
  const mp3 = await encode(stretched);
  writeFileSync(join(outDir, `${name}.mp3`), mp3);
  const lufs = lufsOf(join(outDir, `${name}.mp3`));
  const evened = await encode(gain(stretched, LUFS_TARGET - lufs));
  writeFileSync(join(outDir, `${name}-even.mp3`), evened);
  const spoken = await transcribe(mp3, run.language);
  const record = { name, run: run.id, index: i, variant, text: run.texts[i], request: { text: b.text, annotation: b.annotation }, usage, lufs, gainDb: LUFS_TARGET - lufs, cut, transcript: spoken.text };
  writeFileSync(done, JSON.stringify(record, null, 2));
  return record;
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  const jobs = runs.flatMap((run) => run.texts.flatMap((_, i) => VARIANTS.map((v) => [run, i, v.id])));
  console.log(`${jobs.length} segment renders`);
  const queue = [...jobs];
  await Promise.all(
    Array.from({ length: 5 }, async () => {
      while (queue.length) {
        const [run, i, v] = queue.shift();
        const started = Date.now();
        try {
          const r = await renderSegment(run, i, v);
          console.log(r.name, "ok", `${((Date.now() - started) / 1000).toFixed(1)} s`, JSON.stringify(r.transcript).slice(0, 80));
        } catch (error) {
          console.log(`${run.id}-s${i}-${v}`, "FAILED", error.message);
        }
      }
    }),
  );
  writeFileSync(join(outDir, "runs.json"), JSON.stringify({ runs, variants: VARIANTS, lufsTarget: LUFS_TARGET, continuity: CONTINUITY }, null, 2));
}
