// PROTOTYPE (patricktree/cup#291), throwaway, never merged: writes the blind A/B listening page.
// Usage: node make-html.mjs <page-dir>
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const [pageDir] = process.argv.slice(2);
const { variants, lufsTarget, continuity, runs } = JSON.parse(readFileSync(join(pageDir, "page-data.json"), "utf8"));
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
const signed = (x, d = 1) => (Number.isFinite(x) ? `${x >= 0 ? "+" : "−"}${Math.abs(x).toFixed(d)}` : "–");
const nameOf = Object.fromEntries(variants.map((v) => [v.id, v.name]));
const LETTERS = "ABCDE";

function envSvg(pts, label) {
  const w = 240, h = 34, step = w / Math.max(1, pts.length - 1);
  const y = (d) => h - ((d + 60) / 60) * h;
  const line = pts.map((d, i) => `${(i * step).toFixed(1)},${y(d).toFixed(1)}`).join(" ");
  return `<svg class="env" viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(label)}"><polygon points="0,${h} ${line} ${w},${h}" class="env-fill"></polygon><line x1="${w / 2}" x2="${w / 2}" y1="0" y2="${h}" class="env-mid"></line></svg>`;
}

function wordsCell(x) {
  const issues = [
    ...(x.before.missing.length ? [`end skipped: ${x.before.missing.join(" ")}`] : []),
    ...(x.before.extra.length ? [`end extra: ${x.before.extra.join(" ")}`] : []),
    ...(x.after.missing.length ? [`start skipped: ${x.after.missing.join(" ")}`] : []),
    ...(x.after.extra.length ? [`start extra: ${x.after.extra.join(" ")}`] : []),
  ];
  return issues.length
    ? `<span class="words bad" title="${esc(`Whisper heard …${x.before.heard} ║ ${x.after.heard}…`)}">${esc(issues.join("; "))}</span>`
    : `<span class="words ok" title="${esc(`Whisper heard …${x.before.heard} ║ ${x.after.heard}…`)}">words match</span>`;
}

function boundaryCard(run, b) {
  const rows = b.order.map((vid, k) => {
    const L = LETTERS[k], x = b.variants[vid];
    return `<div class="cand" data-variant="${vid}" data-letter="${L}">
      <button type="button" class="play" data-variant="${vid}" data-at="${x.raw.at.toFixed(2)}" aria-pressed="false"><span class="letter">${L}</span><span class="real">${esc(nameOf[vid])}</span></button>
      <div class="vis">${envSvg(x.raw.env, `Level across boundary, candidate ${L}`)}<span class="nums"><span data-raw="${x.raw.gapMs} ms gap · ${signed(x.raw.levelJump)} dB" data-even="${x.even.gapMs} ms gap · ${signed(x.even.levelJump)} dB">${x.raw.gapMs} ms gap · ${signed(x.raw.levelJump)} dB</span> · ${wordsCell(x)}</span></div>
      <div class="judge" role="radiogroup" aria-label="Candidate ${L}">
        ${["flows", "jumps"].map((v) => `<label><input type="radio" name="${b.id}-${vid}" id="${b.id}-${vid}-${v}" value="${v}"> ${v === "flows" ? "Flows" : "Jumps"}</label>`).join("")}
        <label class="best"><input type="radio" name="${b.id}-best" id="${b.id}-best-${vid}" value="${vid}"> Best</label>
      </div>
    </div>`;
  });
  const c = b.cont;
  return `<article class="bnd" id="${b.id}" data-label="${esc(`${run.title} · ${b.index} · ${b.kind}`)}" data-run="${run.id}">
  <header class="bnd-head"><span class="chip chip-${b.group}">${esc(b.kind)}</span><span class="idx">chunks ${esc(b.index)}</span></header>
  <p class="seam"><span class="tail">…${esc(b.tail.replace(/\n\n/g, " ¶ "))}</span><span class="cut" aria-label="segment boundary">║</span><span class="headtxt">${esc(b.head.replace(/\n\n/g, " ¶ "))}…</span></p>
  <div class="cands">${rows.join("")}
    <div class="cand ref"><button type="button" class="play alt" data-src="audio/${run.contFile}" data-at="${c ? c.at.toFixed(2) : 5}" aria-pressed="false"><span class="letter">R</span><span>Continuous reference</span></button><div class="vis">${c ? envSvg(c.env, "Level across the same spot in the continuous take") : ""}<span class="nums">${c ? `${c.pauseMs} ms pause · ${signed(c.levelJump)} dB` : "spot not located"}</span></div><div class="judge"></div></div>
  </div>
  <div class="extra"><label><input type="checkbox" id="${b.id}-words"> I heard a repeated or skipped word at this boundary</label>
  <label class="note-l" for="${b.id}-note">Notes</label><textarea id="${b.id}-note" rows="2" placeholder="Optional: which letter, what you hear"></textarea></div>
</article>`;
}

const html = `<title>Segment Boundary Approaches</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&family=Fraunces:opsz,wght@9..144,600&display=swap">
<style>
/* Layout: one listening column; each boundary lists five blind candidates (A–E) plus the continuous reference, each with its own verdict. */
:root{--bg:#f6f7f4;--surface:#ffffff;--fg:#1c211d;--muted:#5f6a62;--line:#dfe3dc;--accent:#1f6f5c;--alt:#8a5a14;--chip:#e7efe9;--warn:#f4ead9;--bad:#a3341f;
--display:"Fraunces",Georgia,serif;--text:"IBM Plex Sans",system-ui,sans-serif;--mono:"IBM Plex Mono",ui-monospace,monospace}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#121513;--surface:#1a1f1c;--fg:#e6ebe6;--muted:#97a39a;--line:#2c332e;--accent:#5cc4a6;--alt:#e0ae62;--chip:#22302a;--warn:#33291b;--bad:#f08a72;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#121513;--surface:#1a1f1c;--fg:#e6ebe6;--muted:#97a39a;--line:#2c332e;--accent:#5cc4a6;--alt:#e0ae62;--chip:#22302a;--warn:#33291b;--bad:#f08a72;color-scheme:dark}
body{background:var(--bg);color:var(--fg);font:15px/1.55 var(--text);padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:28px 64px}
main{max-width:980px;margin:0 auto;display:flex;flex-direction:column;gap:20px}
h1{font:600 30px/1.15 var(--display);margin:0;text-wrap:balance}h2{font:600 21px/1.25 var(--display);margin:28px 0 0;text-wrap:balance}
.lede{max-width:68ch;color:var(--muted);margin:0}.lede strong{color:var(--fg);font-weight:600}
.controls{display:flex;flex-wrap:wrap;gap:10px 22px;align-items:center;background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:12px 16px;position:sticky;top:env(safe-area-inset-top,0px);z-index:2}
.controls label{display:flex;gap:8px;align-items:center;font-weight:500}.controls .hint{color:var(--muted);font-size:13px}
.bnd{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:16px;display:flex;flex-direction:column;gap:12px;min-width:0}
.bnd-head{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between}
.chip{font:500 12px/1 var(--text);padding:5px 8px;border-radius:999px;background:var(--chip);color:var(--accent)}.chip-heading,.chip-after-heading{background:var(--warn);color:var(--alt)}
.idx{font:12px var(--mono);color:var(--muted)}
.seam{margin:0;font-size:14px;line-height:1.5}.tail{color:var(--muted)}.cut{color:var(--accent);font-weight:600;padding:0 6px}
.cands{display:flex;flex-direction:column;gap:6px}
.cand{display:grid;grid-template-columns:minmax(150px,auto) minmax(0,1fr) auto;gap:6px 14px;align-items:center;padding:6px 0;border-top:1px solid var(--line)}
@media (max-width:640px){.cand{grid-template-columns:1fr}}
.play{display:flex;gap:10px;align-items:center;font:500 14px var(--text);padding:7px 12px;border-radius:6px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer;text-align:left}
.play .letter{font:600 15px var(--mono);min-width:1ch}.play .real{display:none;font-size:13px}body.revealed .play .real{display:inline}
.play.alt{border-color:var(--alt);color:var(--alt)}.play[aria-pressed="true"]{background:var(--accent);color:var(--surface)}.play.alt[aria-pressed="true"]{background:var(--alt)}
.play:focus-visible,input:focus-visible,textarea:focus-visible,button:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.vis{display:flex;gap:10px;align-items:center;min-width:0;flex-wrap:wrap}
.env{width:160px;max-width:100%;height:34px;flex:none}.env-fill{fill:var(--chip);stroke:var(--accent);stroke-width:1}.ref .env-fill{stroke:var(--alt)}.env-mid{stroke:var(--fg);stroke-dasharray:2 3;stroke-width:1}
.nums{font:12px var(--mono);color:var(--muted);font-variant-numeric:tabular-nums}.words.ok{color:var(--accent)}.words.bad{color:var(--bad)}
.judge{display:flex;gap:12px;font-size:14px;flex-wrap:wrap}.judge label{display:flex;gap:5px;align-items:center}.judge .best{color:var(--alt);font-weight:500}
.extra{display:flex;flex-direction:column;gap:6px;border-top:1px solid var(--line);padding-top:10px;font-size:14px}.extra>label:first-child{display:flex;gap:8px;align-items:center}
.note-l{font-size:12px;color:var(--muted)}textarea{font:14px var(--text);color:var(--fg);background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:8px;width:100%;box-sizing:border-box;resize:vertical}
details.runs{font-size:14px}details.runs summary{cursor:pointer;color:var(--muted)}
.runlist{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px 20px;padding-top:10px}.runlist label{display:flex;flex-direction:column;gap:4px;font-size:13px;color:var(--muted)}
audio{width:100%;height:34px}
.final{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:16px;display:flex;flex-direction:column;gap:10px}
.final fieldset{border:0;padding:0;margin:0;display:flex;flex-wrap:wrap;gap:6px 16px}.final legend{font-weight:600;padding-bottom:6px}
.bar{position:sticky;bottom:calc(12px + env(safe-area-inset-bottom,0px));align-self:center;display:flex;gap:10px;align-items:center;background:var(--surface);border:1px solid var(--line);border-radius:999px;padding:8px 10px 8px 16px;box-shadow:0 4px 18px rgb(0 0 0/.12);font-size:13px;color:var(--muted)}
.bar button{font:500 14px var(--text);padding:8px 14px;border-radius:999px;border:0;background:var(--accent);color:var(--surface);cursor:pointer}
#out{width:100%;font:12px var(--mono)}
</style>
<main>
<h1>Which approach makes segment boundaries inaudible?</h1>
<p class="lede">Prototype for <a href="https://github.com/patricktree/cup/issues/291">Which approach makes segment boundaries inaudible?</a> The same 10 boundaries you judged in the diagnosis, each rendered five ways on 2026-11-13. Every segment is still synthesized on its own (Gemini 3.8 Flash-Lite, Charon, Sonic ×1.05) and the segments are joined byte for byte, as the narration track joins them.</p>
<p class="lede"><strong>The candidates are blind</strong> and shuffled per boundary as A–E. Behind the letters are policy 6 as it is today; a continuity style (“${esc(continuity)}” after the language style); unspoken context, meaning the previous and next narration chunk sent in the same text block with the annotation's byte range on this chunk only; that context plus the continuity style; and overlap and cut, where the previous chunk's last sentence and the next chunk's first sentence are spoken too, then cut away in the pauses, located with Whisper. <strong>R</strong> is the continuous reference from the diagnosis: the whole run as one request.</p>
<p class="lede">Each button plays 5 s on both sides of the boundary. For each candidate, mark whether it <strong>flows</strong> like one person reading on, or <strong>jumps</strong>, and pick the best one. Whisper checked the words at every segment edge; a red note means it heard a skipped or extra word. <strong>Loudness evened</strong> swaps in the same takes with every segment set to ${lufsTarget} LUFS. Try it on the German runs, then answer the question at the end. Your answers stay in this browser; <em>Copy answers</em> names the real candidates.</p>
<div class="controls"><label><input type="checkbox" id="even"> Loudness evened (${lufsTarget} LUFS per segment)</label><label><input type="checkbox" id="reveal"> Reveal candidate names</label><span class="hint">Reveal only after judging.</span></div>
${runs.map((run) => `<section aria-labelledby="h-${run.id}"><h2 id="h-${run.id}">${esc(run.title)}</h2>
${run.boundaries.map((b) => boundaryCard(run, b)).join("\n")}
<details class="runs"><summary>Whole run per candidate (shows names)</summary><div class="runlist">${variants.map((v) => `<label>${esc(v.name)}, ${run.tracks[v.id].raw.seconds.toFixed(1)} s<audio controls preload="none" data-raw="audio/${run.tracks[v.id].raw.file}" data-even="audio/${run.tracks[v.id].even.file}" src="audio/${run.tracks[v.id].raw.file}"></audio></label>`).join("")}<label>Continuous reference, ${run.contSeconds.toFixed(1)} s<audio controls preload="none" src="audio/${run.contFile}"></audio></label></div></details>
</section>`).join("\n")}
<section class="final" aria-labelledby="h-final"><h2 id="h-final" style="margin:0">Loudness evening</h2>
<fieldset id="loud"><legend>With loudness evened, the boundaries sound</legend>${["better", "no different", "worse"].map((v) => `<label><input type="radio" name="loud" id="loud-${v.replace(/\s/g, "")}" value="${v}"> ${v}</label>`).join("")}</fieldset>
<label class="note-l" for="final-note">Overall notes</label><textarea id="final-note" rows="3" placeholder="Optional: anything across boundaries"></textarea></section>
<details><summary>Answers as text</summary><textarea id="out" rows="14" readonly></textarea></details>
<div class="bar"><span id="count">0 boundaries answered</span><button type="button" id="copy">Copy answers</button></div>
</main>
<script>
const NAMES = ${JSON.stringify(nameOf)};
const TRACKS = ${JSON.stringify(Object.fromEntries(runs.map((r) => [r.id, r.tracks])))};
const player = new Audio();
let stopAt = 0, current = null;
player.addEventListener("timeupdate", () => { if (player.currentTime >= stopAt) stop(); });
function stop(){ player.pause(); if (current) current.setAttribute("aria-pressed","false"); current = null; }
const evenOn = () => document.getElementById("even").checked;
document.addEventListener("play", (e) => { if (e.target.tagName === "AUDIO") stop(); for (const a of document.querySelectorAll("audio")) if (a !== e.target) a.pause(); }, true);
for (const btn of document.querySelectorAll(".play")) btn.addEventListener("click", async () => {
  if (current === btn) { stop(); return; }
  stop(); for (const a of document.querySelectorAll("audio")) a.pause();
  const run = btn.closest(".bnd").dataset.run;
  const rel = btn.dataset.src ?? "audio/" + TRACKS[run][btn.dataset.variant][evenOn() ? "even" : "raw"].file;
  const src = new URL(rel, location.href).href;
  if (player.src !== src) { player.src = src; await new Promise((r) => player.addEventListener("loadedmetadata", r, { once: true })); }
  player.currentTime = Math.max(0, +btn.dataset.at - 5); stopAt = +btn.dataset.at + 5; current = btn; btn.setAttribute("aria-pressed","true"); player.play();
});
function applyEven(){
  const on = evenOn(); stop();
  for (const s of document.querySelectorAll("[data-raw][data-even]")) {
    if (s.tagName === "AUDIO") { s.pause(); s.src = on ? s.dataset.even : s.dataset.raw; } else s.textContent = on ? s.dataset.even : s.dataset.raw;
  }
}
document.getElementById("even").addEventListener("change", applyEven);
document.getElementById("reveal").addEventListener("change", (e) => document.body.classList.toggle("revealed", e.target.checked));
const KEY = "segment-boundary-approaches-v1";
const LETTER = {};
for (const c of document.querySelectorAll(".cand[data-variant]")) LETTER[c.closest(".bnd").id + "/" + c.dataset.variant] = c.dataset.letter;
function collect(){
  const bnds = [...document.querySelectorAll(".bnd")].map((b) => {
    const v = {};
    for (const c of b.querySelectorAll(".cand[data-variant]")) v[c.dataset.variant] = c.querySelector('input[name$="-' + c.dataset.variant + '"]:checked')?.value;
    return { id: b.id, label: b.dataset.label, v, best: b.querySelector('input[name$="-best"]:checked')?.value, words: b.querySelector('input[id$="-words"]').checked, note: b.querySelector("textarea").value.trim() };
  });
  return { bnds, loud: document.querySelector('input[name="loud"]:checked')?.value, note: document.getElementById("final-note").value.trim() };
}
function render(){
  const a = collect();
  const done = a.bnds.filter((x) => Object.values(x.v).some(Boolean) || x.best || x.note).length;
  document.getElementById("count").textContent = done + " of " + a.bnds.length + " boundaries answered";
  const name = (b, id) => NAMES[id] + " (" + LETTER[b.id + "/" + id] + ")";
  const lines = a.bnds.map((x) => {
    const flows = Object.entries(x.v).filter(([, s]) => s === "flows").map(([id]) => name(x, id));
    const jumps = Object.entries(x.v).filter(([, s]) => s === "jumps").map(([id]) => name(x, id));
    return "- " + x.label + ": flows: " + (flows.join(", ") || "none") + "; jumps: " + (jumps.join(", ") || "none") + (x.best ? "; best: " + name(x, x.best) : "") + (x.words ? "; heard a repeated or skipped word" : "") + (x.note ? "; " + x.note : "");
  });
  lines.push("- Loudness evened: " + (a.loud ?? "(no answer)") + (a.note ? "; " + a.note : ""));
  lines.push("- Listened with loudness evened at the end: " + (evenOn() ? "yes" : "no"));
  document.getElementById("out").value = lines.join("\\n");
  try { localStorage.setItem(KEY, JSON.stringify(a)); } catch {}
}
try {
  const saved = JSON.parse(localStorage.getItem(KEY) || "null");
  if (saved) {
    for (const s of saved.bnds) {
      const b = document.getElementById(s.id); if (!b) continue;
      for (const [vid, val] of Object.entries(s.v)) if (val) { const i = document.getElementById(s.id + "-" + vid + "-" + val); if (i) i.checked = true; }
      if (s.best) { const i = document.getElementById(s.id + "-best-" + s.best); if (i) i.checked = true; }
      b.querySelector('input[id$="-words"]').checked = !!s.words; b.querySelector("textarea").value = s.note || "";
    }
    if (saved.loud) { const i = document.querySelector('input[name="loud"][value="' + saved.loud + '"]'); if (i) i.checked = true; }
    document.getElementById("final-note").value = saved.note || "";
  }
} catch {}
document.addEventListener("input", render); document.addEventListener("change", render); render();
document.getElementById("copy").addEventListener("click", async () => {
  const text = document.getElementById("out").value;
  try { await navigator.clipboard.writeText(text); document.getElementById("count").textContent = "Copied"; }
  catch { const o = document.getElementById("out"); o.closest("details").open = true; o.select(); document.getElementById("count").textContent = "Select and copy the text above"; }
});
</script>`;
writeFileSync(join(pageDir, "index.html"), html);
console.log("wrote", join(pageDir, "index.html"));
