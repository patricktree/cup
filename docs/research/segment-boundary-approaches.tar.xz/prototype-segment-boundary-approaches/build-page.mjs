// PROTOTYPE (patricktree/cup#291), throwaway, never merged: joins each variant's segments byte for
// byte (as the narration track does), measures every boundary, checks the spoken words at each
// segment's edges, and writes the page data.
// Usage: node build-page.mjs <out-dir> <page-dir> <continuous-dir>
import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join } from "node:path";

const [outDir, pageDir, contDir] = process.argv.slice(2);
mkdirSync(join(pageDir, "audio"), { recursive: true });
const { runs, variants, lufsTarget, continuity } = JSON.parse(readFileSync(join(outDir, "runs.json"), "utf8"));
const RATE = 24_000, FRAME = 240, SILENCE_DB = -45;

const decode = (mp3) =>
  new Int16Array(Uint8Array.from(execFileSync("ffmpeg", ["-v", "error", "-i", mp3, "-f", "s16le", "-ac", "1", "-ar", String(RATE), "-"], { maxBuffer: 1 << 28 })).buffer);
const lufsOf = (mp3) => +/(-?[\d.]+) LUFS/.exec(execFileSync("sh", ["-c", `ffmpeg -hide_banner -nostats -i "${mp3}" -af ebur128 -f null - 2>&1 | grep -E "^\\s+I:" | tail -1`]).toString())?.[1];
function frameDb(pcm) {
  const out = new Float64Array(Math.floor(pcm.length / FRAME));
  for (let f = 0; f < out.length; f++) {
    let s = 0;
    for (let i = f * FRAME; i < (f + 1) * FRAME; i++) s += (pcm[i] / 32768) ** 2;
    out[f] = 10 * Math.log10(s / FRAME + 1e-12);
  }
  return out;
}
const median = (xs) => { const s = xs.filter(Number.isFinite).sort((a, b) => a - b); return s.length ? s[Math.floor(s.length / 2)] : NaN; };
function speechLevel(db, from, to) {
  const fr = db.slice(Math.max(0, Math.round(from * 100)), Math.round(to * 100)).filter((d) => d > SILENCE_DB);
  return fr.length ? 10 * Math.log10(fr.reduce((s, d) => s + 10 ** (d / 10), 0) / fr.length) : NaN;
}
function f0Track(pcm, db) {
  const win = 960, minLag = RATE / 300, maxLag = RATE / 60;
  const out = new Float64Array(db.length).fill(NaN);
  for (let f = 0; f < db.length; f++) {
    if (db[f] < -35) continue;
    const start = f * FRAME - win / 2;
    if (start < 0 || start + win + maxLag > pcm.length) continue;
    let e0 = 0;
    for (let i = 0; i < win; i++) e0 += pcm[start + i] ** 2;
    let best = 0, bestLag = 0;
    for (let lag = Math.floor(minLag); lag <= maxLag; lag++) {
      let c = 0, e1 = 0;
      for (let i = 0; i < win; i++) { c += pcm[start + i] * pcm[start + i + lag]; e1 += pcm[start + i + lag] ** 2; }
      const r = c / Math.sqrt(e0 * e1 + 1e-9);
      if (r > best) { best = r; bestLag = lag; }
    }
    if (best > 0.6) out[f] = RATE / bestLag;
  }
  return out;
}
const f0In = (f0, from, to) => median(Array.from(f0.slice(Math.max(0, Math.round(from * 100)), Math.round(to * 100))));
const semis = (a, b) => 12 * Math.log2(b / a);
function silences(db, minMs) {
  const out = []; let s = -1;
  for (let f = 0; f <= db.length; f++) {
    const silent = f < db.length && db[f] <= SILENCE_DB;
    if (silent && s < 0) s = f;
    if (!silent && s >= 0) { if ((f - s) * 10 >= minMs) out.push([s / 100, f / 100]); s = -1; }
  }
  return out;
}
function edges(db) {
  let a = 0; while (a < db.length && db[a] <= SILENCE_DB) a++;
  let b = db.length; while (b > 0 && db[b - 1] <= SILENCE_DB) b--;
  return { lead: a / 100, trail: (db.length - b) / 100, speechStart: a / 100, speechEnd: b / 100 };
}
const envelope = (db, from, to) => { const pts = []; for (let t = from; t < to; t += 0.02) pts.push(Math.max(-60, db[Math.round(t * 100)] ?? -60)); return pts; };

// Spoken-text guard: aligns the transcript's words with the narration chunk's words (longest
// common subsequence over normalized words) and reports what differs at the segment's edges.
const words = (s) => s.split(/\s+/u).map((w) => ({ raw: w, n: w.toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}]/gu, "") })).filter((w) => w.n);
function guard(text, transcript) {
  const a = words(text), b = words(transcript);
  const L = Array.from({ length: a.length + 1 }, () => new Int32Array(b.length + 1));
  for (let i = a.length - 1; i >= 0; i--) for (let j = b.length - 1; j >= 0; j--) L[i][j] = a[i].n === b[j].n ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const pairs = [];
  for (let i = 0, j = 0; i < a.length && j < b.length; ) {
    if (a[i].n === b[j].n) { pairs.push([i, j]); i++; j++; } else if (L[i + 1][j] >= L[i][j + 1]) i++; else j++;
  }
  if (!pairs.length) return { ok: false, startExtra: b.map((w) => w.raw), startMissing: a.map((w) => w.raw), endExtra: [], endMissing: [], matched: 0, textWords: a.length };
  const [fi, fj] = pairs[0], [li, lj] = pairs.at(-1);
  const r = {
    startMissing: a.slice(0, fi).map((w) => w.raw), startExtra: b.slice(0, fj).map((w) => w.raw),
    endMissing: a.slice(li + 1).map((w) => w.raw), endExtra: b.slice(lj + 1).map((w) => w.raw),
    matched: pairs.length, textWords: a.length,
  };
  r.ok = !r.startMissing.length && !r.startExtra.length && !r.endMissing.length && !r.endExtra.length;
  return r;
}

function kindOf(run, a, b) {
  if (run.split) return { kind: "mid-paragraph split", group: "split" };
  const isTitle = (t) => t.length < 80 && !/[.!?:”"]$/.test(t.trim());
  if (b.includes("\n\n") && b.split("\n\n").every(isTitle)) return { kind: "paragraph → heading-only segment", group: "heading" };
  if (b.includes("\n\n")) return { kind: "paragraph → heading-led segment (new section)", group: "heading" };
  if (isTitle(b)) return { kind: "paragraph → step title as its own segment", group: "heading" };
  if (a.split("\n\n").every(isTitle)) return { kind: "heading- or title-only segment → paragraph", group: "after-heading" };
  if (isTitle(a)) return { kind: "step title → paragraph", group: "after-heading" };
  return { kind: "paragraph → paragraph", group: "paragraph" };
}

// Deterministic per-boundary shuffle, so the blind letters stay put across rebuilds.
function shuffled(list, seed) {
  let h = 2166136261;
  for (const c of seed) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  const out = [...list];
  for (let i = out.length - 1; i > 0; i--) { h = Math.imul(h ^ (h >>> 13), 2246822519) >>> 0; const j = h % (i + 1); [out[i], out[j]] = [out[j], out[i]]; }
  return out;
}

const page = [], summary = [];
for (const run of runs) {
  const cFile = `${run.id}-continuous.mp3`;
  copyFileSync(join(contDir, cFile), join(pageDir, "audio", cFile));
  const cont = decode(join(pageDir, "audio", cFile)), contDb = frameDb(cont), contF0 = f0Track(cont, contDb), contEdges = edges(contDb);
  const contPauses = silences(contDb, 120).filter(([s, e]) => s > contEdges.speechStart && e < contEdges.speechEnd);
  const totalChars = run.texts.reduce((s, t) => s + t.length, 0);

  const perVariant = {};
  for (const v of variants) {
    const segs = run.texts.map((text, i) => {
      const rec = JSON.parse(readFileSync(join(outDir, `${run.id}-s${i}-${v.id}.json`), "utf8"));
      const out = {};
      for (const even of [false, true]) {
        const mp3 = join(outDir, `${run.id}-s${i}-${v.id}${even ? "-even" : ""}.mp3`);
        const pcm = decode(mp3), db = frameDb(pcm), e = edges(db), f0 = f0Track(pcm, db);
        out[even ? "even" : "raw"] = {
          mp3, seconds: pcm.length / RATE, ...e, db, lufs: even ? lufsOf(mp3) : rec.lufs,
          levelStart: speechLevel(db, e.speechStart, e.speechStart + 3), levelEnd: speechLevel(db, e.speechEnd - 3, e.speechEnd),
          f0Start: f0In(f0, e.speechStart, e.speechStart + 2), f0End: f0In(f0, e.speechEnd - 2, e.speechEnd), f0All: f0In(f0, e.speechStart, e.speechEnd),
        };
      }
      return { text, rec, guard: guard(text, rec.transcript), ...out };
    });
    const tracks = {};
    for (const mode of ["raw", "even"]) {
      const file = `${run.id}-${v.id}${mode === "even" ? "-even" : ""}.mp3`;
      writeFileSync(join(pageDir, "audio", file), Buffer.concat(segs.map((s) => readFileSync(s[mode].mp3))));
      const pcm = decode(join(pageDir, "audio", file));
      const db = frameDb(pcm);
      let offset = 0;
      const bs = [];
      for (let i = 0; i < segs.length - 1; i++) {
        const a = segs[i][mode], b = segs[i + 1][mode];
        offset += a.seconds;
        const gapRun = silences(db, 10).find(([s, e]) => s <= offset + 0.2 && e >= offset - 0.2);
        bs.push({
          at: offset, gapMs: gapRun ? Math.round((gapRun[1] - gapRun[0]) * 1000) : 0,
          trailMs: Math.round(a.trail * 1000), leadMs: Math.round(b.lead * 1000),
          levelJump: b.levelStart - a.levelEnd, f0Jump: semis(a.f0End, b.f0Start),
          env: envelope(db, Math.max(0, offset - 4), offset + 4),
        });
      }
      tracks[mode] = { file, seconds: pcm.length / RATE, boundaries: bs };
    }
    perVariant[v.id] = { segs, tracks };
  }

  // The continuous spot: the longest pause near the boundary's share of the text, as in the diagnosis.
  const contSpeech = contEdges.speechEnd - contEdges.speechStart;
  let charsBefore = 0;
  const boundaries = [];
  for (let i = 0; i < run.texts.length - 1; i++) {
    charsBefore += run.texts[i].length;
    const expected = contEdges.speechStart + (contSpeech * charsBefore) / totalChars;
    const near = contPauses.filter(([s, e]) => Math.abs((s + e) / 2 - expected) < 4).sort((x, y) => y[1] - y[0] - (x[1] - x[0]))[0];
    const cp = near ? (near[0] + near[1]) / 2 : expected;
    const { kind, group } = kindOf(run, run.texts[i], run.texts[i + 1]);
    const id = `${run.id}-b${i}`;
    boundaries.push({
      id, index: `${run.firstIndex + i} → ${run.firstIndex + i + 1}`, kind, group,
      tail: run.texts[i].slice(-110), head: run.texts[i + 1].slice(0, 110),
      cont: near ? { at: cp, pauseMs: Math.round((near[1] - near[0]) * 1000), levelJump: speechLevel(contDb, near[1], near[1] + 3) - speechLevel(contDb, near[0] - 3, near[0]), f0Jump: semis(f0In(contF0, near[0] - 2, near[0]), f0In(contF0, near[1], near[1] + 2)), env: envelope(contDb, Math.max(0, cp - 4), cp + 4) } : null,
      order: shuffled(variants.map((v) => v.id), id),
      variants: Object.fromEntries(variants.map((v) => {
        const pv = perVariant[v.id];
        return [v.id, {
          raw: pv.tracks.raw.boundaries[i], even: pv.tracks.even.boundaries[i],
          // Words at this boundary: the end of segment i and the start of segment i + 1.
          before: { ok: !pv.segs[i].guard.endMissing.length && !pv.segs[i].guard.endExtra.length, missing: pv.segs[i].guard.endMissing, extra: pv.segs[i].guard.endExtra, heard: pv.segs[i].rec.transcript.trim().split(/\s+/).slice(-6).join(" ") },
          after: { ok: !pv.segs[i + 1].guard.startMissing.length && !pv.segs[i + 1].guard.startExtra.length, missing: pv.segs[i + 1].guard.startMissing, extra: pv.segs[i + 1].guard.startExtra, heard: pv.segs[i + 1].rec.transcript.trim().split(/\s+/).slice(0, 6).join(" ") },
        }];
      })),
    });
  }
  page.push({
    id: run.id, title: run.title, contFile: cFile, contSeconds: cont.length / RATE, boundaries,
    tracks: Object.fromEntries(variants.map((v) => [v.id, { raw: { file: perVariant[v.id].tracks.raw.file, seconds: perVariant[v.id].tracks.raw.seconds }, even: { file: perVariant[v.id].tracks.even.file, seconds: perVariant[v.id].tracks.even.seconds } }])),
    segRows: run.texts.map((text, i) => ({
      index: run.firstIndex + i, chars: text.length,
      v: Object.fromEntries(variants.map((v) => { const s = perVariant[v.id].segs[i]; return [v.id, { lufs: s.raw.lufs, gainDb: s.rec.gainDb, seconds: s.raw.seconds, leadMs: Math.round(s.raw.lead * 1000), trailMs: Math.round(s.raw.trail * 1000), f0All: s.raw.f0All, inputTokens: s.rec.usage?.total_input_tokens ?? s.rec.usage?.input_tokens, guard: s.guard }]; })),
    })),
  });
  summary.push({
    run: run.id,
    segments: run.texts.map((text, i) => ({
      index: run.firstIndex + i, chars: text.length,
      variants: Object.fromEntries(variants.map((v) => {
        const s = perVariant[v.id].segs[i];
        return [v.id, { seconds: +s.raw.seconds.toFixed(2), lufs: s.raw.lufs, leadMs: Math.round(s.raw.lead * 1000), trailMs: Math.round(s.raw.trail * 1000), f0Hz: Math.round(s.raw.f0All), usage: s.rec.usage, cut: s.rec.cut, edgesMatch: s.guard.ok, startMissing: s.guard.startMissing, startExtra: s.guard.startExtra, endMissing: s.guard.endMissing, endExtra: s.guard.endExtra, transcript: s.rec.transcript }];
      })),
    })),
    boundaries: boundaries.map((b) => ({
      index: b.index, kind: b.kind,
      continuous: b.cont && { pauseMs: b.cont.pauseMs, levelJumpDb: +b.cont.levelJump.toFixed(1), f0JumpSemitones: +b.cont.f0Jump.toFixed(1) },
      variants: Object.fromEntries(variants.map((v) => { const x = b.variants[v.id]; return [v.id, Object.fromEntries(["raw", "even"].map((m) => [m, { gapMs: x[m].gapMs, levelJumpDb: +x[m].levelJump.toFixed(1), f0JumpSemitones: +x[m].f0Jump.toFixed(1) }]))]; })),
    })),
  });
}
writeFileSync(join(pageDir, "..", "summary.json"), JSON.stringify({ lufsTarget, continuity, runs: summary }, null, 2));
writeFileSync(join(pageDir, "page-data.json"), JSON.stringify({ variants, lufsTarget, continuity, runs: page }));
for (const r of summary) for (const b of r.boundaries) console.log(r.run, b.index, b.kind, "| cont", b.continuous?.pauseMs, b.continuous?.levelJumpDb, b.continuous?.f0JumpSemitones, "|", variants.map((v) => `${v.id} ${b.variants[v.id].raw.gapMs}ms ${b.variants[v.id].raw.levelJumpDb}dB ${b.variants[v.id].raw.f0JumpSemitones}st`).join(" · "));
for (const r of summary) for (const s of r.segments) for (const [v, x] of Object.entries(s.variants)) if (!x.edgesMatch) console.log("EDGE", r.run, s.index, v, JSON.stringify({ sm: x.startMissing, se: x.startExtra, em: x.endMissing, ee: x.endExtra }));
