// Blind ranking: Gemini 3.8 Flash hears four byline clips in a rotated order and ranks them by
// how natively German the pronunciation sounds. Four rotations cancel position bias.
// Usage: CLOUDFLARE_ENV_FILE=/abs/path/.env.local node rank.mjs
import fs from "node:fs/promises";
import path from "node:path";

const base = import.meta.dirname;
const outputPath = path.join(base, "ranking.json");
if (!process.env.CLOUDFLARE_ENV_FILE) throw new Error("Set CLOUDFLARE_ENV_FILE");
process.loadEnvFile(process.env.CLOUDFLARE_ENV_FILE);
const { CLOUDFLARE_ACCOUNT_ID: accountId, CLOUDFLARE_API_KEY: apiKey } = process.env;
if (!accountId || !apiKey) throw new Error("Missing Cloudflare credentials");

const clips = ["byline-none", "byline-lang-de-DE", "byline-lang-en-US", "byline-style"];
const audio = Object.fromEntries(
  await Promise.all(
    clips.map(async (id) => [id, (await fs.readFile(path.join(base, `${id}.mp3`))).toString("base64")]),
  ),
);
const rounds = [];
await fs.writeFile(outputPath, "[]", { flag: "wx" });

for (let rotation = 0; rotation < clips.length; rotation += 1) {
  const order = clips.map((_, index) => clips[(index + rotation) % clips.length]);
  const content = [
    {
      type: "text",
      text: 'Four synthesized clips follow, labelled 1 to 4, each reading the same three Austrian personal names. Rank them from most to least native German (Austrian/German) pronunciation of the names. Reply with JSON only: {"ranking": [labels, best first], "notes": {"1": short note, ...}}.',
    },
  ];
  for (const [index, id] of order.entries()) {
    content.push({ type: "text", text: `Clip ${index + 1}:` });
    content.push({ type: "input_audio", input_audio: { data: audio[id], format: "mp3" } });
  }
  const response = await fetch(
    `https://gateway.ai.cloudflare.com/v1/${accountId}/default/google-ai-studio/v1beta/openai/chat/completions`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "cf-aig-authorization": `Bearer ${apiKey}`,
        "cf-aig-collect-log-payload": "false",
      },
      body: JSON.stringify({
        model: "gemini-3.8-flash",
        reasoning_effort: "medium",
        messages: [{ role: "user", content }],
        response_format: { type: "json_object" },
      }),
      signal: AbortSignal.timeout(120_000),
    },
  );
  const payload = await response.json();
  const answer = JSON.parse(payload.choices[0].message.content);
  const ranking = answer.ranking.map((label) => order[Number(label) - 1]);
  const notes = Object.fromEntries(
    Object.entries(answer.notes ?? {}).map(([label, note]) => [order[Number(label) - 1], note]),
  );
  rounds.push({ rotation, order, ranking, notes });
  await fs.writeFile(outputPath, JSON.stringify(rounds, null, 2));
  console.log(JSON.stringify({ rotation, ranking, notes }));
}
