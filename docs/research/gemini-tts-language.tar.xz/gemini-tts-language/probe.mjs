// Probes how gemini-3.8-flash-lite-tts reacts to speech_config.language, system_instruction
// and a speech_metadata style, all sent through Cloudflare AI Gateway like production.
// Usage: CLOUDFLARE_ENV_FILE=/abs/path/.env.local node probe.mjs
import childProcess from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import util from "node:util";

const execFile = util.promisify(childProcess.execFile);
const base = import.meta.dirname;
const outputPath = path.join(base, "results.json");
const model = "gemini-3.8-flash-lite-tts";
const voice = "Charon";

const byline = "Gerald John, Alicia Prager, Sandra Schieder";
const mixedGerman =
  "Der Korrespondent Michael Thompson sagte am Telefon: „This is a historic day for Europe.“ Danach ging die Sitzung im Parlament weiter.";
const englishWithGermanNames =
  "Reporting from Vienna, our correspondents Gerald John and Sandra Schieder spoke with officials at the Bundeskanzleramt.";

const cases = [
  { id: "byline-none", text: byline },
  { id: "byline-lang-de-DE", text: byline, language: "de-DE" },
  { id: "byline-lang-de", text: byline, language: "de" },
  { id: "byline-lang-German", text: byline, language: "German" },
  { id: "byline-lang-en-US", text: byline, language: "en-US" },
  { id: "byline-lang-xx-XX", text: byline, language: "xx-XX" },
  { id: "byline-lang-th-TH", text: byline, language: "th-TH" },
  {
    id: "byline-system-instruction",
    text: byline,
    systemInstruction:
      "The transcript is in German. Speak it as a native German speaker with German pronunciation.",
  },
  {
    id: "byline-style",
    text: byline,
    style: "Read in German with standard German pronunciation.",
  },
  { id: "mixed-de-none", text: mixedGerman },
  { id: "mixed-de-lang-de-DE", text: mixedGerman, language: "de-DE" },
  { id: "en-names-none", text: englishWithGermanNames },
  { id: "en-names-lang-en-US", text: englishWithGermanNames, language: "en-US" },
  { id: "en-names-lang-de-DE", text: englishWithGermanNames, language: "de-DE" },
];

if (!process.env.CLOUDFLARE_ENV_FILE) throw new Error("Set CLOUDFLARE_ENV_FILE");
process.loadEnvFile(process.env.CLOUDFLARE_ENV_FILE);
const { CLOUDFLARE_ACCOUNT_ID: accountId, CLOUDFLARE_API_KEY: apiKey } = process.env;
if (!accountId || !apiKey) throw new Error("Missing Cloudflare credentials");

const run = { date: new Date().toISOString(), model, voice, results: [] };
// Exclusive creation prevents an accidental paid rerun.
await fs.writeFile(outputPath, JSON.stringify(run, null, 2), { flag: "wx" });

for (const testCase of cases) {
  const content = { type: "text", text: testCase.text };
  if (testCase.style) content.annotations = [{ type: "speech_metadata", style: testCase.style }];
  const query = {
    model,
    input: [{ type: "user_input", content: [content] }],
    response_format: { type: "audio", mime_type: "audio/l16", sample_rate: 24_000 },
    generation_config: {
      speech_config: [{ voice, ...(testCase.language ? { language: testCase.language } : {}) }],
    },
    ...(testCase.systemInstruction ? { system_instruction: testCase.systemInstruction } : {}),
    stream: false,
  };
  const record = { ...testCase, request: query };
  run.results.push(record);
  const began = performance.now();
  const response = await fetch(`https://gateway.ai.cloudflare.com/v1/${accountId}/default`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "cf-aig-authorization": `Bearer ${apiKey}`,
      "cf-aig-skip-cache": "true",
      "cf-aig-collect-log-payload": "false",
    },
    body: JSON.stringify([
      {
        provider: "google-ai-studio",
        endpoint: "v1beta/interactions",
        headers: { "Content-Type": "application/json", "Api-Revision": "2026-05-20" },
        query,
      },
    ]),
    signal: AbortSignal.timeout(90_000),
  });
  record.httpStatus = response.status;
  record.gatewayLogId = response.headers.get("cf-aig-log-id");
  record.seconds = (performance.now() - began) / 1000;
  const body = await response.text();
  let payload;
  try {
    payload = JSON.parse(body);
  } catch {
    payload = body;
  }
  if (!response.ok) {
    record.error = payload;
  } else {
    record.status = payload.status;
    record.usage = payload.usage;
    const audio = payload.steps?.flatMap((step) => step.content ?? []).find((c) => c.type === "audio");
    if (!audio) {
      record.error = { noAudio: true, status: payload.status, errors: payload.errors };
    } else {
      const pcm = Buffer.from(audio.data, "base64");
      record.audioSeconds = pcm.length / 48_000;
      const rawPath = path.join(base, `${testCase.id}.pcm`);
      await fs.writeFile(rawPath, pcm);
      await execFile("ffmpeg", ["-v", "error", "-n", "-f", "s16le", "-ar", "24000", "-ac", "1",
        "-i", rawPath, "-codec:a", "libmp3lame", "-b:a", "128k", rawPath.replace(/\.pcm$/u, ".mp3")]);
      await fs.rm(rawPath);
    }
  }
  await fs.writeFile(outputPath, JSON.stringify(run, null, 2));
  console.log(testCase.id, record.httpStatus, record.audioSeconds ?? JSON.stringify(record.error));
}
