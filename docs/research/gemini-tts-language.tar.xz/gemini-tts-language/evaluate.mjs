// Transcribes each probe MP3 with Whisper (language auto-detected) and asks Gemini 3.8 Flash,
// blind to the request, how each name and sentence is pronounced.
// Usage: CLOUDFLARE_ENV_FILE=/abs/path/.env.local node evaluate.mjs
import fs from "node:fs/promises";
import path from "node:path";

const base = import.meta.dirname;
const outputPath = path.join(base, "evaluation.json");
if (!process.env.CLOUDFLARE_ENV_FILE) throw new Error("Set CLOUDFLARE_ENV_FILE");
process.loadEnvFile(process.env.CLOUDFLARE_ENV_FILE);
const { CLOUDFLARE_ACCOUNT_ID: accountId, CLOUDFLARE_API_KEY: apiKey } = process.env;
if (!accountId || !apiKey) throw new Error("Missing Cloudflare credentials");

const { results } = JSON.parse(await fs.readFile(path.join(base, "results.json"), "utf8"));
const evaluation = [];
await fs.writeFile(outputPath, "[]", { flag: "wx" });

for (const result of results.filter((row) => row.audioSeconds)) {
  const audio = await fs.readFile(path.join(base, `${result.id}.mp3`));
  const whisperResponse = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/@cf/openai/whisper-large-v3-turbo`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ audio: audio.toString("base64"), task: "transcribe" }),
      signal: AbortSignal.timeout(90_000),
    },
  );
  const whisper = (await whisperResponse.json()).result;

  const judgeResponse = await fetch(
    `https://gateway.ai.cloudflare.com/v1/${accountId}/default/google-ai-studio/v1beta/openai/chat/completions`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "cf-aig-authorization": `Bearer ${apiKey}`,
        "cf-aig-collect-log-payload": "false",
      },
      body: JSON.stringify({
        model: "gemini-3.8-flash",
        reasoning_effort: "low",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Listen to this synthesized speech clip. Reply with JSON only: {\"transcript\": verbatim words spoken, \"spokenLanguages\": languages heard, \"names\": [{\"name\", \"pronunciation\": \"German\" | \"English\" | \"mixed\" | \"other\", \"note\"}], \"sentences\": [{\"text\", \"accent\": which language's phonetics the speaker uses}], \"extraSpeech\": any words that sound like instructions or commentary rather than content, or null}.",
              },
              { type: "input_audio", input_audio: { data: audio.toString("base64"), format: "mp3" } },
            ],
          },
        ],
        response_format: { type: "json_object" },
      }),
      signal: AbortSignal.timeout(90_000),
    },
  );
  const judgePayload = await judgeResponse.json();
  const judgeText = judgePayload.choices?.[0]?.message?.content;
  let judge;
  try {
    judge = JSON.parse(judgeText);
  } catch {
    judge = judgeText ?? judgePayload;
  }
  const row = {
    id: result.id,
    whisperLanguage: whisper?.transcription_info?.language,
    whisperLanguageProbability: whisper?.transcription_info?.language_probability,
    whisperText: whisper?.text,
    judge,
  };
  evaluation.push(row);
  await fs.writeFile(outputPath, JSON.stringify(evaluation, null, 2));
  console.log(JSON.stringify(row));
}
