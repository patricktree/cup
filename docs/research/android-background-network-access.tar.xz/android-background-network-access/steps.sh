#!/usr/bin/env bash
# The steps of the 2026-11-14 run, on the mobile E2E suite's AVD. Run from the repository root
# after `pnpm turbo run turbo:build --filter=@cup/web-app`, with ANDROID_HOME and JAVA_HOME set
# as the mobile E2E README describes. Requests go to production https://cup.audio (GET / only).
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
adb() { "${ANDROID_HOME}/platform-tools/adb" -s emulator-5600 "$@"; }

ANDROID_AVD_HOME="${HOME}/Library/Caches/cup-mobile-e2e/avd" "${ANDROID_HOME}/emulator/emulator" \
  -avd cup-mobile-e2e-api36-ram4g -no-window -no-boot-anim -read-only -port 5600 &
adb wait-for-device
(cd apps/mobile-app && pnpm exec cap sync android && cd android && ./gradlew assembleDebug --quiet)
adb install -r apps/mobile-app/android/app/build/outputs/apk/debug/app-debug.apk
# Without the cupTestApiOrigin extra, the debug build talks to https://cup.audio.
adb shell am start -n audio.cup.app/.MainActivity
sleep 8
adb forward tcp:9333 "localabstract:webview_devtools_remote_$(adb shell pidof audio.cup.app)"

# 1. Requests only (fetch-probe.js), or 2. with a looped tone playing (audio-probe.js, which also
# requests http://localhost:18999/; serve something there and `adb reverse tcp:18999 tcp:18999`).
node "${here}/cdp-eval.mjs" 9333 "$(cat "${here}/${1:-fetch-probe.js}")"
adb shell input tap 540 1200   # starts the tone in audio-probe.js; harmless otherwise
sleep 4
adb shell input keyevent KEYCODE_HOME
sleep 30
adb shell dumpsys activity processes audio.cup.app | grep curProcState
# Do not read the log while Cup is in the background: a frozen app's devtools socket can hang adb.
adb shell am start -n audio.cup.app/.MainActivity
sleep 5
node "${here}/cdp-eval.mjs" 9333 "window.__probe.log"
adb logcat -d | grep -E "UnknownHost|resolve host" | head
adb emu kill
