// Shows a full-screen button whose tap starts a looped 440 Hz tone, then every 3 s requests
// https://cup.audio/ and http://localhost:18999/ through CapacitorHttp, recording each outcome with
// the page visibility and whether the tone plays in window.__probe.log.
(() => {
  // A 2 s, 440 Hz WAV, looped, started from a tap on a full-screen button (WebView needs a gesture).
  const rate = 8000, n = rate * 2, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
  const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, "RIFF"); v.setUint32(4, 36 + n * 2, true); w(8, "WAVEfmt "); v.setUint32(16, 16, true);
  v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true);
  v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, "data"); v.setUint32(40, n * 2, true);
  for (let i = 0; i < n; i++) v.setInt16(44 + i * 2, Math.sin((i * 2 * Math.PI * 440) / rate) * 3000, true);
  const audio = new Audio(URL.createObjectURL(new Blob([buf], { type: "audio/wav" })));
  audio.loop = true;
  window.__audio = audio;
  const button = document.createElement("button");
  button.textContent = "PROBE PLAY";
  button.style.cssText = "position:fixed;inset:0;z-index:99999;font-size:40px";
  button.onclick = () => { audio.play().then(() => button.remove(), (e) => (button.textContent = String(e))); };
  document.body.append(button);
  clearInterval(window.__probeTimer);
  window.__probe = { log: [], start: Date.now() };
  const t = () => Math.round((Date.now() - window.__probe.start) / 1000);
  const push = (e) => window.__probe.log.push(`${t()}s ${document.visibilityState} playing=${!audio.paused} ${e}`);
  window.__probeTimer = setInterval(() => {
    Capacitor.Plugins.CapacitorHttp.request({ url: "https://cup.audio/", method: "GET" }).then((r) => push("cup.audio ok " + r.status), (e) => push("cup.audio ERR " + e.message));
    Capacitor.Plugins.CapacitorHttp.request({ url: "http://localhost:18999/", method: "GET" }).then((r) => push("localhost ok " + r.status), (e) => push("localhost ERR " + e.message));
  }, 3000);
  return "ready";
})()
