// Usage: node cdp-eval.mjs <port> "<expression>". Evaluates one expression in the first page of a
// WebView whose devtools socket is forwarded to localhost:<port>, and prints its JSON value.
const [port, expression] = process.argv.slice(2);
const pages = await (await fetch(`http://localhost:${port}/json`)).json();
const ws = new WebSocket(pages.find((p) => p.type === "page").webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
ws.send(JSON.stringify({ id: 1, method: "Runtime.evaluate", params: { expression, awaitPromise: true, returnByValue: true } }));
const msg = await new Promise((r) => ws.addEventListener("message", (e) => r(JSON.parse(e.data))));
console.log(JSON.stringify(msg.result?.result?.value ?? msg, null, 1));
ws.close();
