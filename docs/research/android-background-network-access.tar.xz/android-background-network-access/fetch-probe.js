// Every 3 s, requests https://cup.audio/ through the CapacitorHttp plugin and through the patched
// fetch, and records each outcome with the page's visibility in window.__probe.log.
(() => {
  clearInterval(window.__probeTimer);
  window.__probe = { log: [], start: Date.now() };
  const t = () => Math.round((Date.now() - window.__probe.start) / 1000);
  const push = (e) => window.__probe.log.push(`${t()}s ${document.visibilityState} ${e}`);
  document.addEventListener("visibilitychange", () => push("visibilitychange"));
  window.__probeTimer = setInterval(() => {
    Capacitor.Plugins.CapacitorHttp.request({ url: "https://cup.audio/", method: "GET" }).then(
      (r) => push("plugin ok " + r.status),
      (e) => push("plugin ERR " + (e && e.message)),
    );
    fetch("https://cup.audio/").then(
      (r) => push("fetch ok " + r.status),
      (e) => push("fetch ERR " + e.name + ": " + e.message),
    );
  }, 3000);
  return "ok";
})()
