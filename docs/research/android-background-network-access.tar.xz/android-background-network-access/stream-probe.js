// Shows a full-screen button whose tap plays a 19-minute, 64 kbps LibriVox MP3 from archive.org,
// then every 5 s records the position, the buffered end, and the element's states, with each
// media event that signals a stall, in window.__probe.log.
(() => {
  const audio = new Audio("https://archive.org/download/pride_and_prejudice_librivox/prideandprejudice_01-03_austen_64kb.mp3");
  window.__audio = audio;
  clearInterval(window.__probeTimer);
  window.__probe = { log: [], start: Date.now() };
  const t = () => Math.round((Date.now() - window.__probe.start) / 1000);
  const bufferedEnd = () => (audio.buffered.length ? audio.buffered.end(audio.buffered.length - 1) : 0);
  const push = (e) =>
    window.__probe.log.push(
      `${t()}s ${document.visibilityState} at=${audio.currentTime.toFixed(0)} buffered=${bufferedEnd().toFixed(0)} paused=${audio.paused} ready=${audio.readyState} net=${audio.networkState} ${e}`,
    );
  for (const type of ["playing", "waiting", "stalled", "suspend", "error", "pause", "ended"]) {
    audio.addEventListener(type, () => push(`event:${type}${audio.error ? " code=" + audio.error.code : ""}`));
  }
  document.addEventListener("visibilitychange", () => push("visibilitychange"));
  const button = document.createElement("button");
  button.textContent = "PROBE PLAY";
  button.style.cssText = "position:fixed;inset:0;z-index:99999;font-size:40px";
  button.onclick = () => audio.play().then(() => button.remove(), (e) => (button.textContent = String(e)));
  document.body.append(button);
  window.__probeTimer = setInterval(() => push("tick"), 5000);
  return "ready";
})()
